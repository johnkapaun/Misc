﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EquipmentBarcodeScanner
{
    internal partial class frmManEntry : Form
    {
        internal frmManEntry(List<string> lstAllAvailableEquipment)
        {
            InitializeComponent();
            g_lstAllAvailableEquipment = lstAllAvailableEquipment;
        }
        internal List<string> SelectedEquipment
        {
            get { return g_lstSelectedEquipment; }
        }

        private List<string> g_lstAllAvailableEquipment = new List<string>();
        private List<string> g_lstSelectedEquipment = new List<string>();
        private DataTable DT = new DataTable();

        private void frmManEntry_Load(object sender, EventArgs e)
        {
            try
            {
                g_lstAllAvailableEquipment.Sort();
                lbxAllItems.DataSource = g_lstAllAvailableEquipment;
                DT.Columns.Add("Index", System.Type.GetType("System.Int32"));
                DT.Columns.Add("Equipment");
                for (int i = 0; i < g_lstAllAvailableEquipment.Count; i++)
                    DT.Rows.Add(new object[] { i, g_lstAllAvailableEquipment[i] });
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (lbxAllItems.SelectedItems.Count > 0)
                    addEntry(lbxAllItems.SelectedItem.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (lbxSelectedItems.SelectedItems.Count > 0)
                    lbxSelectedItems.Items.RemoveAt(lbxSelectedItems.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void tbxSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // this is the case where you delete characters
                if (lbxAllItems.SelectedItem.ToString().ToUpper().StartsWith(tbxSearch.Text.ToUpper()))
                    return;
                //
                DataRow[] selectedRows;
                selectedRows = DT.Select("Equipment like '" + tbxSearch.Text + "%'");
                if (selectedRows.Length > 0)
                    lbxAllItems.SelectedIndex = Convert.ToInt32(selectedRows[0]["Index"]);
                else
                {
                    tbxSearch.Text = tbxSearch.Text.Remove(tbxSearch.Text.Length - 1);
                    tbxSearch.Select(tbxSearch.Text.Length, 0);
                    tbxSearch.ScrollToCaret();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void tbxSearch_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (lbxAllItems.SelectedItems.Count > 0)
                    addEntry(lbxAllItems.SelectedItems[0].ToString());
                tbxSearch.Clear();
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void lbxAllItems_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
            if (e.KeyCode == Keys.Enter)
                if (lbxAllItems.SelectedItems.Count > 0)
                    addEntry(lbxAllItems.SelectedItems[0].ToString());
            tbxSearch.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
            for (int i = 0; i < lbxSelectedItems.Items.Count; i++)
                g_lstSelectedEquipment.Add(lbxSelectedItems.Items[i].ToString());
            Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lbxAllItems_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                addEntry(lbxAllItems.SelectedItem.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void addEntry(string strEquipmentNumber)
        {
            try
            {
                if (!lbxSelectedItems.Items.Contains(strEquipmentNumber))
                    lbxSelectedItems.Items.Add(strEquipmentNumber);
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }


    }
}
