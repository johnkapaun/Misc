
#include "stdafx.h"
#include "main.h"

///////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////// Application Hook ///////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////

static WNDPROC ShutdownHook_OldWndProc = NULL;
static DWORD LVFrameThreadID = 0;
static bool ThreadsAttached  = false;

static DWORD GetInterfaceThreadID( void )
{
	HWND hwnd = FindWindowEx(	HWND_MESSAGE,					// handle to parent window
								NULL,							// handle to a child window
								"HwtDeviceCommonInterface",		// pointer to class name
								NULL );							// pointer to window name
	if( hwnd == NULL )
	{
		MessageBox(NULL, "Window Not Found", "GetInterfaceThreadID", MB_OK );
		return 0;
	}

	return GetWindowThreadProcessId( hwnd, NULL );
}

static TString DLL_FileName(void)
{
	char Path[_MAX_PATH + 1];

	DWORD PathLength = GetModuleFileName( This_Lib, Path, _MAX_PATH );	// determine file path of loaded DLL
	Path[PathLength] = '\0';

	return Path;
}

static DWORD GetWindowProcessId( HWND hWnd )
{
	DWORD ProcessID = 0;

	GetWindowThreadProcessId( hWnd, &ProcessID ); // retrieve the identifier of the process that created the window

	return ProcessID;
};

static BOOL CALLBACK EnumWindowsProc( HWND hwnd,  LPARAM lParam  )
{
	static DWORD ProcessID = GetCurrentProcessId();	// Get the Application's Process ID

	// If top level window ( GetParent(hwnd) is NULL ) and
	// If the window owned by this process ( Window's ProcessId == Application's ProcessID ) and
	// If the window is visible ( IsWindowVisible(hwnd) returns TRUE )
	if( GetParent(hwnd) == NULL && GetWindowProcessId(hwnd) == ProcessID && IsWindowVisible(hwnd) == TRUE )
	{
		char str[21];

		str[GetClassName( hwnd,  str,  20 )] = '\0';	// Get Class Name and mark end of string

		if( stricmp(str, "LVFrame" ) == 0 )	// If window Class is 'LVFrame'
		{
			*((HWND *)lParam) = hwnd;		// return the window handle in lParam
			return FALSE;					// indicate we have found the window
		}
	}
	return TRUE;	// indicate keep looking
}

static LRESULT CALLBACK CallWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if( uMsg == WM_DESTROY )
	{
		if( ThreadsAttached == true )
		{
			DWORD InterfaceThreadID = GetInterfaceThreadID();

			if( InterfaceThreadID != 0 && LVFrameThreadID != 0 )
				AttachThreadInput( LVFrameThreadID, InterfaceThreadID, FALSE );
		}
	}
	return CallWindowProc(ShutdownHook_OldWndProc, hwnd, uMsg, wParam, lParam);	// call original WndProc
}

void InstallApplicationHook(void)
{
	static bool Installed = false;

	if( Installed )	// Check if the hook was already installed
		return;

	Installed = true;

	// Bump the attach count to prevent LabVIEW from freeing this DLL when the last VI is closed.
	LoadLibrary( DLL_FileName() );

	HWND MainFrame = NULL;
    EnumWindows( EnumWindowsProc, (LPARAM) &MainFrame );

	if( MainFrame != NULL )
	{
		LVFrameThreadID   = GetWindowThreadProcessId( MainFrame, NULL );

		ShutdownHook_OldWndProc = (WNDPROC)GetWindowLong( MainFrame, GWL_WNDPROC );
		ShutdownHook_OldWndProc = (WNDPROC)SetWindowLong( MainFrame, GWL_WNDPROC, (LONG)CallWndProc);

		DWORD InterfaceThreadID = GetInterfaceThreadID();

		if( InterfaceThreadID == 0 || LVFrameThreadID == 0 || AttachThreadInput( LVFrameThreadID, InterfaceThreadID, TRUE ) == 0 )
			MessageBox(NULL, "Thread Attached Failed", "InstallApplicationHook", MB_OK );

		else
			ThreadsAttached = true;
	}
	else
		MessageBox(NULL, "Unable to find LabVIEW 'LVFrame'", "InstallApplicationHook", MB_OK );
}

///////////////////////////////////////////////////////////////////////////////////////////////
