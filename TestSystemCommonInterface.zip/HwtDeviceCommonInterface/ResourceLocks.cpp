
#include <StdAfx.h>
#include "ResourceLocks.h"

///////////////////////////////////////////////////////////////////////////////////////////////

// The 'DeviceResourceLock' class wraps a Windows Mutex object
// and is used to prevent simultaneous access to functions 
// that communicate with the device.
//
DeviceResourceLock::DeviceResourceLock(ErrorCluster *error, bool LockResource )
{
	Locked = false;

	if( error->Status() )
		return;

	if( LockResource )
		Lock(error);

	else if( LockHandle == NULL )
		error->SetError(72,"Device Resource Lock not Found!");
}

void DeviceResourceLock::Lock(ErrorCluster *error)
{
	if( error->Status() || Locked )
		return;

	if( LockHandle == NULL )
	{
		error->SetError(72,"Device Resource Lock not Found!");
		return;
	}

	switch( WaitForSingleObject( LockHandle, 60000 ) ) // Wait for up to 60 Seconds
	{
		case WAIT_OBJECT_0:
			Locked = true;
			break;

		case WAIT_TIMEOUT:
			Locked = false;
			error->SetError(72,"Device Resource Lock Timeout!");
			break;

		case WAIT_ABANDONED:
			Locked = true;
			error->SetError(72,"Device Resource Lock in a Undefined State!");
			break;

		default:
			Locked = false;
			error->SetError(72,"Device Resource Lock request returned unexpected response!");
			break;
	}
}

void DeviceResourceLock::UnLock(void)
{
	if( Locked )
		Locked = (ReleaseMutex( LockHandle )) ? false : Locked;
}

DeviceResourceLock::~DeviceResourceLock()
{
	UnLock();
}

HANDLE DeviceResourceLock::LockHandle = CreateMutex(NULL, FALSE, "CRM_DEV DeviceLock");

///////////////////////////////////////////////////////////////////////////////////////////////

// The 'UplinkResourceLock' class wraps a Windows Mutex object
// and is used to prevent simultaneous access to functions 
// that process unsolicited uplink.
//
UplinkResourceLock::UplinkResourceLock(ErrorCluster *error, bool LockResource )
{
	Locked = false;

	if( error->Status() )
		return;

	if( LockResource )
		Lock(error);

	else if( LockHandle == NULL )
		error->SetError(72,"Uplink Resource Lock not Found!");
}

void UplinkResourceLock::Lock(ErrorCluster *error)
{
	if( error->Status() || Locked )
		return;

	if( LockHandle == NULL )
	{
		error->SetError(72,"Uplink Resource Lock not Found!");
		return;
	}

	switch( WaitForSingleObject( LockHandle, 60000 ) ) // Wait for up to 60 Seconds
	{
		case WAIT_OBJECT_0:
			Locked = true;
			break;

		case WAIT_TIMEOUT:
			Locked = false;
			error->SetError(72,"Uplink Resource Lock Timeout!");
			break;

		case WAIT_ABANDONED:
			Locked = true;
			error->SetError(72,"Uplink Resource Lock in a Undefined State!");
			break;

		default:
			Locked = false;
			error->SetError(72,"Uplink Resource Lock request returned unexpected response!");
			break;
	}
}

void UplinkResourceLock::UnLock(void)
{
	if( Locked )
		Locked = (ReleaseMutex( LockHandle )) ? false : Locked;
}

UplinkResourceLock::~UplinkResourceLock()
{
	UnLock();
}

HANDLE UplinkResourceLock::LockHandle = CreateMutex(NULL, FALSE, "CRM_DEV UplinkLock");

///////////////////////////////////////////////////////////////////////////////////////////////

// The 'ApplicationResourceLock' class wraps a Windows Mutex object
// and is used to prevent simultaneous connection/disconnection
// operations between Client Applications and the Host.
// Client Applications need to access the Mulex by name "CRM_DEV ApplicationLock".
//
ApplicationResourceLock::ApplicationResourceLock(ErrorCluster *error, bool LockResource )
{
	Locked = false;

	if( error->Status() )
		return;

	if( LockResource )
		Lock(error);

	else if( LockHandle == NULL )
		error->SetError(72,"Application Resource Lock not Found!");
}

void ApplicationResourceLock::Lock(ErrorCluster *error)
{
	if( error->Status() || Locked )
		return;

	if( LockHandle == NULL )
	{
		error->SetError(72,"Application Resource Lock not Found!");
		return;
	}

	switch( WaitForSingleObject( LockHandle, 60000 ) ) // Wait for up to 60 Seconds
	{
		case WAIT_OBJECT_0:
			Locked = true;
			break;

		case WAIT_TIMEOUT:
			Locked = false;
			error->SetError(72,"Application Resource Lock Timeout!");
			break;

		case WAIT_ABANDONED:
			Locked = true;
			error->SetError(72,"Application Resource Lock in a Undefined State!");
			break;

		default:
			Locked = false;
			error->SetError(72,"Application Resource Lock request returned unexpected response!");
			break;
	}
}

void ApplicationResourceLock::UnLock(void)
{
	if( Locked )
		Locked = (ReleaseMutex( LockHandle )) ? false : Locked;
}

ApplicationResourceLock::~ApplicationResourceLock()
{
	UnLock();
}

HANDLE ApplicationResourceLock::LockHandle = CreateMutex(NULL, FALSE, "CRM_DEV ApplicationLock");

///////////////////////////////////////////////////////////////////////////////////////////////