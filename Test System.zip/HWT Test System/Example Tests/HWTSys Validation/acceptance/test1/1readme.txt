This folder is set up to test a missing/misnamed test app VI.

"Invalid test application
THe selected directory does not contain a valid test vi"

Retry/cancel