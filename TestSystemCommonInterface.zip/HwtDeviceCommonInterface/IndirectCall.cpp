
#include "stdafx.h"
#include "main.h"
#include "IndirectCall.h"
#include "IndirectCallTypeDef.h"

////////////////////////////////////////////////////////////////////////////////////

IndirectFunctionCallStack::IndirectFunctionCallStack(void)
{
	CallStack = new unsigned char[1000];	// Hack, needs to be dynamic
	memset( CallStack, 0, 1000 );
	StackSize = 0;
	FunctionCallComplete = false;
	ReturnValuePassedInRegisters = 0;
}

IndirectFunctionCallStack::~IndirectFunctionCallStack()
{
	delete [] CallStack;
	CallStack = NULL;
	StackSize = 0;
}

// Calls a function in the Device Specific DLL
void IndirectFunctionCallStack::FunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut )
{
	DataIn = FlatDataIn;
	DataOut = FlatDataOut;

	if( !error->Status() )
	{
		unFlattenFunctionCall( error );	// Build the function call stack

		void *fptr = GetDeviceFunctionAddress( error, FunctionName);	// Lookup function name in DLL

		if( !error->Status() )
			FunctionCall( fptr );		// Call the function
	}

	FlattenResults( error );		// return the function results
}

// Calls Controller Object Function in controller DLL
void IndirectFunctionCallStack::DirectControllerObjectFunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut )
{
	DataIn = FlatDataIn;
	DataOut = FlatDataOut;

	if( !InDebugMode )
		error->SetError( 42, "Direct Controller Object Function Call - NOT supported in non-debug mode" );

	if( !error->Status() )
	{
		unFlattenFunctionCall( error );	// Build the function call stack

		// Allocate variables to receive the parsed function name ( Gen2(0)+12 )
		char *FamilyRev = new char[FunctionName.Length() + 1];	// Controller Object Name - 'Gen2' in the example above
		int ControllerNumber = 0;								// Controller Number - '0' in the example above
		unsigned FunctionOffset = 0;							// Function VTable index - '12' in the example above

		// extract the 'Controller Object Name', 'Controller Number' and 'Function VTable index'
		if( !error->Status() && sscanf( FunctionName, "%[^(](%d)+%u", FamilyRev, &ControllerNumber, &FunctionOffset ) != 3 )
			error->SetError( 42, "ObjectFunctionCall - Invalid Format" );

		// Get pointer to controller object
		void *optr = AcquireControllerObjectPointer( error, FamilyRev, ControllerNumber );

		// call Controller Object function
		if( optr != NULL && !error->Status() )
			FunctionCall( (*((void***)optr))[FunctionOffset], optr );

		delete [] FamilyRev;
	}

	FlattenResults( error );	// return the function results
}

// Calls Debug Controller Object Function
void IndirectFunctionCallStack::DebugControllerFunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut )
{
	DataIn = FlatDataIn;
	DataOut = FlatDataOut;

	if( !error->Status() )
	{
		unFlattenFunctionCall( error );	// Build the function call stack

		unsigned FunctionOffset = 0;	// Function VTable index

		// extract the 'Function VTable index'
		if( !error->Status() && sscanf( FunctionName, "%u", &FunctionOffset ) != 1 )
			error->SetError( 42, "DebugControllerFunctionCall - Invalid Format" );

		// Get pointer to controller object
		void *optr = DebugToolsObject(NULL);

		// call Debug Controller Object function
		if( optr != NULL && !error->Status() )
			FunctionCall( (*((void***)optr))[FunctionOffset], optr );
	}

	FlattenResults( error );	// return the function results
}

////////////////////////////////////////////////////////////////////////////////////

void IndirectFunctionCallStack::AdjustStackForReturnValue( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	// determine if the returned parameter is an object
	bool isObject = ( DataType & ( DataTypeArray | DataTypeArrayArray | DataTypeSTR ) ) != 0;

	// if returned parameter is passed by pointer or reference; or is a non-object type passed by value
	// set the flag indicating the returned data is returned in the processor registers
	if( ( DataType & DataTypeByVAL ) != DataTypeByVAL || !isObject )
	{
		if( DataType == TypeRetSglVAL )			// float32 values are returned on FP processor stack
			ReturnValuePassedInRegisters = 2;

		else if( DataType == TypeRetDblVAL )	// float64 values are returned on FP processor stack
			ReturnValuePassedInRegisters = 3;

		else									// all other values an pointers are returned in EDX:EAX
			ReturnValuePassedInRegisters = 1;
	}

	// else returned paramter is passed back to the calling function on the stack
	// the calling function needs to pass a pointer to a memory space for the returned
	// object as the first item on the stack.  The location for the object buffer is
	// unknown at this point in the code, therefore only space for the pointer is 
	// being reserved at this time.
	else
	{
		ReturnValuePassedInRegisters = 0;
		StackSize += sizeof(void*);
	}
}

////////////////////////////////////////////////////////////////////////////////////

// Extracts the function name and parameters
// Builds the function call stack.
void IndirectFunctionCallStack::unFlattenFunctionCall( ErrorCluster *error )
{
	uInt32Array DataTypes;
	uInt32 DataType;
	bool FunctionReturnsValue = false;			// flag used to indicate if the function returns a value

	DataIn->unFlatten(&FunctionName);			// extract the function name from the flattened input stream
	DataIn->unFlatten(&DataTypes);				// extract the parameter type array from the flattened input stream
	DataIn->BufferStatus(error);				// check the input stream for extract errors

	int ParamListSize = DataTypes.GetSize();	// Number of Parameters

	// For functions that return a value the return value parameter is expected to be that last item
	// in the list. However C++ returns the value in processer register or as the first thing
	// on the stack.  For this reason we need to process the return value first.
	if( ParamListSize > 0 && ( DataTypes[DataTypes.GetUpperBound()] & DataTypeRETURN ) == DataTypeRETURN )
	{
		AdjustStackForReturnValue( error, DataTypes[DataTypes.GetUpperBound()] );
		FunctionReturnsValue = !error->Status();	// We need to add this param to the ParamTrackingInfo list last, so just set a flag for now
		ParamListSize--;							// since we have already dealt with this param, reduce the count for the following for loop
	}

	for( int i = 0; !error->Status() && i < ParamListSize; i++ )
	{
		DataType = DataTypes[i];

		// There can only be one returned parameter, and we have handled it above, if there is a second, error
		if( ( DataType & DataTypeRETURN ) == DataTypeRETURN )
			error->SetError( 42, "unFlattenFunctionCall - return parameter must be last item in list" );

		switch( DataType & DataFilterType )
		{
			case DataTypeERR:	unFlattenERR( error, DataType );		break;
			case DataTypeSTR:	unFlattenSTR( error, DataType );		break;
			case DataTypeI8:	unFlattenI8(  error, DataType );		break;
			case DataTypeI16:	unFlattenI16( error, DataType );		break;
			case DataTypeI32:	unFlattenI32( error, DataType );		break;
			case DataTypeU8:	unFlattenU8(  error, DataType );		break;
			case DataTypeU16:	unFlattenU16( error, DataType );		break;
			case DataTypeU32:	unFlattenU32( error, DataType );		break;
			case DataTypeSGL:	unFlattenFloat32( error, DataType );	break;
			case DataTypeDBL:	unFlattenFloat64( error, DataType );	break;
			case DataTypeBOOL:	unFlattenBOOL( error, DataType );		break;
			case DataTypeCSTR:	unFlattenCSTR( error, DataType );		break;
		
			default:	error->SetError( 42, "unFlattenFunctionCall - Invalid DataType -- 0x%08X", DataType );
		}

		DataIn->BufferStatus(error);	// check the input stream for extract errors
	}

	DataIn->BufferStatus(error);	// check the input stream for extract errors

	if( FunctionReturnsValue == true )	// If function returns a value
	{
		// If returned parameter is an object passed by value.  Update the pointer at the begining
		// of our buffer with a pointer to available space at the end of our used buffer space.
		if( ReturnValuePassedInRegisters == 0 )
			*((uInt32 *)CallStack) = (uInt32)(CallStack + StackSize);

		// The returned value needs to be the last value in the flattened returned string
		// Therefore we need to add this param to the ParamTrackingInfo list last
		ParamTrackingInfo Param( DataTypes[DataTypes.GetUpperBound()], CallStack + StackSize );
		ParamInfo.push_back(Param);
	}
}

////////////////////////////////////

// Builds the returned parameter flattened data stream
// Releases all memory allocated on our stack buffer
void IndirectFunctionCallStack::FlattenResults( ErrorCluster *error )
{
	unsigned size = ParamInfo.size();

	// Allow for case where first parameter is not an ErrorCluster*
	if( size == 0 || ParamInfo[0].Type != TypeErrPTR )
		DataOut->Flatten( error );

	// otherwise allow for case where we never called the function because of an earlier error
	else if( error->Status() )
		DataOut->Flatten( error );	// add the error to the output string

	ErrorCluster Err = *error;		// Use a different object to track Flatten Errors
									// Make sure if we already have an error to not flatten
									// any more data by setting 'Err' to '*error'.

	for( unsigned i = 0; i < size; i++ )  // don't stop on error, need to release all memory
	{
		uInt32 DataType = (ParamInfo[i].Type & DataFilterType);

		switch( DataType )
		{
			case  DataTypeERR:		FlattenERR( &Err, ParamInfo[i] );		break;
			case  DataTypeSTR:		FlattenSTR( &Err, ParamInfo[i] );		break;
			case  DataTypeI8:		FlattenI8(  &Err, ParamInfo[i] );		break;
			case  DataTypeI16:		FlattenI16( &Err, ParamInfo[i] );		break;
			case  DataTypeI32:		FlattenI32( &Err, ParamInfo[i] );		break;
			case  DataTypeU8:		FlattenU8(  &Err, ParamInfo[i] );		break;
			case  DataTypeU16:		FlattenU16( &Err, ParamInfo[i] );		break;
			case  DataTypeU32:		FlattenU32( &Err, ParamInfo[i] );		break;
			case  DataTypeSGL:		FlattenFloat32( &Err, ParamInfo[i] );	break;
			case  DataTypeDBL:		FlattenFloat64( &Err, ParamInfo[i] );	break;
			case  DataTypeBOOL:		FlattenBOOL( &Err, ParamInfo[i] );		break;
			case  DataTypeCSTR:		FlattenCSTR( &Err, ParamInfo[i] );		break;

			default:				Err.SetError( 42, "FlattenResults - Invalid DataType -- 0x%08X", ParamInfo[i].Type );
		}
	}

	DataOut->BufferStatus(&Err);	// check the output stream for errors

	// If we did not have an incoming error (*error) but did have a Flatten error (Err)
	// then flush the output buffer and add only the new error
	if( error->Status() == false && Err.Status() == true )
	{
		DataOut->ResetBuffer();
		DataOut->Flatten( &Err );
		*error = Err;
	}
}

////////////////////////////////////

// Based on the type of parameter return a code indicating how memory allocated
// for the parameter should be released.
// 1 - indicates the 'delete' operater should be called on the pointer
// 2 - indicates the object destructor should be called.
// 0 - indicates the memory will be released when we release our stack buffer, nothing else needs to be done
int IndirectFunctionCallStack::DeleteMethod( const ParamTrackingInfo &Param, void *ptr )
{
	bool isValueType  = ( Param.Type & DataFilterDir ) == DataTypeByVAL;

	bool isObject = ( Param.Type & ( DataTypeArray | DataTypeArrayArray | DataTypeSTR ) ) != 0;

	// if Parameter is returned by the function
	if( ( Param.Type & DataTypeRETURN ) == DataTypeRETURN )
	{
		if( isObject && isValueType && HasValidVTable(ptr) )
			return 2;	// ptr->~Object()

		if( ( Param.Type & DataFilterDir ) == DataTypeByPTR )
			return 1;	// delete ptr
	}
	// if Parameter is passed to the function
	else
	{
		if( !isValueType )
			return 1;	// delete ptr;

		if( isObject && !FunctionCallComplete && HasValidVTable(ptr) )
			return 2;	// ptr->~Object()
	}

	return 0;	// if none of the above cases fit, parameter must be a non-object value on the stack, do nothing
}

// Determine if an index to a parameter on our stack is a pointer to an object/value
// or a pointer to a pointer to an object/value
bool IndirectFunctionCallStack::Ptr_Or_PtrToPtr( const ParamTrackingInfo &Param )
{
	if( ( Param.Type & DataTypeByVAL ) == 0 )	// If not a by Value data type
		return false;							// then it is a Pointer to a Pointer

	return true;	// If none of the above cases fit, it must be a Pointer
}

// Determine if a parameter should be stored in the output stream
bool IndirectFunctionCallStack::OutputData( ErrorCluster *error, const ParamTrackingInfo &Param )
{
	if( error->Status() )	// Once we get a Flatten Data Error, Stop adding new data
		return false;		// Client should detect short data string, not sure what it would do with missing parameters

	return ( Param.Type & DataFilterDir ) == DataTypeByPTR  || ( Param.Type & DataTypeRETURN ) == DataTypeRETURN;
}

////////////////////////////////////
/////////// ErrorCluster ///////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenERR( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	if( DataType == TypeErrPTR )	// Only the *ErrorCluster data type is supported
	{
		ParamTrackingInfo Param( DataType, CallStack + StackSize );

		// create object, copy pointer into our buffer, update with flattened data
		DataIn->unFlatten( *((ErrorCluster **)Param.StackPtr) = new ErrorCluster );

		StackSize += sizeof(ErrorCluster*);	// adjust stack buffer index

		ParamInfo.push_back(Param);
	}

	else
		error->SetError( 42, "unFlattenERR - Invalid DataType -- 0x%08X", DataType );
}

void IndirectFunctionCallStack::FlattenERR( ErrorCluster *error, ParamTrackingInfo &Param )
{
	if( Param.Type == TypeErrPTR )	// Only the *ErrorCluster data type is supported
	{
		// Get pointer to object
		ErrorCluster *ptr = *((ErrorCluster **)Param.StackPtr);

		if( !error->Status() )			// Once we get a Flatten Data Error, Stop adding new data
			DataOut->Flatten( ptr );	// Client should detect short data string, not sure what it
										// would do with missing parameters
		delete ptr;
	}

	else
		error->SetError( 42, "FlattenERR - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
////////////// TString /////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenSTR( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																		// create object, copy pointer into our buffer
			DataIn->unFlatten( *((TString **)Param.StackPtr) = new TString );	// update with flattened data
			StackSize += sizeof(TString*);										// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			TString dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(TString) );	// copy into our buffer
			DataIn->unFlatten( (TString *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(TString);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																					// create object, copy pointer into our buffer
			DataIn->unFlatten( *((TStringArray **)Param.StackPtr) = new TStringArray );		// update with flattened data
			StackSize += sizeof(TStringArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			TStringArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(TStringArray) );	// copy into our buffer
			DataIn->unFlatten( (TStringArray *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(TStringArray);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																							// create object, copy pointer into our buffer
			DataIn->unFlatten( *((TStringArrayArray **)Param.StackPtr) = new TStringArrayArray );	// update with flattened data
			StackSize += sizeof(TStringArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			TStringArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(TStringArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (TStringArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(TStringArrayArray);							// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenSTR - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenSTR( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		TString *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (TString *)Param.StackPtr : *((TString **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;			break;
			case 2 :	ptr->~TString();	break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		TStringArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (TStringArray *)Param.StackPtr : *((TStringArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~TStringArray();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		TStringArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (TStringArrayArray *)Param.StackPtr : *((TStringArrayArray **)Param.StackPtr);
		
		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~TStringArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenSTR - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// int8 ///////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenI8( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int8 **)Param.StackPtr) = new int8 );	// update with flattened data
			StackSize += sizeof(int8*);									// adjust stack buffer index
		}
		else	// All values smaller than 32 bits need to be sign extended to 32 bit
		{
			int8 temp;
			DataIn->unFlatten( &temp );							// get value from flattened data
			int32 temp32 = (int32)temp;							// sign extend to 32 bits
			memcpy( Param.StackPtr, &temp32, sizeof(int32) );	// update our copy with the flattened data
			StackSize += sizeof(int32);							// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																			// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int8Array **)Param.StackPtr) = new int8Array );	// update with flattened data
			StackSize += sizeof(int8Array*);										// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int8Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int8Array) );	// copy into our buffer
			DataIn->unFlatten( (int8Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int8Array);							// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																					// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int8ArrayArray **)Param.StackPtr) = new int8ArrayArray );	// update with flattened data
			StackSize += sizeof(int8ArrayArray*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int8ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int8ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (int8ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int8ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenI8 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenI8( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int8 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int8 *)Param.StackPtr : *((int8 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;			break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int8Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int8Array *)Param.StackPtr : *((int8Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~int8Array();		break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int8ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int8ArrayArray *)Param.StackPtr : *((int8ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~int8ArrayArray();		break;
		}
	}

	else
		error->SetError( 42, "FlattenI8 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// int16 //////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenI16( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																	// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int16 **)Param.StackPtr) = new int16 );	// update with flattened data
			StackSize += sizeof(int16*);									// adjust stack buffer index
		}
		else	// All values smaller than 32 bits need to be sign extended to 32 bit
		{
			int16 temp;
			DataIn->unFlatten( &temp );							// get value from flattened data
			int32 temp32 = (int32)temp;							// sign extend to 32 bits
			memcpy( Param.StackPtr, &temp32, sizeof(int32) );	// update our copy with the flattened data
			StackSize += sizeof(int32);							// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int16Array **)Param.StackPtr) = new int16Array );		// update with flattened data
			StackSize += sizeof(int16Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int16Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int16Array) );	// copy into our buffer
			DataIn->unFlatten( (int16Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int16Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																						// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int16ArrayArray **)Param.StackPtr) = new int16ArrayArray );	// update with flattened data
			StackSize += sizeof(int16ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int16ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int16ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (int16ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int16ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenI16 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenI16( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int16 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int16 *)Param.StackPtr : *((int16 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;			break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int16Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int16Array *)Param.StackPtr : *((int16Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~int16Array();		break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int16ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int16ArrayArray *)Param.StackPtr : *((int16ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~int16ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenI16 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// int32 //////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenI32( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																	// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int32 **)Param.StackPtr) = new int32 );	// update with flattened data
			StackSize += sizeof(int32*);									// adjust stack buffer index
		}
		else
		{
			DataIn->unFlatten( (int32 *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(int32);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int32Array **)Param.StackPtr) = new int32Array );		// update with flattened data
			StackSize += sizeof(int32Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int32Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int32Array) );	// copy into our buffer
			DataIn->unFlatten( (int32Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int32Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																						// create object, copy pointer into our buffer
			DataIn->unFlatten( *((int32ArrayArray **)Param.StackPtr) = new int32ArrayArray );	// update with flattened data
			StackSize += sizeof(int32ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			int32ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(int32ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (int32ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(int32ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenI32 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenI32( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int32 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int32 *)Param.StackPtr : *((int32 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;			break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int32Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int32Array *)Param.StackPtr : *((int32Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~int32Array();		break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		int32ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (int32ArrayArray *)Param.StackPtr : *((int32ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~int32ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenI32 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// uInt8 //////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenU8( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																	// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt8 **)Param.StackPtr) = new uInt8 );	// update with flattened data
			StackSize += sizeof(uInt8*);									// adjust stack buffer index
		}
		else	// All values smaller than 32 bits need to be extended to 32 bit
		{
			uInt8 temp;
			DataIn->unFlatten( &temp );							// get value from flattened data
			uInt32 temp32 = (uInt32)temp;						// extend to 32 bits
			memcpy( Param.StackPtr, &temp32, sizeof(uInt32) );	// update our copy with the flattened data
			StackSize += sizeof(uInt32);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt8Array **)Param.StackPtr) = new uInt8Array );		// update with flattened data
			StackSize += sizeof(uInt8Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt8Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt8Array) );	// copy into our buffer
			DataIn->unFlatten( (uInt8Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(uInt8Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																						// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt8ArrayArray **)Param.StackPtr) = new uInt8ArrayArray );	// update with flattened data
			StackSize += sizeof(uInt8ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt8ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt8ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (uInt8ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(uInt8ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenU8 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenU8( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt8 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt8 *)Param.StackPtr : *((uInt8 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt8Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt8Array *)Param.StackPtr : *((uInt8Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~uInt8Array();		break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt8ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt8ArrayArray *)Param.StackPtr : *((uInt8ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~uInt8ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenU8 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// uInt16 /////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenU16( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																		// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt16 **)Param.StackPtr) = new uInt16 );		// update with flattened data
			StackSize += sizeof(uInt16*);										// adjust stack buffer index
		}
		else	// All values smaller than 32 bits need to be extended to 32 bit
		{
			uInt16 temp;
			DataIn->unFlatten( &temp );							// get value from flattened data
			uInt32 temp32 = (uInt32)temp;						// extend to 32 bits
			memcpy( Param.StackPtr, &temp32, sizeof(uInt32) );	// update our copy with the flattened data
			StackSize += sizeof(uInt32);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt16Array **)Param.StackPtr) = new uInt16Array );	// update with flattened data
			StackSize += sizeof(uInt16Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt16Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt16Array) );	// copy into our buffer
			DataIn->unFlatten( (uInt16Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(uInt16Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																						// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt16ArrayArray **)Param.StackPtr) = new uInt16ArrayArray );	// update with flattened data
			StackSize += sizeof(uInt16ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt16ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt16ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (uInt16ArrayArray *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(uInt16ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenU16 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenU16( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt16 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt16 *)Param.StackPtr : *((uInt16 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt16Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt16Array *)Param.StackPtr : *((uInt16Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~uInt16Array();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt16ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt16ArrayArray *)Param.StackPtr : *((uInt16ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~uInt16ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenU16 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
/////////////// uInt32 /////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenU32( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																	// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt32 **)Param.StackPtr) = new uInt32 );	// update with flattened data
			StackSize += sizeof(uInt32*);									// adjust stack buffer index
		}
		else
		{
			DataIn->unFlatten( (uInt32 *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(uInt32);					// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt32Array **)Param.StackPtr) = new uInt32Array );	// update with flattened data
			StackSize += sizeof(uInt32Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt32Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt32Array) );	// copy into our buffer
			DataIn->unFlatten( (uInt32Array *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(uInt32Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																						// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt32ArrayArray **)Param.StackPtr) = new uInt32ArrayArray );	// update with flattened data
			StackSize += sizeof(uInt32ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			uInt32ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(uInt32ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (uInt32ArrayArray *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(uInt32ArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenU32 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenU32( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt32 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt32 *)Param.StackPtr : *((uInt32 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt32Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt32Array *)Param.StackPtr : *((uInt32Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~uInt32Array();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		uInt32ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (uInt32ArrayArray *)Param.StackPtr : *((uInt32ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~uInt32ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenU32 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
////////////// float32 /////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenFloat32( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																		// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float32 **)Param.StackPtr) = new float32 );	// update with flattened data
			StackSize += sizeof(float32*);										// adjust stack buffer index
		}
		else
		{
			DataIn->unFlatten( (float32 *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(float32);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																					// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float32Array **)Param.StackPtr) = new float32Array );		// update with flattened data
			StackSize += sizeof(float32Array*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			float32Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(float32Array) );	// copy into our buffer
			DataIn->unFlatten( (float32Array *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(float32Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																							// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float32ArrayArray **)Param.StackPtr) = new float32ArrayArray );	// update with flattened data
			StackSize += sizeof(float32ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			float32ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(float32ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (float32ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(float32ArrayArray);							// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenFloat32 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenFloat32( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float32 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float32 *)Param.StackPtr : *((float32 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float32Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float32Array *)Param.StackPtr : *((float32Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~float32Array();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float32ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float32ArrayArray *)Param.StackPtr : *((float32ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~float32ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenFloat32 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
////////////// float64 /////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenFloat64( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																		// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float64 **)Param.StackPtr) = new float64 );	// update with flattened data
			StackSize += sizeof(float64*);										// adjust stack buffer index
		}
		else
		{
			DataIn->unFlatten( (float64 *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(float64);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																				// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float64Array **)Param.StackPtr) = new float64Array );	// update with flattened data
			StackSize += sizeof(float64Array*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			float64Array dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(float64Array) );	// copy into our buffer
			DataIn->unFlatten( (float64Array *)Param.StackPtr );	// update our copy with the flattened data
			StackSize += sizeof(float64Array);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																							// create object, copy pointer into our buffer
			DataIn->unFlatten( *((float64ArrayArray **)Param.StackPtr) = new float64ArrayArray );	// update with flattened data
			StackSize += sizeof(float64ArrayArray*);												// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			float64ArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(float64ArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (float64ArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(float64ArrayArray);							// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenFloat64 - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenFloat64( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float64 *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float64 *)Param.StackPtr : *((float64 **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float64Array *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float64Array *)Param.StackPtr : *((float64Array **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;				break;
			case 2 :	ptr->~float64Array();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		float64ArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (float64ArrayArray *)Param.StackPtr : *((float64ArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~float64ArrayArray();	break;
		}
	}

	else
		error->SetError( 42, "FlattenFloat64 - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
////////////// bool ////////////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenBOOL( ErrorCluster *error, uInt32 DataType )
{
	if( error->Status() )
		return;

	const int ArrayType = DataType & DataFilterSize;

	ParamTrackingInfo Param( DataType, CallStack + StackSize );

	if( ArrayType == DataTypeNonArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																	// create object, copy pointer into our buffer
			DataIn->unFlatten( *((uInt8 **)Param.StackPtr) = new uInt8 );	// update with flattened data
			StackSize += sizeof(uInt8*);									// adjust stack buffer index
		}
		else	// All values smaller than 32 bits need to be extended to 32 bit
		{
			bool temp;
			DataIn->unFlatten( &temp );							// get value from flattened data
			uInt32 temp32 = (temp) ? 1 : 0;						// extend to 32 bits and convert to 0 or 1
			memcpy( Param.StackPtr, &temp32, sizeof(uInt32) );	// update our copy with the flattened data
			StackSize += sizeof(uInt32);						// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																			// create object, copy pointer into our buffer
			DataIn->unFlatten( *((boolArray **)Param.StackPtr) = new boolArray );	// update with flattened data
			StackSize += sizeof(boolArray*);										// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			boolArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(boolArray) );	// copy into our buffer
			DataIn->unFlatten( (boolArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(boolArray);							// adjust stack buffer index
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		if( (DataType & DataFilterDir) != DataTypeByVAL )
		{																					// create object, copy pointer into our buffer
			DataIn->unFlatten( *((boolArrayArray **)Param.StackPtr) = new boolArrayArray );	// update with flattened data
			StackSize += sizeof(boolArrayArray*);											// adjust stack buffer index
		}
		else	// Note: default constructor doesn't allocate memory on the heap that is why we get away with the following trick
		{
			boolArrayArray dummy;										// create object on stack
			memcpy( Param.StackPtr, &dummy, sizeof(boolArrayArray) );	// copy into our buffer
			DataIn->unFlatten( (boolArrayArray *)Param.StackPtr );		// update our copy with the flattened data
			StackSize += sizeof(boolArrayArray);						// adjust stack buffer index
		}
	}

	else
		error->SetError( 42, "unFlattenBOOL - Invalid DataType -- 0x%08X", DataType );

	if( !error->Status() )
		ParamInfo.push_back(Param);
}

void IndirectFunctionCallStack::FlattenBOOL( ErrorCluster *error, ParamTrackingInfo &Param )
{
	const int ArrayType = Param.Type & DataFilterSize;

	if( ArrayType == DataTypeNonArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		bool *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (bool *)Param.StackPtr : *((bool **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;		break;
		}
	}

	else if( ArrayType == DataTypeArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		boolArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (boolArray *)Param.StackPtr : *((boolArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;			break;
			case 2 :	ptr->~boolArray();	break;
		}
	}

	else if( ArrayType == DataTypeArrayArray )
	{
		// Get pointer to object, the level of indirection differs by parameter type (see Ptr_Or_PtrToPtr function)
		boolArrayArray *ptr = ( Ptr_Or_PtrToPtr(Param) ) ? (boolArrayArray *)Param.StackPtr : *((boolArrayArray **)Param.StackPtr);

		if( OutputData(error, Param) )	// if parameter is a pointer or the return value of the function
			DataOut->Flatten( *ptr );	// flatten object/value into output stream

		switch( DeleteMethod( Param, ptr ) )	// Determine if and how the allocated memory needs to be released
		{
			case 1 :	delete ptr;					break;
			case 2 :	ptr->~boolArrayArray();		break;
		}
	}

	else
		error->SetError( 42, "FlattenBOOL - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////
///////// Const 'C' String /////////
////////////////////////////////////

void IndirectFunctionCallStack::unFlattenCSTR( ErrorCluster *error, uInt32 DataType )
{
	if( DataType == TypeCStrREF )
	{
		ParamTrackingInfo Param( DataType, CallStack + StackSize );

		TString TempStorage;	// Must be unFlattened into a TString object (no direct support of char*)

		DataIn->unFlatten( &TempStorage );	// unFlatten Data

		*((char **)Param.StackPtr) = new char[TempStorage.Length() + 1];	// create object, copy pointer into our buffer

		strcpy( *((char **)Param.StackPtr), TempStorage );	// update char buffer with data from TString

		StackSize += sizeof(char *);	// adjust stack buffer index

		ParamInfo.push_back(Param);
	}

	else
		error->SetError( 42, "unFlattenCSTR - Invalid DataType -- 0x%08X", DataType );
}

void IndirectFunctionCallStack::FlattenCSTR( ErrorCluster *error, ParamTrackingInfo &Param )
{
	if( Param.Type == TypeCStrREF )	// Only the const char* (by reference in this vernacular) is supported
	{								// thus this function will never return a value but is only call to release memory

		char *ptr = *((char **)Param.StackPtr);

		delete ptr;
	}

	else
		error->SetError( 42, "FlattenCSTR - Invalid DataType -- 0x%08X", Param.Type );
}

////////////////////////////////////

void IndirectFunctionCallStack::FunctionCall( void *IndirectFunction, void *ThisPtr )
{
	char *StackPointer = NULL;
	unsigned char *LocalCallStack = CallStack;
	int LocalStackSize = StackSize;
	int LocalReturnValueType = ReturnValuePassedInRegisters;
	union { struct { uInt32 Reg_EAX; uInt32 Reg_EDX; }; float32 SGL; float64 DBL; unsigned __int64 U64; } Reg;

	// Allocate space on the processer stack
	__asm sub esp, LocalStackSize
	__asm mov DWORD PTR StackPointer, esp

	// Copy our function call stack to the processer stack
	memcpy( StackPointer, CallStack, StackSize );

	// The 'this pointer' is passed in the ecx register (only applies to objects)
	__asm mov ecx, ThisPtr

	// Call the specified function
	__asm call IndirectFunction

	// If return value is returned in EDX:EAX
	__asm cmp  LocalReturnValueType, 1
	__asm jne  IsSGL
	__asm mov  Reg.Reg_EAX, eax
	__asm mov  Reg.Reg_EDX, edx
	__asm jmp  CleanUp

	IsSGL: // If return type is a float32 
	__asm cmp  LocalReturnValueType, 2
	__asm jne  IsDBL
	__asm fstp Reg.SGL
	__asm jmp  CleanUp

	IsDBL: // If return type is a float64 
	__asm cmp  LocalReturnValueType, 3
	__asm jne  CleanUp
	__asm fstp Reg.DBL

	CleanUp: // Clean up the Processor Stack
	__asm add esp, LocalStackSize

	// Set Flag to indicate this function was run
	FunctionCallComplete = true;

	// update function return values in our function stack
	if( ReturnValuePassedInRegisters != 0 )
		*((unsigned _int64 *)(CallStack + StackSize)) = Reg.U64;
}

////////////////////////////////////
