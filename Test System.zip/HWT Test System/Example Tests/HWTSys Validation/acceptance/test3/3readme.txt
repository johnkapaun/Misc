This test is intended to test the case of a properly named VI that is functionally inoperable.

Error in Engine- exit HWTSys