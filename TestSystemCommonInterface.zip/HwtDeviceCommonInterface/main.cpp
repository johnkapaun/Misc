
#include "stdafx.h"
#include "main.h"
#include "ResourceLocks.h"
#include "external\Tversion.h"	// Note: if no longer needed remove version.lib from Library Modules list
#include "resource.h"

///////////////////////////////////////////////////////////////

// Global Variables:
HINSTANCE hInst = NULL;			// current instance
HWND hWnd = NULL;				// main window handle
DWORD MessageLoopThreadID = 0;	// main message thread ID
ProcessLog RefCount;			// Log of Attached Processes
bool InDebugMode = false;		// debug mode flag

// Foward declarations of functions included in this code module:
static void				NotifyIcon(const char *StatusMsg );
static bool				StartServer( void );
static ATOM				MyRegisterClass(HINSTANCE hInstance);
static bool				InitInstance(HINSTANCE, int);
static LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
static LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
static bool				TestCommandLineOptions( LPSTR lpCmdLine );
static TStringArray		ParseCommandLineOptions( ErrorCluster *error, TString OptionString, const TStringArray &SupportedOptions );

//////////////////////////////////////////////////////////////////////

//
//  FUNCTION: NotifyIcon(const char *)
//
//  PURPOSE: Create, Update, or Delete Icon in the notification area
//           of the task bar.
//
//  COMMENTS:
//
//    This function will create or update the Notification Icon if 
//    'StatusMsg' is a non-empty string, or delete the Icon if 'StatusMsg'
//    is an empty string.
//
static void NotifyIcon(const char *StatusMsg )
{
	static NOTIFYICONDATA NotifyInfo;
	static int Initialized = 0;

	// message window was not created or attempting to delete Icon
	// that was never created, just exit
	if( hWnd == NULL || ( *StatusMsg == '\0' && Initialized == 0 ) )
		return;

	if( Initialized == 0 )	// if not initialized
	{
		Initialized = 1;	// set flag to indicate first pass

		memset( &NotifyInfo, 0, sizeof(NotifyInfo) );

		NotifyInfo.cbSize = sizeof(NotifyInfo); 
		NotifyInfo.hWnd = hWnd; 
		NotifyInfo.uID = 0; 
		NotifyInfo.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE; 
		NotifyInfo.uCallbackMessage = WM_NOTIFY_MSG; 
		NotifyInfo.hIcon = LoadIcon(hInst, (LPCTSTR)IDI_SMALL);; 
	}

	// Update Tip string, limit length to 63 bytes (excluding terminating '\')
	strncpy( NotifyInfo.szTip, StatusMsg, 63 );

	// if StatusMsg is empty, remove Icon
	if( *StatusMsg == '\0' )
		Shell_NotifyIcon(NIM_DELETE, &NotifyInfo );

	// if already initialized, just modify string
	else if( Initialized > 1 )
		Shell_NotifyIcon(NIM_MODIFY, &NotifyInfo );

	// if not initialized, create Icon, update 'Initialized' flag
	else
	{
		Shell_NotifyIcon(NIM_ADD, &NotifyInfo );
		Initialized = 2;
	}
}

//
//  FUNCTION: StartServer()
//
//  PURPOSE: Starts the Server Thread.
//
static bool StartServer( void )
{
	unsigned ThreadID = 0;
	HANDLE hThread = NULL;

	hThread = (HANDLE)_beginthreadex( NULL, 0, ServerThread, (LPVOID)NULL, 0, &ThreadID );

	return hThread != NULL;
}

//
//  FUNCTION: LoadUnloadSystemDLLs()
//
//  PURPOSE: Load system or National Instruments DLLs that leak resources
//  and/or memory when loaded and freed repeatedly. By loading the offending
//  DLLs at application start the leaks are avoided.
//
static LoadUnloadSystemDLLs( bool load )
{
//	static HMODULE gpib32_handle = NULL;

//	if( load )
//	{
//		if( gpib32_handle == NULL )
//			LoadLibrary("gpib-32.dll");
//	}
//	else
//	{
//		if( gpib32_handle != NULL )
//			FreeLibrary( gpib32_handle );
//	}
}

//
//  FUNCTION: WinMain()
//
//  PURPOSE: Entry point for Application.
//
//  Process Command-Line Options
//  Register Windows Class
//  Create message only window
//  Create an Icon in the task bar notify area
//  Initializes the COM library
//  Start Server Thread
//  Process Messages until application is closed
//  Close the COM library
//  Remove Icon from the task bar notify area
//
int APIENTRY WinMain(	HINSTANCE hInstance,
						HINSTANCE hPrevInstance,
						LPSTR     lpCmdLine,
						int       nCmdShow)
{
	// if error parsing command-line, bail out	
	if( !TestCommandLineOptions( lpCmdLine ) )
		return - 1;

	MSG msg;

	// Save the Thread ID
	MessageLoopThreadID = GetCurrentThreadId();

	// Register Windows Class
	if( !MyRegisterClass(hInstance) )
		return FALSE;

	// Create message only window
	if (!InitInstance (hInstance, nCmdShow)) 
		return FALSE;

	// Load any system DLLs that leak resource/memory if loaded and freed repeatedly
	LoadUnloadSystemDLLs( true );

	// Create an Icon in the task bar notify area
	NotifyIcon("HWT Device Common Interface");

	// Initializes the COM library
	CoInitializeEx(NULL,COINIT_MULTITHREADED);

	// Start Server Thread
	StartServer();

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	// Close the COM library
	CoUninitialize();

	// Remove Icon from the task bar notify area
	NotifyIcon("");

	// Free any system DLLs loaded to avoid resorce/memory leak
	LoadUnloadSystemDLLs( false );

	return msg.wParam;
}

//
//  FUNCTION: MyRegisterClass(HINSTANCE)
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function registers this application's main window class
//    for subsequent use in InitInstance function
//
static ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	memset( &wcex, 0, sizeof(wcex) );

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= SZAPPNAME;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//	FUNCTION: InitInstance(HANDLE, int)
//
//	PURPOSE: Saves instance handle and creates main window
//
//	COMMENTS:
//
//		In this function, we save the instance handle in a global variable and
//		creates a message only window.
//
static bool InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindow( SZAPPNAME, "", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, HWND_MESSAGE, NULL, hInstance, NULL);

	return (!hWnd) ? false : true;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_DESTROY	    - stops the service
//  WM_SERVICE_EXIT - post a quit message and returns
//  WM_REPORT_ERR   - displays an error message in a MessageBox
//	WM_NOTIFY_MSG   - process Notify Icon messages
//
static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static bool ActiveDialog = false;

	switch (message) 
	{
		case WM_DESTROY:		// Stop the server, the server will send the 'WM_SERVICE_EXIT'
			ServerStop();		// message that will in turn call 'PostQuitMessage' (see next case)
			break;

		case WM_SERVICE_EXIT:	// The Server is shutting down, exit the application
			PostQuitMessage(0);
			break;

		case WM_REPORT_ERR:
			MessageBox( hWnd, (LPCTSTR)lParam, SZAPPDISPLAYNAME, MB_OK | MB_ICONEXCLAMATION );
			break;

		case WM_NOTIFY_MSG:
			switch (lParam)
			{
				case WM_LBUTTONUP:
					if( !ActiveDialog )
					{
						ActiveDialog = true;
						DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
						ActiveDialog = false;
					}
					break;

				case WM_RBUTTONUP:
					CheckForActiveClients();	// Close Application of no active clients
					break;
			}
			break;

		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

//
//  FUNCTION: About(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the 'About' message box.
//
//  WM_INITDIALOG - Updates displayed Text
//  WM_COMMAND    - Closes dialog box
//
static LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				SendDlgItemMessage( hDlg, IDC_EDIT1, WM_SETTEXT, (WPARAM)0, (LPARAM)RefCount.ProcessReport().CStr() );
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
	return FALSE;
}

///////////////////////////////////////////////////////////////////////////////

//
//  FUNCTION: AttachCurrentThreadToMessageThread(void)
//
//  PURPOSE:  Attach the current thread to the application's main message thread.
//
//	COMMENTS:
//
//      Windows created in different threads typically process input independently
//      of each other. That is, they have their own input states (focus, active,
//      capture windows, key state, queue status, and so on), and they are not
//      synchronized with the input processing of other threads. By using the Windows
//      API function AttachThreadInput function, a thread can attach its input
//      processing to another thread. This also allows threads to share their input states,
//      so they can call the SetFocus function to set the keyboard focus to a window of a
//      different thread. This also allows threads to get key-state information.
//      These capabilities are not generally possible.
//
void AttachCurrentThreadToMessageThread(void)
{
	if( AttachThreadInput( GetCurrentThreadId(), MessageLoopThreadID, TRUE ) == 0 )
		MessageBox(NULL, "Thread Attached Failed", "AttachCurrentThreadToMessageThread", MB_OK );
}

//
//  FUNCTION: DetachCurrentThreadFromMessageThread(void)
//
//  PURPOSE:  Detach the current thread from the application's main message thread.
//
//	COMMENTS:
//
//      See the 'AttachCurrentThreadToMessageThread' function
//
void DetachCurrentThreadFromMessageThread(void)
{
	if( AttachThreadInput( GetCurrentThreadId(), MessageLoopThreadID, FALSE ) == 0 )
		MessageBox(NULL, "Thread Detach Failed", "DetachCurrentThreadFromMessageThread", MB_OK );
}

//
//  FUNCTION: CheckForActiveClients(void)
//
//  PURPOSE:  Check for Active Clients, and stop the server if none
//
void CheckForActiveClients(void)
{
	if( RefCount.ActiveClients() == 0 )
	{
		ErrorCluster Err;

		ApplicationResourceLock Lock( &Err );	// Ignore Error

		if( RefCount.ActiveClients() == 0 )
			RpcMgmtStopServerListening(0);
	}
}

///////////////////////////////////////////////////////////////////////////////

//
//  FUNCTION: ReleasedInterfacePath(ErrorCluster *error)
//
//  PURPOSE:  This function returns the file path to the released Interface Libraries
//
TString ReleasedInterfacePath(ErrorCluster *error)
{
	// The current 'rsc_dev.rsc' file does not include a field for this path
	// Use the 'ReleasedDllPath' and replace the last part of the path with 'Interface'.
	TString Path = ReleasedDllPath(error);

	// If path starts with ".\" -- assume path is relative to this application
	if( Path[0] == '.' && Path[1] == '\\' )
		Path =  RemoveFileNameFromPath(CommonInterface_FileName(true)) + (Path.CStr() + 2);

	Path.TrimRight("\\");

	return RemoveFileNameFromPath( Path ) + "Interface\\";
}

//
//  FUNCTION: LocalInterfacePath(ErrorCluster *error)
//
//  PURPOSE:  This function returns the file path to the local copies of Interface Libraries
//
TString LocalInterfacePath(ErrorCluster *error)
{
	// The current 'rsc_dev.rsc' file does not include a field for this path
	// Use the 'LocalDllPath' and replace the last part of the path with 'Interface'.
	TString Path = LocalDllPath(error);

	// If path starts with ".\" -- assume path is relative to this application
	if( Path[0] == '.' && Path[1] == '\\' )
		Path =  RemoveFileNameFromPath(CommonInterface_FileName(true)) + (Path.CStr() + 2);

	Path.TrimRight("\\");

	return RemoveFileNameFromPath( Path ) + "Interface\\";
}

//
//  FUNCTION: CommonInterface_FileName(bool IncludePath)
//
//  PURPOSE:  If IncludePath is false this function returns the file name of this application (HwtDeviceCommonInterface).
//            If IncludePath is true this function returns the Path\FileName of this application.
//
TString CommonInterface_FileName(bool IncludePath)
{
	char Path[_MAX_PATH + 1];

	DWORD PathLength = GetModuleFileName( NULL, Path, _MAX_PATH );
	Path[PathLength] = '\0';

	if( IncludePath )
		return Path;
	else
		return RemovePathFromFileName( Path );
}

//
//  FUNCTION: VerifyHwtDeviceCommonInterface(ErrorCluster *error)
//
//  PURPOSE:  This function compares the version of this application (HwtDeviceCommonInterface) to the master version.
//            Depending on the result of this comparison the ErrorCluster error will be updated with the information listed below.
//            The returned TString is empty if error->status is true or the versions match and are released;
//            otherwise a description of the comparison is returned.
//
// =====================================================================================================================================================//
// Result of Comparison                   | error->status  | error->code | error->source                                                                //
// =====================================================================================================================================================//
// Loaded Version info not found          | true           |     15      | Unable to read Application Version Information from                          //
//                                        |                |             | 'PATH\HwtDeviceCommonInterface.exe'                                          //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
// Master file or version info not found  | false          |      1      | Unable to Verify Version of 'HwtDeviceCommonInterface.exe'                   //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
// Versions do not match                  | false          |      2      | HWT Device Common Interface 'HwtDeviceCommonInterface.exe' Version Conflict! //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
// Version numbers match but local copy   |                |             | HWT Device Common Interface 'HwtDeviceCommonInterface.exe' is a              //
// is a is Pre Release, Private or        | false          |      3      | <Pre-Release,Private,Special> Version!                                       //
// Special Version                        |                |             |                                                                              //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
// Application is running in debug mode   | false          |      4      | 'HwtDeviceCommonInterface.exe' is running in Debug Mode                      //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
// Versions match and are released        | false          | unchanged   | Unchanged                                                                    //
// -----------------------------------------------------------------------------------------------------------------------------------------------------//
//
TString VerifyHwtDeviceCommonInterface( ErrorCluster *error )
{
	if( error->Status() )
		return "";

	const char *AppName = "HwtDeviceCommonInterface.exe";

	TString Msg;

	TString Path = CommonInterface_FileName(true);						// Determine file path of this application
	FileVersionInfo LocalAPP(Path);										// Load Version Information of loaded APP
	FileVersionInfo ReleasedAPP(ReleasedInterfacePath() + AppName );	// Load Version Information of Currently Released APP

	if( !LocalAPP.Valid() )
	{
		error->SetError( 15, "Unable to read Application Version Information from '%s'\n", Path.CStr() );
	}
	else if( InDebugMode )
	{
		error->SetWarning( 4, "'%s' is running in Debug Mode", AppName );
		Msg.Format( "Warning!!!     '%s' is running in Debug Mode", AppName );
	}
	else if( !ReleasedAPP.Valid() )
	{
		error->SetWarning( 1, "Unable to Verify Version of '%s'", AppName );

		Msg.Format( "Warning!!!     Unable to Verify Version of '%s'\n\n"
					"Released Version = 'Unknown'\n"
					"Local Version = '%s' %s", AppName,
					LocalAPP.QueryValue("FileVersion").CStr(), LocalAPP.FlagString().CStr() );
	}
	else if( LocalAPP.FixedFileVersion != ReleasedAPP.FixedFileVersion )
	{
		error->SetWarning( 2, "HWT Device Common Interface '%s' Version Conflict!", AppName );

		Msg.Format( "Warning!!!     '%s'  Version Conflict!\n\n"
					"Released Version = '%s'\n"
					"Local Version = '%s' %s", AppName,
					ReleasedAPP.QueryValue("FileVersion").CStr(),
					LocalAPP.QueryValue("FileVersion").CStr(), LocalAPP.FlagString().CStr() );
	}
	else if( LocalAPP.FileFlags & ( VS_FF_PRERELEASE | VS_FF_PRIVATEBUILD | VS_FF_SPECIALBUILD ) )
	{
		error->SetWarning( 3, "HWT Device Common Interface '%s' is a %s Version!", AppName, LocalAPP.FlagString(false).CStr() );
		Msg.Format( "Warning!!!    HWT Device Common Interface\n'%s'\nis a %s Version", AppName, LocalAPP.FlagString(false).CStr() );
	}
	return Msg;
}

//
//  FUNCTION: VerifyAppInterfaceVersions(ErrorCluster *error)
//
//  PURPOSE:  This function compares the version of the Interface Libraries of all current Clients to the master version.
//            The returned TString is empty if all Interface versions match and are released;
//            otherwise a description of the comparison is returned.
//
TString VerifyAppInterfaceVersions( ErrorCluster *error )
{
	TStringArray Interfaces = RefCount.InterfaceList( error );

	if( error->Status() )
		return "";

	TString CompleteMessage;

	for( int i = 0; i < Interfaces.GetSize(); i ++ )
	{
		TString InterfaceFilename = RemovePathFromFileName(Interfaces[i]);				// Determine file path of this application
		FileVersionInfo LocalInterface(Interfaces[i]);									// Load Version Information of loaded Interface
		FileVersionInfo ReleasedInterface(ReleasedInterfacePath() + InterfaceFilename );// Load Version Information of Currently Released Interface
		TString Msg;

		if( !LocalInterface.Valid() )
		{
			error->SetError( 15, "Unable to read Version Information from '%s'\n", InterfaceFilename.CStr() );
		}
		else if( !ReleasedInterface.Valid() )
		{
			Msg.Format( "Warning!!!     Unable to Verify Version of '%s'\n\n"
						"Released Version = 'Unknown'\n"
						"Local Version = '%s' %s", InterfaceFilename.CStr(),
						LocalInterface.QueryValue("FileVersion").CStr(), LocalInterface.FlagString().CStr() );
		}
		else if( LocalInterface.FixedFileVersion != ReleasedInterface.FixedFileVersion )
		{
			Msg.Format( "Warning!!!     '%s'  Version Conflict!\n\n"
						"Released Version = '%s'\n"
						"Local Version = '%s' %s", InterfaceFilename.CStr(),
						ReleasedInterface.QueryValue("FileVersion").CStr(),
						LocalInterface.QueryValue("FileVersion").CStr(), LocalInterface.FlagString().CStr() );
		}
		else if( LocalInterface.FileFlags & ( VS_FF_PRERELEASE | VS_FF_PRIVATEBUILD | VS_FF_SPECIALBUILD ) )
		{
			Msg.Format( "Warning!!!    Interface '%s' is a %s Version", InterfaceFilename.CStr(), LocalInterface.FlagString(false).CStr() );
		}

		if( !Msg.IsEmpty() )
			CompleteMessage += Msg + "\n\n";
	}

	if( !CompleteMessage.IsEmpty() )
		error->SetWarning( 42, "Not all Application Interfaces are up to date and released" );

	return CompleteMessage;
}

///////////////////////////////////////////////////////////////////////////////

// This function checks command line options the passed to the application at startup
// The only supported option at this time is '/debug' with no parameters ( no : )
static bool TestCommandLineOptions( LPSTR lpCmdLine )
{
	ErrorCluster Err;

	TStringArray Options = ParseCommandLineOptions( &Err, lpCmdLine, TStringArray( 1, "debug" ) );

	if( Err.Status() || ( !Options[0].IsEmpty() && stricmp( Options[0], "Default" ) != 0 ) )
	{
		MessageBox(NULL, "Invalid Command Line", "HwtDeviceCommonInterface", MB_OK );
		return false;
	}

	InDebugMode = ( Options[0].IsEmpty() )	? false : true;

	return true;
}


// This function is intended to parse a string containing the command line options
//
// The function takes three arquments:
//		A pointer to a ErrorCluster.
//		A TString containing the options
//		A TString array containing the supported options
// The function returns a TStringArray the same size as the SupportedOptions array
// containing a non-empty string for each option specified in the OptionString.
// If an option is specified more than once in OptionString, the last value will be returned.
// If an option in OptionString in not contained in SupportedOptions, an error will be returned.
// The expected format of OptionString is: /Option1:Value1 /Option2:Value2

static TStringArray ParseCommandLineOptions( ErrorCluster *error, TString OptionString, const TStringArray &SupportedOptions )
{
	OptionString.Trim();

	TStringArray ReturnedOptionValues( SupportedOptions.GetSize() );

	if( error->Status() || OptionString.IsEmpty() )
		return ReturnedOptionValues;

	char *Buffer = new char[OptionString.Length() + 1];
	char *Option = new char[OptionString.Length() + 1];
	char *Value  = new char[OptionString.Length() + 1];
	char *ptr;

	strcpy( Buffer, OptionString );

	// Parse Option string by the '/' char
	for( int i = 0; (ptr = strtok( (i==0) ? Buffer : NULL, "/") ) != NULL; i++ )
	{
		// Empty Strings
		Option[0] = '\0';
		Value[0] = '\0';

		// Parse Option Name and Value
		sscanf( ptr, " %[^:]: %[^|]", Option, Value );

		// Remove trailing white spaces from option name
		for( char *ptr2 = Option + strlen(Option) - 1; ptr2 > Option && isspace(*ptr2); ptr2-- )
			*ptr2 = '\0';

		// try to match option in string to ValidOption
		for( int ii = SupportedOptions.GetUpperBound(); ii >= 0 && stricmp(Option, SupportedOptions[ii]) != 0; ii-- )
			;
		if( ii < 0 )
			error->SetError( 42, "Command Line Option '%s' is Invalid", Option );
		else if( Value[0] == '\0' )
			ReturnedOptionValues[ii] = "Default";
		else
			ReturnedOptionValues[ii] = Value;
	}
	// remove leading and trailing white spaces from Option Values
	for( i = ReturnedOptionValues.GetUpperBound(); i >= 0; i-- )
		ReturnedOptionValues[i].Trim();

	delete [] Buffer;
	delete [] Option;
	delete [] Value;

	return ReturnedOptionValues;
}
