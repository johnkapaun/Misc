
enum DebugTextColor {	BLACK  = 0x00000000,
						RED    = 0x000000FF,
						GREEN  = 0x00008000,
						BLUE   = 0x00FF0000,
						VIOLET = 0x00FF00FF,
						YELLOW = 0x0080FFFF,
						ORANGE = 0x004080FF,
						GRAY   = 0x00C0C0C0,
						LIGHT_GREEN = 0x0080FF00,
						LIGHT_BLUE  = 0x00FFFF80
};

class DebugToolsControllerObject
{
    public:

		virtual void PrintMessage(ErrorCluster *error, const char *Message ) = 0;

		virtual void Write( const char *str, DebugTextColor Color = BLACK ) = 0;
		virtual void Write( const ErrorCluster *error ) = 0;
		virtual void Writef(DebugTextColor Color, const char *format, ... ) = 0;

		virtual void ClearDisplay( ErrorCluster *error = NULL ) = 0;
		virtual void ReadDisplay( ErrorCluster *error, const char *Format, TString *Contents ) = 0;

		// Reserved
		virtual void Reserved1( ErrorCluster *error ) = 0;
		virtual void Reserved2( ErrorCluster *error ) = 0;
		virtual void Reserved3( ErrorCluster *error ) = 0;
};

// Define function contained in crm_dev.dll 
CRM_DEV_API DebugToolsControllerObject* DebugToolsObject(ErrorCluster *error = NULL);
