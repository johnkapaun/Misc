﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEquipment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEquipment))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.DGVcnfg = New System.Windows.Forms.DataGridView
        Me.ConfigStuff = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnDeleteRow = New System.Windows.Forms.Button
        Me.btnBlankRow = New System.Windows.Forms.Button
        Me.DGV = New System.Windows.Forms.DataGridView
        Me.Description = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EquipmentNumber = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.CalDueDate = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Manufacturer = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnUp = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnDown = New System.Windows.Forms.Button
        Me.btnOK = New System.Windows.Forms.Button
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.DGVcnfg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.DGVcnfg)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnDeleteRow)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnBlankRow)
        Me.SplitContainer1.Panel2.Controls.Add(Me.DGV)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label6)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label7)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnUp)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label5)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnDown)
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnOK)
        Me.SplitContainer1.Size = New System.Drawing.Size(908, 578)
        Me.SplitContainer1.SplitterDistance = 192
        Me.SplitContainer1.TabIndex = 26
        '
        'DGVcnfg
        '
        Me.DGVcnfg.AllowUserToAddRows = False
        Me.DGVcnfg.AllowUserToDeleteRows = False
        Me.DGVcnfg.AllowUserToResizeRows = False
        Me.DGVcnfg.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        Me.DGVcnfg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVcnfg.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ConfigStuff})
        Me.DGVcnfg.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGVcnfg.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DGVcnfg.Enabled = False
        Me.DGVcnfg.Location = New System.Drawing.Point(0, 0)
        Me.DGVcnfg.MultiSelect = False
        Me.DGVcnfg.Name = "DGVcnfg"
        Me.DGVcnfg.ReadOnly = True
        Me.DGVcnfg.RowHeadersVisible = False
        Me.DGVcnfg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.ColumnHeaderSelect
        Me.DGVcnfg.Size = New System.Drawing.Size(192, 578)
        Me.DGVcnfg.TabIndex = 12
        '
        'ConfigStuff
        '
        Me.ConfigStuff.HeaderText = "Equipment"
        Me.ConfigStuff.Name = "ConfigStuff"
        Me.ConfigStuff.ReadOnly = True
        Me.ConfigStuff.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ConfigStuff.Width = 750
        '
        'btnDeleteRow
        '
        Me.btnDeleteRow.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnDeleteRow.Image = CType(resources.GetObject("btnDeleteRow.Image"), System.Drawing.Image)
        Me.btnDeleteRow.Location = New System.Drawing.Point(633, 190)
        Me.btnDeleteRow.Name = "btnDeleteRow"
        Me.btnDeleteRow.Size = New System.Drawing.Size(45, 45)
        Me.btnDeleteRow.TabIndex = 30
        Me.ToolTip1.SetToolTip(Me.btnDeleteRow, "delete row")
        Me.btnDeleteRow.UseVisualStyleBackColor = True
        '
        'btnBlankRow
        '
        Me.btnBlankRow.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnBlankRow.Image = CType(resources.GetObject("btnBlankRow.Image"), System.Drawing.Image)
        Me.btnBlankRow.Location = New System.Drawing.Point(633, 130)
        Me.btnBlankRow.Name = "btnBlankRow"
        Me.btnBlankRow.Size = New System.Drawing.Size(45, 45)
        Me.btnBlankRow.TabIndex = 29
        Me.ToolTip1.SetToolTip(Me.btnBlankRow, "add row")
        Me.btnBlankRow.UseVisualStyleBackColor = True
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.AllowUserToDeleteRows = False
        Me.DGV.AllowUserToResizeRows = False
        Me.DGV.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Description, Me.EquipmentNumber, Me.CalDueDate, Me.Manufacturer})
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DGV.DefaultCellStyle = DataGridViewCellStyle1
        Me.DGV.Location = New System.Drawing.Point(2, 0)
        Me.DGV.MultiSelect = False
        Me.DGV.Name = "DGV"
        Me.DGV.ReadOnly = True
        Me.DGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGV.Size = New System.Drawing.Size(628, 578)
        Me.DGV.TabIndex = 9
        '
        'Description
        '
        Me.Description.HeaderText = "Description"
        Me.Description.Name = "Description"
        Me.Description.ReadOnly = True
        Me.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Description.Width = 300
        '
        'EquipmentNumber
        '
        Me.EquipmentNumber.HeaderText = "Equipment #"
        Me.EquipmentNumber.Name = "EquipmentNumber"
        Me.EquipmentNumber.ReadOnly = True
        Me.EquipmentNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.EquipmentNumber.Width = 200
        '
        'CalDueDate
        '
        Me.CalDueDate.HeaderText = "Cal Due Date"
        Me.CalDueDate.Name = "CalDueDate"
        Me.CalDueDate.ReadOnly = True
        Me.CalDueDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.CalDueDate.Width = 200
        '
        'Manufacturer
        '
        Me.Manufacturer.HeaderText = "Manufacturer"
        Me.Manufacturer.Name = "Manufacturer"
        Me.Manufacturer.ReadOnly = True
        Me.Manufacturer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Manufacturer.Width = 300
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.BackColor = System.Drawing.Color.Yellow
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Location = New System.Drawing.Point(633, 41)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 32)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Due in 30 days or less"
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.BackColor = System.Drawing.Color.Red
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(633, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 32)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Past due/Not in the system"
        '
        'btnUp
        '
        Me.btnUp.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnUp.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnUp.Image = CType(resources.GetObject("btnUp.Image"), System.Drawing.Image)
        Me.btnUp.Location = New System.Drawing.Point(633, 250)
        Me.btnUp.Name = "btnUp"
        Me.btnUp.Size = New System.Drawing.Size(45, 45)
        Me.btnUp.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.btnUp, "move row up")
        Me.btnUp.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.BackColor = System.Drawing.Color.LimeGreen
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Location = New System.Drawing.Point(633, 73)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 32)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Not Due for at least 31 days"
        '
        'btnDown
        '
        Me.btnDown.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.btnDown.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.btnDown.Image = CType(resources.GetObject("btnDown.Image"), System.Drawing.Image)
        Me.btnDown.Location = New System.Drawing.Point(633, 310)
        Me.btnDown.Name = "btnDown"
        Me.btnDown.Size = New System.Drawing.Size(45, 45)
        Me.btnDown.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.btnDown, "move row down")
        Me.btnDown.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(633, 552)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(76, 23)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'frmEquipment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 578)
        Me.Controls.Add(Me.SplitContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(600, 600)
        Me.Name = "frmEquipment"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Scan Equipment"
        Me.TopMost = True
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.DGVcnfg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Private WithEvents DGVcnfg As System.Windows.Forms.DataGridView
    Private WithEvents DGV As System.Windows.Forms.DataGridView
    Private WithEvents btnUp As System.Windows.Forms.Button
    Private WithEvents btnDown As System.Windows.Forms.Button
    Private WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnBlankRow As System.Windows.Forms.Button
    Friend WithEvents btnDeleteRow As System.Windows.Forms.Button
    Friend WithEvents ConfigStuff As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EquipmentNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CalDueDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Manufacturer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
