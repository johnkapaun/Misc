﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OracleClient;
using System.Runtime.InteropServices;
using System.IO;

// TABLE - EQ_SCHED_ALL_DEPT
/////////////////////////////////////////////////////
// PROP_NUM  SCHED_TYPE  FREQ  INTERVAL  DUE_DATE ///
/////////////////////////////////////////////////////

// Table - EQUIP_ALL_DEPT
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// PROP_NUM  ISACTIVE  MISSING  WARN_NOT_CALD  SPEC_CAL  NCR  MANUFACTURER  MODEL_NUM  DESCRIPTION  SERIAL_NUM  DEPARTMENT  TRACKING_STATUS  IN_SERVICE  LOCATION  SUB_LOCATION  VENDOR_CAL  SERVICED_BY //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace EquipmentBarcodeScanner
{


    internal partial class frmMain : Form
    {
        internal frmMain()
        {
            InitializeComponent();
        }

        #region disable the close 'x' button
        const int MF_BYPOSITION = 0x400;

        [DllImport("User32")]
        private static extern int RemoveMenu(IntPtr hMenu, int nPosition, int wFlags);

        [DllImport("User32")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("User32")]
        private static extern int GetMenuItemCount(IntPtr hWnd);

        #endregion

        #region internal (public) members

        internal string EnteredEquipment
        {
            get { return g_strEnteredEquipment; }
        }

        internal string ConfigFileEquipment
        {
            set { g_strConfigFileEquipment = value; }
        }

        internal string TestExecutor
        {
            set { g_strTestExecutor = value; }
        }

        internal string TestName
        {
            set { g_strTestName = value; }
        }

        internal string InitialEquipment
        {
            set { g_strInitialEquipment = value; }
        }

        #endregion

        #region private members used to set/get properties
        private string g_strEnteredEquipment = "";
        private string g_strConfigFileEquipment = "";
        private string g_strWorkstationID;
        private string g_strTestExecutor = "";
        private string g_strTestName = "";
        private string g_strInitialEquipment = "";
        #endregion

        #region database connections
        private OracleConnection g_MNdbConnection = new OracleConnection(
            "Data Source=PGAGECLB.PACE.MEDTRONIC.COM;Persist Security Info=True;User ID=Siteadmin_user;Password=readonly4prd;Unicode=True");
        private OracleConnection g_AZdbConnection = new OracleConnection(
            "Data Source=indy.tmp.medtronic.com;Persist Security Info=True;User ID=indyrpt;Password=reporting1;Unicode=True");
        #endregion

        #region private members (globals)
        private List<string> g_lstAllAvailableEquipment = new List<string>();
        private List<string> g_lstEquipNumPieces = new List<string>(); // used to collect equip num pieces
        private Boolean g_IsTime1Null = true;
        private DateTime g_Time1;
        private DateTime g_Time2;
        private TimeSpan g_Span;
        #endregion

        #region Constants
        private const String PAST_DUE_FOR_CALIBRATION = "Past due for calibration";
        private const String OUT_OF_DEPARTMENT = "Out of department";
        private const String NO_CALIBRATION_DATE = "Missing calibration date";
        private const String CALIBRATION_NOT_REQUIRED = "Calibration not required";
        private const String INVALID = "Invalid equipment number";
        private const String DUE_IN_30_DAYS = "Due in 30 days or less";
        private const String GOOD = "Good";
        private const string AZOWNER = "indyadmin.";
        private const string MNOWNER = "siteadmin.";
        #endregion

        #region Database stuff

        private void openDbConnections()
        {
            try
            {
                if (g_MNdbConnection.State != ConnectionState.Open)
                    g_MNdbConnection.Open();
                if (g_AZdbConnection.State != ConnectionState.Open)
                    g_AZdbConnection.Open();
            }

            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private bool isIn150165(string strEquipNum)
        {
            // check in/out department only if it's being used in MN\MV\ESD
            // if it's some other department return true so that rows don't get highlighted
            // for out of dept equipment
            if (!g_strWorkstationID.ToUpper().StartsWith("CRM-HWT-"))
                return true;
            //
            //
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            try
            {
                strSQL = "SELECT  PROP_NUM FROM " + MNOWNER + "EQUIP_ALL_DEPT " +
                                    "WHERE  PROP_NUM = '" + strEquipNum + "' and " +
                                    "DEPARTMENT = '150165'";
                //
                if (g_MNdbConnection.State != ConnectionState.Open)
                    g_MNdbConnection.Open();
                //
                DA = new OracleDataAdapter(strSQL, g_MNdbConnection);
                DT = new DataTable();
                DA.Fill(DT);
                //
                if (DT.Rows.Count == 0)
                    return false;
                else
                    return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return false;
            }
        }

        private string existInWhichDatabase(string strEquipNum)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;

            try
            {
                strSQL = "SELECT  PROP_NUM FROM " + MNOWNER + "EQUIP_ALL_DEPT " +
                    "WHERE  PROP_NUM = '" + strEquipNum + "' ";
                //
                if (g_MNdbConnection.State != ConnectionState.Open)
                    g_MNdbConnection.Open();
                //
                DA = new OracleDataAdapter(strSQL, g_MNdbConnection);
                DT = new DataTable();
                DA.Fill(DT);
                //
                if (DT.Rows.Count == 0)
                {
                    strSQL = "SELECT  PROP_NUM FROM " + AZOWNER + "EQUIP_ALL_DEPT " +
                       "WHERE  PROP_NUM = '" + strEquipNum + "' ";
                    if (g_AZdbConnection.State != ConnectionState.Open)
                        g_AZdbConnection.Open(); ;
                    //
                    DA = new OracleDataAdapter(strSQL, g_AZdbConnection);
                    DT = new DataTable();
                    DA.Fill(DT);
                    //
                    if (DT.Rows.Count == 0)
                        return "";
                    else
                        return "AZ";

                }
                else
                    return "MN";
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return "";
            }
        }

        private bool isCalibrationRequired(string strEquipNum, OracleConnection conn, string strViewOwner)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            int intNCR;
            int intWARN_NOT_CALD;
            try
            {
                strSQL = "SELECT  NCR,WARN_NOT_CALD FROM " + strViewOwner + "EQUIP_ALL_DEPT " +
                                    "WHERE  PROP_NUM = '" + strEquipNum + "' ";
                //
                //
                DA = new OracleDataAdapter(strSQL, conn);
                DT = new DataTable();
                DA.Fill(DT);
                //
                //
                intWARN_NOT_CALD = Convert.ToInt32(DT.Rows[0]["WARN_NOT_CALD"].ToString());
                intNCR = Convert.ToInt32(DT.Rows[0]["NCR"].ToString());
                //
                if (intNCR == 0 && intWARN_NOT_CALD == 0)
                    return true;
                else
                    return false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return false;
            }
        }

        private string getDescription(string strEquipmentNumber, OracleConnection conn, string strViewOwner)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            try
            {
                strSQL = "SELECT  DESCRIPTION FROM " + strViewOwner + "EQUIP_ALL_DEPT " +
                                    "WHERE  PROP_NUM = '" + strEquipmentNumber + "' ";
                //
                //
                DA = new OracleDataAdapter(strSQL, conn);
                DT = new DataTable();
                //
                DA.Fill(DT);
                if (DT.Rows.Count == 0)
                    return "";
                else
                    return DT.Rows[0][0].ToString().Replace(";", ",");
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return "";
            }
        }

        private string getCalibrationDueDate(string strEquipmentNumber, OracleConnection conn, string strViewOwner)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            string strCalDueDate = "";
            DateTime equipDate;
            try
            {
                strSQL = "SELECT  DUE_DATE,SCHED_TYPE FROM " + strViewOwner + "EQ_SCHED_ALL_DEPT " +
                                     "WHERE  PROP_NUM = '" + strEquipmentNumber + "' " +
                                     "ORDER BY DUE_DATE ASC ";
                //
                DA = new OracleDataAdapter(strSQL, conn);
                DT = new DataTable();
                //
                DA.Fill(DT);

                if (DT.Rows.Count > 0)
                {
                    for (int i = 0; String.IsNullOrEmpty(strCalDueDate) && i < DT.Rows.Count; i++)
                    {
                        if (String.Compare(DT.Rows[i][1].ToString(), "CALIBRATION", true) == 0)
                            strCalDueDate = DT.Rows[i][0].ToString();
                    }

                    for (int i = 0; String.IsNullOrEmpty(strCalDueDate) && i < DT.Rows.Count; i++)
                    {
                        if (String.Compare(DT.Rows[i][1].ToString(), "PM INSPECTION", true) == 0)
                            strCalDueDate = DT.Rows[i][0].ToString();
                    }
                }

                //
                // format (cosmetic)
                if (DateTime.TryParse(strCalDueDate, out equipDate))
                    strCalDueDate = equipDate.ToString("ddMMMyyyy");
                //
                return strCalDueDate;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return "";
            }

        }

        private string getManufacturer(string strEquipmentNumber, OracleConnection conn, string strViewOwner)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            try
            {
                strSQL = "SELECT  MANUFACTURER FROM " + strViewOwner + "EQUIP_ALL_DEPT " +
                        "WHERE  PROP_NUM = '" + strEquipmentNumber + "' ";
                //
                DA = new OracleDataAdapter(strSQL, conn);
                DT = new DataTable();
                //
                DA.Fill(DT);
                if (DT.Rows.Count == 0)
                    return "";
                else
                    return DT.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return "";
            }

        }

        private string getDepartment(string strEquipNum, OracleConnection conn, string strViewOwner)
        {
            string strSQL;
            OracleDataAdapter DA;
            DataTable DT;
            try
            {
                strSQL = "SELECT  department FROM " + strViewOwner + "EQUIP_ALL_DEPT " +
                                    "WHERE  PROP_NUM = '" + strEquipNum + "' ";
                //
                //if (g_MNdbConnection.State != ConnectionState.Open)
                //    openDbConnections();
                //
                DA = new OracleDataAdapter(strSQL, conn);
                DT = new DataTable();
                DA.Fill(DT);

                if (DT.Rows.Count == 0)
                    return "";
                else
                    return DT.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return "an exception occurred while getting department";
            }

        }

        private List<String> getAllEquipment()
        {
            OracleDataAdapter DA;
            DataTable DT;
            List<String> lstEquipNums = new List<string>();
            try
            {
                DA = new OracleDataAdapter("select prop_num from " + MNOWNER + "EQUIP_ALL_DEPT", g_MNdbConnection);
                DT = new DataTable();
                DA.Fill(DT);
                //
                for (int i = 0; i < DT.Rows.Count; i++)
                    lstEquipNums.Add(DT.Rows[i][0].ToString());
                //
                DA = new OracleDataAdapter("select prop_num from " + AZOWNER + "EQUIP_ALL_DEPT", g_AZdbConnection);
                DT = new DataTable();
                DA.Fill(DT);
                //
                for (int i = 0; i < DT.Rows.Count; i++)
                    lstEquipNums.Add(DT.Rows[i][0].ToString());

                return lstEquipNums;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return new List<string>();
            }
        }

        #endregion

        #region main form load

        private void frmMain_Load(object sender, EventArgs e)
        {
            int menuItemCount;
            List<string> lstInitialEquipment;
            List<string> lstConfigEquipment;

            try
            {
                this.Text = "Scan Equipment";
                g_strWorkstationID = System.Net.Dns.GetHostName();
                // disable the close 'x' button
                IntPtr hMenu = GetSystemMenu(this.Handle, false);
                menuItemCount = GetMenuItemCount(hMenu);
                RemoveMenu(hMenu, menuItemCount - 1, MF_BYPOSITION);
                //
                // get the config equipment items from the passed string
                lstConfigEquipment = new List<string>();
                lstConfigEquipment.AddRange(g_strConfigFileEquipment.Split(new string[] { ";" }, StringSplitOptions.None));
                //
                // add the config equipment
                for (int i = 0; i < lstConfigEquipment.Count; i++)
                    dgvConfigEquipment.Rows.Add(new object[] { lstConfigEquipment[i] });
                //
                // Add the initial equipment
                if (g_strInitialEquipment.Trim().Length > 0)
                {
                    // split on the rows
                    lstInitialEquipment = new List<string>();
                    lstInitialEquipment.AddRange(g_strInitialEquipment.Split(new string[] { ";" }, StringSplitOptions.None));
                    //
                    for (int i = 0; i < lstInitialEquipment.Count; i++)
                        equipmentScanned(lstInitialEquipment[i]);

                }
                //
                // 
                openDbConnections();
                //
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        #endregion

        #region move row up/down
        private void btnUp_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDbEquipment.RowCount == 0 || dgvDbEquipment.SelectedRows.Count == 0)
                    return;
                //
                int intSelectedRow = dgvDbEquipment.SelectedRows[0].Index;
                int intI;
                //
                if (intSelectedRow == 0)
                    return;
                //
                dgvDbEquipment.Rows.Insert(intSelectedRow - 1);
                //
                for (intI = 0; intI < dgvDbEquipment.Columns.Count; intI++)
                    dgvDbEquipment[intI, intSelectedRow - 1].Value =
                        dgvDbEquipment[intI, intSelectedRow + 1].Value;

                //
                dgvDbEquipment.Rows.RemoveAt(intSelectedRow + 1);
                //
                dgvDbEquipment.CurrentCell = null;
                dgvDbEquipment.Rows[intSelectedRow - 1].Selected = true;
                //
                ColorDGVRows();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }




        private void btnDown_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDbEquipment.RowCount <= 0 || dgvDbEquipment.SelectedRows.Count == 0)
                    return;

                int intSelectedRow = dgvDbEquipment.SelectedRows[0].Index;

                //
                if (intSelectedRow == dgvDbEquipment.Rows.Count - 1)
                    return;

                //
                dgvDbEquipment.Rows.Insert(intSelectedRow);
                //

                for (int i = 0; i < dgvDbEquipment.Columns.Count; i++)
                {
                    dgvDbEquipment[i, intSelectedRow].Value = dgvDbEquipment[i, intSelectedRow + 2].Value;
                }
                //
                dgvDbEquipment.Rows.RemoveAt(intSelectedRow + 2);
                //
                dgvDbEquipment.CurrentCell = null;
                dgvDbEquipment.Rows[intSelectedRow + 1].Selected = true;
                //
                ColorDGVRows();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }
        #endregion

        #region key down




        private void frmMain_KeyDown(object sender, KeyEventArgs e)
        {
            KeysConverter k = new KeysConverter();
            String strItem;
            int intI;
            // see if this is really the first this that happens when a key is down
            dgvDbEquipment.Focus();
            //
            if (e.KeyCode == Keys.Delete)
            {
                deleteSelectedRow();
                return;
            }
            //

            try
            {
                if (g_IsTime1Null == true)
                {
                    g_IsTime1Null = false;
                    g_Time1 = DateTime.Now;
                    g_lstEquipNumPieces = new List<string>();
                    g_lstEquipNumPieces.Add(k.ConvertToString(e.KeyData));
                }
                else
                {
                    g_Time2 = DateTime.Now;
                    g_Span = g_Time2.Subtract(g_Time1);
                    //
                    if (g_Span.TotalMilliseconds < 60)
                    {
                        if (e.KeyCode == Keys.Enter)
                        {
                            // -----------------------------------------------------------------------*
                            // Remove non-printing keypresses 
                            // -----------------------------------------------------------------------*
                            intI = 0;
                            while (intI < g_lstEquipNumPieces.Count)
                            {
                                if (g_lstEquipNumPieces[intI].ToString() == "Shift+ShiftKey")
                                    g_lstEquipNumPieces.RemoveAt(intI);
                                else
                                    intI += 1;

                            }
                            // -----------------------------------------------------------------------*
                            // *** UCase/LCase ***
                            // -----------------------------------------------------------------------*
                            for (int i = 0; i < g_lstEquipNumPieces.Count; i++)
                            {
                                if (g_lstEquipNumPieces[i].StartsWith("Shift+") == true)
                                {
                                    g_lstEquipNumPieces[i] = g_lstEquipNumPieces[i].Replace("Shift+", "").ToUpper();
                                }
                                else
                                    g_lstEquipNumPieces[i] = g_lstEquipNumPieces[i].ToLower();

                            }
                            // -----------------------------------------------------------------------*
                            // build the item name
                            // -----------------------------------------------------------------------*
                            strItem = "";
                            for (int I = 0; I < g_lstEquipNumPieces.Count; I++)
                                strItem = strItem + g_lstEquipNumPieces[I];
                            //
                            //
                            equipmentScanned(strItem);
                            //
                            // 
                            g_lstEquipNumPieces = new List<string>();
                            g_IsTime1Null = true;
                            //
                        }
                        else // if the entered Character is not //Enter//
                            g_lstEquipNumPieces.Add(k.ConvertToString(e.KeyData));
                    }
                    else // if the timespan is > 60ms
                    {
                        g_lstEquipNumPieces = new List<string>();
                        g_IsTime1Null = true;
                    }

                    //
                    g_Time1 = g_Time2;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                g_lstEquipNumPieces = new List<string>();
                g_IsTime1Null = true;
            }

        }



        #endregion

        #region coloring

        private Color whatColor(int intRow)
        {
            string strStatus;
            try
            {
                if (dgvDbEquipment["Status", intRow].Value == null)
                    return Color.Violet;
                //
                strStatus = dgvDbEquipment["Status", intRow].Value.ToString();
                //
                switch (strStatus)
                {
                    //---------------------------------------------------------------------
                    case INVALID:
                        return Color.Tomato;

                    case NO_CALIBRATION_DATE:
                        return Color.Tomato;

                    case PAST_DUE_FOR_CALIBRATION:
                        return Color.Tomato;
                    //---------------------------------------------------------------------
                    case CALIBRATION_NOT_REQUIRED:
                        return Color.PaleGreen;

                    case OUT_OF_DEPARTMENT + ", " + CALIBRATION_NOT_REQUIRED:
                        return Color.PaleGreen;

                    case GOOD:
                        return Color.PaleGreen;
                    //---------------------------------------------------------------------
                    case OUT_OF_DEPARTMENT:
                        return Color.Gold;

                    case DUE_IN_30_DAYS:
                        return Color.Gold;
                    //---------------------------------------------------------------------
                    default:
                        return Color.Gold;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
                return Color.Violet;
            }

        }

        private void ColorDGVRows()
        {
            Color cColor;
            int intRow;
            DateTime todayDate;
            try
            {
                todayDate = DateTime.Today;
                for (intRow = 0; intRow < dgvDbEquipment.Rows.Count; intRow++)
                {
                    cColor = whatColor(intRow);
                    //
                    // color row
                    for (int i = 0; i < dgvDbEquipment.Columns.Count; i++)
                        dgvDbEquipment[i, intRow].Style.BackColor = cColor;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        #endregion

        #region add/delete rows

        private void deleteSelectedRow()
        {
            try
            {
                if (dgvDbEquipment.SelectedRows.Count == 0)
                    return;
                //
                int intSelectedRow = dgvDbEquipment.SelectedRows[0].Index;
                //
                if (intSelectedRow == (dgvDbEquipment.Rows.Count - 1))
                    intSelectedRow--;

                dgvDbEquipment.Rows.Remove(dgvDbEquipment.SelectedRows[0]);
                //
                if (intSelectedRow >= 0)
                    dgvDbEquipment.Rows[intSelectedRow].Selected = true;
                //
                ColorDGVRows();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }

        }

        private void btnDeleteRow_Click(object sender, EventArgs e)
        {
            deleteSelectedRow();
        }

        #endregion

        #region a piece of equipment has been entered

        private void equipmentScanned(string strEquipmentNumber)
        {
            string strDatabase;
            string strCalDueDate;
            string strStatus = GOOD;
            DateTime todayDate;
            DateTime equipDate;
            bool bolInDepartment;
            OracleConnection conn;
            string strViewOwner;
            try
            {
                // ============================================================================
                // if empty equipment number
                // ============================================================================
                if (strEquipmentNumber.Trim() == "")
                    return;
                //
                // ============================================================================
                // if already exists in the table (scanned before)
                // ============================================================================
                for (int i = 0; i < dgvDbEquipment.Rows.Count; i++)
                    if (dgvDbEquipment["EquipmentNumber", i].Value.ToString() == strEquipmentNumber)
                        return;
                //
                Cursor.Current = Cursors.WaitCursor;
                //
                //
                strDatabase = existInWhichDatabase(strEquipmentNumber);
                if (strDatabase == "")
                {
                    // ============================================================================
                    // if doesn't exist in any database
                    // ============================================================================
                    strStatus = INVALID;
                    // add the row
                    dgvDbEquipment.Rows.Add(new object[] { "", strEquipmentNumber, strStatus, "", "", "" });
                }
                else // check for out of cal
                {
                    if (strDatabase == "MN")
                    {
                        conn = g_MNdbConnection;
                        strViewOwner = MNOWNER;
                    }
                    else// (strDatabase == "AZ")
                    {
                        conn = g_AZdbConnection;
                        strViewOwner = AZOWNER;
                    }
                    //
                    if (conn.State != ConnectionState.Open)
                        conn.Open();

                    // ============================================================================
                    // check if calibration is needed at all
                    // ============================================================================
                    if (!isCalibrationRequired(strEquipmentNumber, conn, strViewOwner))
                        strStatus = CALIBRATION_NOT_REQUIRED;
                    else
                    {
                        todayDate = DateTime.Today;
                        strCalDueDate = getCalibrationDueDate(strEquipmentNumber, conn, strViewOwner);
                        // ============================================================================
                        // check calibration due date
                        // ============================================================================
                        if (DateTime.TryParse(strCalDueDate, out equipDate))
                        {
                            if (equipDate.Subtract(todayDate).Days < 0)
                                strStatus = PAST_DUE_FOR_CALIBRATION;

                            else if (equipDate.Subtract(todayDate).Days >= 0 && equipDate.Subtract(todayDate).Days <= 30)
                                strStatus = DUE_IN_30_DAYS;
                        }
                        // ============================================================================
                        // check if it's a valid item (has a cal due date or not required for cal)
                        // ============================================================================
                        else
                            strStatus = NO_CALIBRATION_DATE;
                    }
                    // ============================================================================
                    // out of department
                    // ============================================================================
                    if (strStatus == GOOD || strStatus == CALIBRATION_NOT_REQUIRED || strStatus == DUE_IN_30_DAYS)
                    {
                        bolInDepartment = isIn150165(strEquipmentNumber);
                        if (!bolInDepartment && strStatus == GOOD) // good but out of department
                            strStatus = OUT_OF_DEPARTMENT;
                        else if (!bolInDepartment && strStatus != GOOD)
                            strStatus = OUT_OF_DEPARTMENT + ", " + strStatus;
                    }
                    //
                    //
                    // add the row
                    dgvDbEquipment.Rows.Add(new object[] {getDescription(strEquipmentNumber,conn,strViewOwner  ),
                        strEquipmentNumber, strStatus ,getCalibrationDueDate (strEquipmentNumber,conn ,strViewOwner ),
                        getManufacturer(strEquipmentNumber,conn,strViewOwner  ), getDepartment(strEquipmentNumber,conn,strViewOwner  )});
                }
                //
                //

                //
                ColorDGVRows();
                //
                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        #endregion

        private void dgvDbEquipment_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                // basically I want to color the selected row like the background
                if (dgvDbEquipment.SelectedCells.Count > 0)
                    dgvDbEquipment.Rows[dgvDbEquipment.SelectedCells[0].RowIndex].Selected = true;
                if (dgvDbEquipment.SelectedRows.Count > 0)
                    for (int c = 0; c < dgvDbEquipment.Columns.Count; c++)
                        dgvDbEquipment[c, dgvDbEquipment.SelectedRows[0].Index].Style.SelectionBackColor =
                            whatColor(dgvDbEquipment.SelectedRows[0].Index);
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }

        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            try
            {
                //DataTable DT;
                StringBuilder sbPastDue = new StringBuilder(1024);
                StringBuilder sbOutOfDepartment = new StringBuilder(1024);
                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                // case of an empty table
                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                if (dgvDbEquipment.Rows.Count == 0)
                    if (MessageBox.Show(this, "No equipment entered, are you sure you are done?", "Empty table",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        Close();
                    else
                        return;
                //}
                //
                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                // check bad entries
                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                for (int i = 0; i < dgvDbEquipment.Rows.Count; i++)
                    if (dgvDbEquipment["Status", i].Value.ToString() == NO_CALIBRATION_DATE ||
                        dgvDbEquipment["Status", i].Value.ToString() == INVALID ||
                        dgvDbEquipment["Status", i].Value.ToString() == PAST_DUE_FOR_CALIBRATION)
                    {
                        MessageBox.Show("Equipment that are invalid ,unavailable or past due for calibration must not be used" +
                        "\r\nCheck the status of the items highlighted in red", "Bad entires",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                // return entered equipment
                // -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
                Cursor.Current = Cursors.WaitCursor;
                g_strEnteredEquipment = "";
                for (int i = 0; i < dgvDbEquipment.Rows.Count; i++)
                {
                    g_strEnteredEquipment = g_strEnteredEquipment + dgvDbEquipment[0, i].Value.ToString();
                    for (int j = 1; j < dgvDbEquipment.Columns.Count; j++)
                    {
                        g_strEnteredEquipment = g_strEnteredEquipment + ";" + dgvDbEquipment[j, i].Value.ToString();
                    }
                    if (i < (dgvDbEquipment.Rows.Count - 1))
                        g_strEnteredEquipment = g_strEnteredEquipment + "\r\n";
                }
                //
                updateOutOfDepartmentFile();
                //
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }

        }

        private void updateOutOfDepartmentFile()
        {
            //if (!g_strWorkstationID.StartsWith("CRM-HWT-"))
            //    return;
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                string strTrackingDirectory = "\\\\HWDVT.crmdev.medtronic.com\\HW-DIT-LAB\\Drive-L\\Transfer\\Carl\\OutOfDepartment";
                string strTrackingFile = "OutOfDepartment.txt";
                string strColumnHeaders = "Description\tEquipment Number\tStatus\tCalibration Due Date\tManufacturer\tDepartment\tTest Name\tTest Executer\tDate Used\tWorkstation ID\r\n\r\n";
                StringBuilder sbData = new StringBuilder();
                Random rNum = new Random();
                //
                //
                if (!Directory.Exists(strTrackingDirectory))
                    Directory.CreateDirectory(strTrackingDirectory);
                if (!File.Exists(strTrackingDirectory + "\\" + strTrackingFile))
                    File.WriteAllText(strTrackingDirectory + "\\" + strTrackingFile, strColumnHeaders);
                //
                //
                // build the string that is to be written to do one write operation
                for (int i = 0; i < dgvDbEquipment.Rows.Count; i++)
                    // if the workstation id is not CRM-HWT then log everything
                    // if the workstation id is CRM-HWT then only log the out of 150165 ones
                    if ((!g_strWorkstationID.ToUpper().StartsWith("CRM-HWT-") &&
                        !dgvDbEquipment[2, i].Value.ToString().Contains(CALIBRATION_NOT_REQUIRED)) ||
                        g_strWorkstationID.StartsWith("CRM-HWT-") &&
                        !isIn150165(dgvDbEquipment[1, i].Value.ToString()) &&
                        !dgvDbEquipment[2, i].Value.ToString().Contains(CALIBRATION_NOT_REQUIRED))
                        sbData.Append(dgvDbEquipment[0, i].Value.ToString() + "\t" +
                                        dgvDbEquipment[1, i].Value.ToString() + "\t" +
                                        dgvDbEquipment[2, i].Value.ToString() + "\t" +
                                        dgvDbEquipment[3, i].Value.ToString() + "\t" +
                                        dgvDbEquipment[4, i].Value.ToString() + "\t" +
                                        dgvDbEquipment[5, i].Value.ToString() + "\t" +
                                        g_strTestName + "\t" +
                                        g_strTestExecutor + "\t" +
                                        string.Format("{0:dd/MMM/yyyy}", DateTime.Today.Date) + "\t" +
                                        System.Net.Dns.GetHostName() + "\r\n");
                //
                //
                // this is a trick to get around the problem of file being locked by someone else
                bool bolSuccessful = false;
                int intCount = 0;
                // try 10 times 
                while (!bolSuccessful && intCount < 10)
                {
                    try
                    {
                        File.AppendAllText(strTrackingDirectory + "\\" + strTrackingFile, sbData.ToString());
                        bolSuccessful = true;
                    }
                    catch
                    {
                        intCount++;
                        bolSuccessful = false;
                        // wait a random number to break the tie between the competing computers
                        System.Threading.Thread.Sleep(rNum.Next(250, 1000));
                    }
                }
                //
                //
                // if the file is still locked; then create a separate file
                if (!bolSuccessful)
                {
                    strTrackingFile = "OutOfDepartment_(" + string.Format("{0:dd-MMM-yyyy}", DateTime.Today.Date) +
                                            ")__(" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_" + DateTime.Now.Millisecond +
                                            ")__" + System.Net.Dns.GetHostName() + ".txt";
                    //
                    File.AppendAllText(strTrackingDirectory + "\\" + strTrackingFile, strColumnHeaders + sbData.ToString());
                }
            }
            catch //(Exception ex)
            {
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (g_MNdbConnection != null)
            {
                g_MNdbConnection.Close();
                g_MNdbConnection.Dispose();
            }
            if (g_AZdbConnection != null)
            {
                g_AZdbConnection.Close();
                g_AZdbConnection.Dispose();
            }
        }

        private void btnManualEntry_Click(object sender, EventArgs e)
        {
            /*
            frmManualEquipmentEntry manualEntry;
            //
            Cursor.Current = Cursors.WaitCursor;
            //
            if (g_lstAllAvailableEquipment.Count == 0)
                g_lstAllAvailableEquipment = getAllEquipment();
            //
            manualEntry = new frmManualEquipmentEntry(g_lstAllAvailableEquipment);

            //
            manualEntry.TopMost = true;
            manualEntry.ShowDialog();
            //
            for (int i = 0; i < manualEntry.SelectedEquipment.Count; i++)
                equipmentScanned(manualEntry.SelectedEquipment[i]);
            */

            frmManEntry manualEntry;
            //
            Cursor.Current = Cursors.WaitCursor;
            //
            if (g_lstAllAvailableEquipment.Count == 0)
                g_lstAllAvailableEquipment = getAllEquipment();
            //
            manualEntry = new frmManEntry(g_lstAllAvailableEquipment);

            //
            manualEntry.TopMost = true;
            manualEntry.ShowDialog();
            //
            for (int i = 0; i < manualEntry.SelectedEquipment.Count; i++)
                equipmentScanned(manualEntry.SelectedEquipment[i]);

        }

        private void btnMoveRowUp_Click(object sender, EventArgs e)
        {
            try
            {
                // for safety
                if (dgvDbEquipment.SelectedRows.Count == 0)
                    return;
                // if the first row then do nothing
                if (dgvDbEquipment.SelectedRows[0].Index == 0)
                    return;
                //
                // the idea is to replace values in the two rows
                int intRow1 = dgvDbEquipment.SelectedRows[0].Index - 1;
                int intRow2 = dgvDbEquipment.SelectedRows[0].Index;
                string strTmp;
                //
                //
                for (int col = 0; col < dgvDbEquipment.Columns.Count; col++)
                {
                    strTmp = dgvDbEquipment[col, intRow1].Value.ToString();
                    dgvDbEquipment[col, intRow1].Value = dgvDbEquipment[col, intRow2].Value;
                    dgvDbEquipment[col, intRow2].Value = strTmp;
                }
                //
                ColorDGVRows();
                //
                dgvDbEquipment.CurrentCell = dgvDbEquipment.Rows[intRow1].Cells[0];
                dgvDbEquipment.Rows[intRow1].Selected = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void btnMoveRowDown_Click(object sender, EventArgs e)
        {
            try
            {
                // for safety
                if (dgvDbEquipment.SelectedRows.Count == 0)
                    return;
                // if the bottom row then do nothing
                if (dgvDbEquipment.SelectedRows[0].Index == (dgvDbEquipment.Rows.Count - 1))
                    return;
                //
                // the idea is to replace values in the two rows
                int intRow1 = dgvDbEquipment.SelectedRows[0].Index;
                int intRow2 = dgvDbEquipment.SelectedRows[0].Index + 1;
                string strTmp;
                //
                //
                for (int col = 0; col < dgvDbEquipment.Columns.Count; col++)
                {
                    strTmp = dgvDbEquipment[col, intRow1].Value.ToString();
                    dgvDbEquipment[col, intRow1].Value = dgvDbEquipment[col, intRow2].Value;
                    dgvDbEquipment[col, intRow2].Value = strTmp;
                }
                //
                ColorDGVRows();
                //
                dgvDbEquipment.CurrentCell = dgvDbEquipment.Rows[intRow2].Cells[0];
                dgvDbEquipment.Rows[intRow2].Selected = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }

        private void btnAddEmptyRow_Click(object sender, EventArgs e)
        {
            try
            {
                dgvDbEquipment.Rows.Add(new object[] { "", "", "", "", "", "" });
                //
                ColorDGVRows();
                //
                dgvDbEquipment.CurrentCell = dgvDbEquipment.Rows[dgvDbEquipment.Rows.Count - 1].Cells[0];
                dgvDbEquipment.Rows[dgvDbEquipment.Rows.Count - 1].Selected = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("\r\nMessage:\r\n" + ex.Message + "\r\nStackTrace:\r\n" + ex.StackTrace, "Exception ");
            }
        }
        /*
                private void btnManualEntry_Click(object sender, EventArgs e)
        {
            //
            Cursor.Current = Cursors.WaitCursor;
            //
            if (g_ManualNumberSelectionForm == null)
            {
                //g_lstAllEquipment = getAllEquipment();
                g_ManualNumberSelectionForm = new frmManualEntry(getAllEquipment());
                //g_ManualNumberSelectionForm.EquipmentNumbersList = g_lstAllEquipment;
            }
            //
            g_ManualNumberSelectionForm.TopMost = true;
            g_ManualNumberSelectionForm.ShowDialog();
            //
            for (int i = 0; i < g_ManualNumberSelectionForm.SelectedEquipment.Count; i++)
                equipmentScanned(g_ManualNumberSelectionForm.SelectedEquipment[i]);


            //
        }

        */






    }
}
