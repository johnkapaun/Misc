
#define DataTypeByPTR 0x10000000
#define DataTypeByREF 0x20000000
#define DataTypeByVAL 0x40000000

#define DataTypeI8    0x00000001
#define DataTypeI16   0x00000002
#define DataTypeI32   0x00000004
#define DataTypeI64   0x00000008

#define DataTypeU8    0x00000010
#define DataTypeU16   0x00000020
#define DataTypeU32   0x00000040
#define DataTypeU64   0x00000080

#define DataTypeSGL   0x00000100
#define DataTypeDBL   0x00000200
#define DataTypeBOOL  0x00000400
#define DataTypeSTR   0x00000800
#define DataTypeERR   0x00001000
#define DataTypeCSTR  0x00002000

#define DataTypeNonArray   0x01000000
#define DataTypeArray      0x02000000
#define DataTypeArrayArray 0x04000000

#define DataTypeRETURN 0x80000000

#define DataFilterType 0x00FFFFFF
#define DataFilterSize 0x0F000000
#define DataFilterDir  0x70000000


enum DataTypes
{
	TypeErrPTR         = DataTypeERR  | DataTypeByPTR | DataTypeNonArray,

	//////////////////////////////////////////////////////////////////

	TypeStrPTR         = DataTypeSTR  | DataTypeByPTR | DataTypeNonArray,
	TypeStrREF         = DataTypeSTR  | DataTypeByREF | DataTypeNonArray,
	TypeStrVAL         = DataTypeSTR  | DataTypeByVAL | DataTypeNonArray,

	TypeI8PTR          = DataTypeI8   | DataTypeByPTR | DataTypeNonArray,
	TypeI8REF          = DataTypeI8   | DataTypeByREF | DataTypeNonArray,
	TypeI8VAL          = DataTypeI8   | DataTypeByVAL | DataTypeNonArray,

	TypeU8PTR          = DataTypeU8   | DataTypeByPTR | DataTypeNonArray,
	TypeU8REF          = DataTypeU8   | DataTypeByREF | DataTypeNonArray,
	TypeU8VAL          = DataTypeU8   | DataTypeByVAL | DataTypeNonArray,

	TypeI16PTR         = DataTypeI16  | DataTypeByPTR | DataTypeNonArray,
	TypeI16REF         = DataTypeI16  | DataTypeByREF | DataTypeNonArray,
	TypeI16VAL         = DataTypeI16  | DataTypeByVAL | DataTypeNonArray,

	TypeU16PTR         = DataTypeU16  | DataTypeByPTR | DataTypeNonArray,
	TypeU16REF         = DataTypeU16  | DataTypeByREF | DataTypeNonArray,
	TypeU16VAL         = DataTypeU16  | DataTypeByVAL | DataTypeNonArray,

	TypeI32PTR         = DataTypeI32  | DataTypeByPTR | DataTypeNonArray,
	TypeI32REF         = DataTypeI32  | DataTypeByREF | DataTypeNonArray,
	TypeI32VAL         = DataTypeI32  | DataTypeByVAL | DataTypeNonArray,

	TypeU32PTR         = DataTypeU32  | DataTypeByPTR | DataTypeNonArray,
	TypeU32REF         = DataTypeU32  | DataTypeByREF | DataTypeNonArray,
	TypeU32VAL         = DataTypeU32  | DataTypeByVAL | DataTypeNonArray,

	TypeSglPTR         = DataTypeSGL  | DataTypeByPTR | DataTypeNonArray,
	TypeSglREF         = DataTypeSGL  | DataTypeByREF | DataTypeNonArray,
	TypeSglVAL         = DataTypeSGL  | DataTypeByVAL | DataTypeNonArray,

	TypeDblPTR         = DataTypeDBL  | DataTypeByPTR | DataTypeNonArray,
	TypeDblREF         = DataTypeDBL  | DataTypeByREF | DataTypeNonArray,
	TypeDblVAL         = DataTypeDBL  | DataTypeByVAL | DataTypeNonArray,

	TypeBoolPTR        = DataTypeBOOL | DataTypeByPTR | DataTypeNonArray,
	TypeBoolREF        = DataTypeBOOL | DataTypeByREF | DataTypeNonArray,
	TypeBoolVAL        = DataTypeBOOL | DataTypeByVAL | DataTypeNonArray,

	//////////////////////////////////////////////////////////////////

	TypeStrArrPTR      = DataTypeSTR  | DataTypeByPTR | DataTypeArray,
	TypeStrArrREF      = DataTypeSTR  | DataTypeByREF | DataTypeArray,
	TypeStrArrVAL      = DataTypeSTR  | DataTypeByVAL | DataTypeArray,

	TypeI8ArrPTR       = DataTypeI8   | DataTypeByPTR | DataTypeArray,
	TypeI8ArrREF       = DataTypeI8   | DataTypeByREF | DataTypeArray,
	TypeI8ArrVAL       = DataTypeI8   | DataTypeByVAL | DataTypeArray,

	TypeU8ArrPTR       = DataTypeU8   | DataTypeByPTR | DataTypeArray,
	TypeU8ArrREF       = DataTypeU8   | DataTypeByREF | DataTypeArray,
	TypeU8ArrVAL       = DataTypeU8   | DataTypeByVAL | DataTypeArray,

	TypeI16ArrPTR      = DataTypeI16  | DataTypeByPTR | DataTypeArray,
	TypeI16ArrREF      = DataTypeI16  | DataTypeByREF | DataTypeArray,
	TypeI16ArrVAL      = DataTypeI16  | DataTypeByVAL | DataTypeArray,

	TypeU16ArrPTR      = DataTypeU16  | DataTypeByPTR | DataTypeArray,
	TypeU16ArrREF      = DataTypeU16  | DataTypeByREF | DataTypeArray,
	TypeU16ArrVAL      = DataTypeU16  | DataTypeByVAL | DataTypeArray,

	TypeI32ArrPTR      = DataTypeI32  | DataTypeByPTR | DataTypeArray,
	TypeI32ArrREF      = DataTypeI32  | DataTypeByREF | DataTypeArray,
	TypeI32ArrVAL      = DataTypeI32  | DataTypeByVAL | DataTypeArray,

	TypeU32ArrPTR      = DataTypeU32  | DataTypeByPTR | DataTypeArray,
	TypeU32ArrREF      = DataTypeU32  | DataTypeByREF | DataTypeArray,
	TypeU32ArrVAL      = DataTypeU32  | DataTypeByVAL | DataTypeArray,

	TypeSglArrPTR      = DataTypeSGL  | DataTypeByPTR | DataTypeArray,
	TypeSglArrREF      = DataTypeSGL  | DataTypeByREF | DataTypeArray,
	TypeSglArrVAL      = DataTypeSGL  | DataTypeByVAL | DataTypeArray,

	TypeDblArrPTR      = DataTypeDBL  | DataTypeByPTR | DataTypeArray,
	TypeDblArrREF      = DataTypeDBL  | DataTypeByREF | DataTypeArray,
	TypeDblArrVAL      = DataTypeDBL  | DataTypeByVAL | DataTypeArray,

	TypeBoolArrPTR     = DataTypeBOOL | DataTypeByPTR | DataTypeArray,
	TypeBoolArrREF     = DataTypeBOOL | DataTypeByREF | DataTypeArray,
	TypeBoolArrVAL     = DataTypeBOOL | DataTypeByVAL | DataTypeArray,

	//////////////////////////////////////////////////////////////////

	TypeStrArrArrPTR   = DataTypeSTR  | DataTypeByPTR | DataTypeArrayArray,
	TypeStrArrArrREF   = DataTypeSTR  | DataTypeByREF | DataTypeArrayArray,
	TypeStrArrArrVAL   = DataTypeSTR  | DataTypeByVAL | DataTypeArrayArray,

	TypeI8ArrArrPTR    = DataTypeI8   | DataTypeByPTR | DataTypeArrayArray,
	TypeI8ArrArrREF    = DataTypeI8   | DataTypeByREF | DataTypeArrayArray,
	TypeI8ArrArrVAL    = DataTypeI8   | DataTypeByVAL | DataTypeArrayArray,

	TypeU8ArrArrPTR    = DataTypeU8   | DataTypeByPTR | DataTypeArrayArray,
	TypeU8ArrArrREF    = DataTypeU8   | DataTypeByREF | DataTypeArrayArray,
	TypeU8ArrArrVAL    = DataTypeU8   | DataTypeByVAL | DataTypeArrayArray,

	TypeI16ArrArrPTR   = DataTypeI16  | DataTypeByPTR | DataTypeArrayArray,
	TypeI16ArrArrREF   = DataTypeI16  | DataTypeByREF | DataTypeArrayArray,
	TypeI16ArrArrVAL   = DataTypeI16  | DataTypeByVAL | DataTypeArrayArray,

	TypeU16ArrArrPTR   = DataTypeU16  | DataTypeByPTR | DataTypeArrayArray,
	TypeU16ArrArrREF   = DataTypeU16  | DataTypeByREF | DataTypeArrayArray,
	TypeU16ArrArrVAL   = DataTypeU16  | DataTypeByVAL | DataTypeArrayArray,

	TypeI32ArrArrPTR   = DataTypeI32  | DataTypeByPTR | DataTypeArrayArray,
	TypeI32ArrArrREF   = DataTypeI32  | DataTypeByREF | DataTypeArrayArray,
	TypeI32ArrArrVAL   = DataTypeI32  | DataTypeByVAL | DataTypeArrayArray,

	TypeU32ArrArrPTR   = DataTypeU32  | DataTypeByPTR | DataTypeArrayArray,
	TypeU32ArrArrREF   = DataTypeU32  | DataTypeByREF | DataTypeArrayArray,
	TypeU32ArrArrVAL   = DataTypeU32  | DataTypeByVAL | DataTypeArrayArray,

	TypeSglArrArrPTR   = DataTypeSGL  | DataTypeByPTR | DataTypeArrayArray,
	TypeSglArrArrREF   = DataTypeSGL  | DataTypeByREF | DataTypeArrayArray,
	TypeSglArrArrVAL   = DataTypeSGL  | DataTypeByVAL | DataTypeArrayArray,

	TypeDblArrArrPTR   = DataTypeDBL  | DataTypeByPTR | DataTypeArrayArray,
	TypeDblArrArrREF   = DataTypeDBL  | DataTypeByREF | DataTypeArrayArray,
	TypeDblArrArrVAL   = DataTypeDBL  | DataTypeByVAL | DataTypeArrayArray,

	TypeBoolArrArrPTR  = DataTypeBOOL | DataTypeByPTR | DataTypeArrayArray,
	TypeBoolArrArrREF  = DataTypeBOOL | DataTypeByREF | DataTypeArrayArray,
	TypeBoolArrArrVAL  = DataTypeBOOL | DataTypeByVAL | DataTypeArrayArray,

	//////////////////////////////////////////////////////////////////

	TypeCStrREF        = DataTypeCSTR  | DataTypeByREF | DataTypeNonArray,

	//////////////////////////////////////////////////////////////////

	TypeRetStrPTR         = TypeStrPTR  | DataTypeRETURN,
	TypeRetStrREF         = TypeStrREF  | DataTypeRETURN,
	TypeRetStrVAL         = TypeStrVAL  | DataTypeRETURN,

	TypeRetI8PTR          = TypeI8PTR   | DataTypeRETURN,
	TypeRetI8REF          = TypeI8REF   | DataTypeRETURN,
	TypeRetI8VAL          = TypeI8VAL   | DataTypeRETURN,

	TypeRetU8PTR          = TypeU8PTR   | DataTypeRETURN,
	TypeRetU8REF          = TypeU8REF   | DataTypeRETURN,
	TypeRetU8VAL          = TypeU8VAL   | DataTypeRETURN,

	TypeRetI16PTR         = TypeI16PTR  | DataTypeRETURN,
	TypeRetI16REF         = TypeI16REF  | DataTypeRETURN,
	TypeRetI16VAL         = TypeI16VAL  | DataTypeRETURN,

	TypeRetU16PTR         = TypeU16PTR  | DataTypeRETURN,
	TypeRetU16REF         = TypeU16REF  | DataTypeRETURN,
	TypeRetU16VAL         = TypeU16VAL  | DataTypeRETURN,

	TypeRetI32PTR         = TypeI32PTR  | DataTypeRETURN,
	TypeRetI32REF         = TypeI32REF  | DataTypeRETURN,
	TypeRetI32VAL         = TypeI32VAL  | DataTypeRETURN,

	TypeRetU32PTR         = TypeU32PTR  | DataTypeRETURN,
	TypeRetU32REF         = TypeU32REF  | DataTypeRETURN,
	TypeRetU32VAL         = TypeU32VAL  | DataTypeRETURN,

	TypeRetSglPTR         = TypeSglPTR  | DataTypeRETURN,
	TypeRetSglREF         = TypeSglREF  | DataTypeRETURN,
	TypeRetSglVAL         = TypeSglVAL  | DataTypeRETURN,

	TypeRetDblPTR         = TypeDblPTR  | DataTypeRETURN,
	TypeRetDblREF         = TypeDblREF  | DataTypeRETURN,
	TypeRetDblVAL         = TypeDblVAL  | DataTypeRETURN,

	TypeRetBoolPTR        = TypeBoolPTR | DataTypeRETURN,
	TypeRetBoolREF        = TypeBoolREF | DataTypeRETURN,
	TypeRetBoolVAL        = TypeBoolVAL | DataTypeRETURN,

	//////////////////////////////////////////////////////////////////

	TypeRetStrArrPTR      = TypeStrArrPTR  | DataTypeRETURN,
	TypeRetStrArrREF      = TypeStrArrREF  | DataTypeRETURN,
	TypeRetStrArrVAL      = TypeStrArrVAL  | DataTypeRETURN,

	TypeRetI8ArrPTR       = TypeI8ArrPTR   | DataTypeRETURN,
	TypeRetI8ArrREF       = TypeI8ArrREF   | DataTypeRETURN,
	TypeRetI8ArrVAL       = TypeI8ArrVAL   | DataTypeRETURN,

	TypeRetU8ArrPTR       = TypeU8ArrPTR   | DataTypeRETURN,
	TypeRetU8ArrREF       = TypeU8ArrREF   | DataTypeRETURN,
	TypeRetU8ArrVAL       = TypeU8ArrVAL   | DataTypeRETURN,

	TypeRetI16ArrPTR      = TypeI16ArrPTR  | DataTypeRETURN,
	TypeRetI16ArrREF      = TypeI16ArrREF  | DataTypeRETURN,
	TypeRetI16ArrVAL      = TypeI16ArrVAL  | DataTypeRETURN,

	TypeRetU16ArrPTR      = TypeU16ArrPTR  | DataTypeRETURN,
	TypeRetU16ArrREF      = TypeU16ArrREF  | DataTypeRETURN,
	TypeRetU16ArrVAL      = TypeU16ArrVAL  | DataTypeRETURN,

	TypeRetI32ArrPTR      = TypeI32ArrPTR  | DataTypeRETURN,
	TypeRetI32ArrREF      = TypeI32ArrREF  | DataTypeRETURN,
	TypeRetI32ArrVAL      = TypeI32ArrVAL  | DataTypeRETURN,

	TypeRetU32ArrPTR      = TypeU32ArrPTR  | DataTypeRETURN,
	TypeRetU32ArrREF      = TypeU32ArrREF  | DataTypeRETURN,
	TypeRetU32ArrVAL      = TypeU32ArrVAL  | DataTypeRETURN,

	TypeRetSglArrPTR      = TypeSglArrPTR  | DataTypeRETURN,
	TypeRetSglArrREF      = TypeSglArrREF  | DataTypeRETURN,
	TypeRetSglArrVAL      = TypeSglArrVAL  | DataTypeRETURN,

	TypeRetDblArrPTR      = TypeDblArrPTR  | DataTypeRETURN,
	TypeRetDblArrREF      = TypeDblArrREF  | DataTypeRETURN,
	TypeRetDblArrVAL      = TypeDblArrVAL  | DataTypeRETURN,

	TypeRetBoolArrPTR     = TypeBoolArrPTR | DataTypeRETURN,
	TypeRetBoolArrREF     = TypeBoolArrREF | DataTypeRETURN,
	TypeRetBoolArrVAL     = TypeBoolArrVAL | DataTypeRETURN,

	//////////////////////////////////////////////////////////////////

	TypeRetStrArrArrPTR   = TypeStrArrArrPTR  | DataTypeRETURN,
	TypeRetStrArrArrREF   = TypeStrArrArrREF  | DataTypeRETURN,
	TypeRetStrArrArrVAL   = TypeStrArrArrVAL  | DataTypeRETURN,

	TypeRetI8ArrArrPTR    = TypeI8ArrArrPTR   | DataTypeRETURN,
	TypeRetI8ArrArrREF    = TypeI8ArrArrREF   | DataTypeRETURN,
	TypeRetI8ArrArrVAL    = TypeI8ArrArrVAL   | DataTypeRETURN,

	TypeRetU8ArrArrPTR    = TypeU8ArrArrPTR   | DataTypeRETURN,
	TypeRetU8ArrArrREF    = TypeU8ArrArrREF   | DataTypeRETURN,
	TypeRetU8ArrArrVAL    = TypeU8ArrArrVAL   | DataTypeRETURN,

	TypeRetI16ArrArrPTR   = TypeI16ArrArrPTR  | DataTypeRETURN,
	TypeRetI16ArrArrREF   = TypeI16ArrArrREF  | DataTypeRETURN,
	TypeRetI16ArrArrVAL   = TypeI16ArrArrVAL  | DataTypeRETURN,

	TypeRetU16ArrArrPTR   = TypeU16ArrArrPTR  | DataTypeRETURN,
	TypeRetU16ArrArrREF   = TypeU16ArrArrREF  | DataTypeRETURN,
	TypeRetU16ArrArrVAL   = TypeU16ArrArrVAL  | DataTypeRETURN,

	TypeRetI32ArrArrPTR   = TypeI32ArrArrPTR  | DataTypeRETURN,
	TypeRetI32ArrArrREF   = TypeI32ArrArrREF  | DataTypeRETURN,
	TypeRetI32ArrArrVAL   = TypeI32ArrArrVAL  | DataTypeRETURN,

	TypeRetU32ArrArrPTR   = TypeU32ArrArrPTR  | DataTypeRETURN,
	TypeRetU32ArrArrREF   = TypeU32ArrArrREF  | DataTypeRETURN,
	TypeRetU32ArrArrVAL   = TypeU32ArrArrVAL  | DataTypeRETURN,

	TypeRetSglArrArrPTR   = TypeSglArrArrPTR  | DataTypeRETURN,
	TypeRetSglArrArrREF   = TypeSglArrArrREF  | DataTypeRETURN,
	TypeRetSglArrArrVAL   = TypeSglArrArrVAL  | DataTypeRETURN,

	TypeRetDblArrArrPTR   = TypeDblArrArrPTR  | DataTypeRETURN,
	TypeRetDblArrArrREF   = TypeDblArrArrREF  | DataTypeRETURN,
	TypeRetDblArrArrVAL   = TypeDblArrArrVAL  | DataTypeRETURN,

	TypeRetBoolArrArrPTR  = TypeBoolArrArrPTR | DataTypeRETURN,
	TypeRetBoolArrArrREF  = TypeBoolArrArrREF | DataTypeRETURN,
	TypeRetBoolArrArrVAL  = TypeBoolArrArrVAL | DataTypeRETURN,

	//////////////////////////////////////////////////////////////////

};
