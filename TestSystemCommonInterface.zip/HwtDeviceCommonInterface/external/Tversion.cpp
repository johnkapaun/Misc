
#include "stdafx.h"
#include "tstring.h"
#include "crm_dev.h"
#include "tarray.h"
#include "tversion.h"

FileVersionInfo::FileVersionInfo(const char *FullFileName)
{
	VersionBuffer = NULL;
	VersionBufferLen = 0;
	ValidStatus = false;
	FixedFileVersion = uInt16Array(4);
	FixedProductVersion = uInt16Array(4);
	FileFlags = 0;
	FileName = 	RemovePathFromFileName( FullFileName );

	DWORD lDummy;
	char *temp;

	temp = new char[strlen(FullFileName) + 1];
	strcpy( temp, FullFileName );

    if( (VersionBufferLen = GetFileVersionInfoSize(temp, &lDummy)) > 0 )
	{
		VersionBuffer = new char[VersionBufferLen];

		if( GetFileVersionInfo(temp, 0, VersionBufferLen, VersionBuffer) != FALSE )
			if( (ValidStatus = LoadFixedFileInfo()) == true)
				FormattedInfo = BuildVersionString();
	}
	delete [] temp;
}

FileVersionInfo::~FileVersionInfo()
{
	delete [] VersionBuffer;
}

bool FileVersionInfo::LoadFixedFileInfo(void)
{
    VS_FIXEDFILEINFO *pVerInfo;
    UINT len;

    if( VerQueryValue(VersionBuffer, "\\", (void **)&pVerInfo, &len) != FALSE )
	{
		FixedFileVersion[0] = HIWORD(pVerInfo->dwFileVersionMS);
		FixedFileVersion[1] = LOWORD(pVerInfo->dwFileVersionMS);
		FixedFileVersion[2] = HIWORD(pVerInfo->dwFileVersionLS);
		FixedFileVersion[3] = LOWORD(pVerInfo->dwFileVersionLS);

		FixedProductVersion[0] = HIWORD(pVerInfo->dwProductVersionMS);
		FixedProductVersion[1] = LOWORD(pVerInfo->dwProductVersionMS);
		FixedProductVersion[2] = HIWORD(pVerInfo->dwProductVersionLS);
		FixedProductVersion[3] = LOWORD(pVerInfo->dwProductVersionLS);

		FileFlags = pVerInfo->dwFileFlags;

		return true;
	}
	return false;
}

TString FileVersionInfo::BuildVersionString(void) const
{
	TString str;

	if( !Valid() )
	{
		str.Format("Library = '%s', Version Information Not Available\n", FileName.CStr() );
		return str;
	}

	TString File = QueryValue("OriginalFilename");
	TString Special = QueryValue("SpecialBuild");
	TString Private = QueryValue("PrivateBuild");

	if( stricmp(File, FileName) != 0 )							// if FileName != OriginalFilename 
		File.Format( "%s (%s)", FileName.CStr(), File.CStr() );	// reformat as 'FileName (OriginalFilename)'

	str.Format("Library = '%s', Version = '%s'", File.CStr(), QueryValue("FileVersion").CStr() );

	if( FileFlags & VS_FF_PRERELEASE )
		str += " (PRE-RELEASE)";

	if( Special.Length() > 0 )
		str += TString(", Special Build = '") + Special + "'";

	if( Private.Length() > 0 )
		str += TString(", Private Build = '") + Private + "'";

	return str + "\n";
}

TString FileVersionInfo::QueryValue(const char *Parm) const
{
    void *Buffer;
	char *temp;
    UINT str_len;

	if( !ValidStatus )
		return "";

	TString FullParm( TString("\\StringFileInfo\\040904B0\\") + Parm );

	temp = new char[FullParm.Length() + 1];
	strcpy( temp, FullParm );

    if( VerQueryValue(VersionBuffer, temp, &Buffer, &str_len) == FALSE )
	{
		delete [] temp;
		return "";
	}
	delete [] temp;
	TString Value( (char *)Buffer, str_len );
	Value.Trim();
	return Value;
}

TString FileVersionInfo::FlagString(bool Parenthesis) const
{
	TString str;

	if( FileFlags & VS_FF_PRERELEASE )
		str = "Pre-Release";

	if( FileFlags & VS_FF_PRIVATEBUILD )
	{
		if( !str.IsEmpty() )
			str += ", ";
		str += "Private-Build";
	}

	if( FileFlags & VS_FF_SPECIALBUILD )
	{
		if( !str.IsEmpty() )
			str += ", ";
		str += "Special-Build";
	}

	if( Parenthesis & !str.IsEmpty() )
		str = "(" + str + ")";

	return str;
}
