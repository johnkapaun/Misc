This folder is set up to test a test app VI that has an improper connecion pane.

Error - HWT Test System exits