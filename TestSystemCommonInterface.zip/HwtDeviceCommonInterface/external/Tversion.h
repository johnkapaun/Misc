
class FileVersionInfo
{
    protected:
		char *VersionBuffer;		// Raw Version Information from Resource
		UINT  VersionBufferLen;		// Raw Resource Version Size
		bool ValidStatus;			// Valid State of File Version Information
		TString FormattedInfo;
		TString FileName;

    public:
		FileVersionInfo(const char *FullFileName);	// Constructor
		virtual ~FileVersionInfo();					// Destructor

		uInt16Array FixedFileVersion;
		uInt16Array FixedProductVersion;
		uInt32 FileFlags;

		TString QueryValue(const char *Parm) const;
		bool Valid(void) const { return ValidStatus; }
		TString FormattedVersionInfo(void) const { return FormattedInfo; }
		TString FlagString(bool Parenthesis = true) const;

	private:
		bool LoadFixedFileInfo(void);
		TString BuildVersionString(void) const;
};
