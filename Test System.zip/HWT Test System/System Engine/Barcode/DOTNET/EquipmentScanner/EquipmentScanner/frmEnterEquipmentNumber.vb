﻿Imports System.Data.OracleClient
Imports System.Collections.Specialized
Imports System.Windows.Forms


Public Class frmEnterEquipmentNumber

    Public ReadOnly Property EquipmentNumber() As String
        Get
            Return g_strEquipmentNumber
        End Get
    End Property

    Private g_strEquipmentNumber As String

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        '//////////////////////////////////////////////////////////////////
        ' this form will be instanciated once so load up the equipment
        ' in the drop down menu once
        '//////////////////////////////////////////////////////////////////
        Try

        
            Dim strSQL As String
            Dim DA As OracleDataAdapter
            Dim DT As DataTable
            Dim intI As Int32
            Dim colEquipment As StringCollection
            '
            Cursor.Current = Cursors.WaitCursor
            strSQL = "SELECT PROP_NUM FROM EQUIP_ALL_DEPT"
            DA = New OracleDataAdapter(strSQL, frmEquipment.Connection)
            DT = New DataTable
            DA.Fill(DT)
            '
            colEquipment = New StringCollection
            For intI = 0 To DT.Rows.Count - 1
                colEquipment.Add(DT.Rows(intI).Item(0).ToString)
            Next
            '
            cbxEquipmentNumbers.DataSource = colEquipment
            '
            Cursor.Current = Cursors.Default
            '//////////////////////////////////////////////////////////////////
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception: frmEnterEquipmentNumber:New")
        End Try

    End Sub



    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Try

        
            g_strEquipmentNumber = Trim(cbxEquipmentNumbers.Text)

            If cbxEquipmentNumbers.Items.Contains(g_strEquipmentNumber) = False Then
                MessageBox.Show("The number you entered does not exist in the database!", _
                                 "Equipment not found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Exit Sub
            End If
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception: btnOK_Click")
            g_strEquipmentNumber = Nothing
            Me.Close()
        End Try
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        g_strEquipmentNumber = Nothing
        Me.Close()

    End Sub


End Class