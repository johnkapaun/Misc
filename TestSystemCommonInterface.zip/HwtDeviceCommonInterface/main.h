
#ifndef _MAIN_H
#define _MAIN_H

#include "ProcessLog.h"

//////////////////////////////////////////////////////////////////////////////

// name of the executable
#define SZAPPNAME            "HwtDeviceCommonInterface"

// displayed name of the application
#define SZAPPDISPLAYNAME "Hwt Device Common Interface"

//////////////////////////////////////////////////////////////////////////////

unsigned __stdcall ServerThread( LPVOID lpParameter );
void ServerStop(void);

void AttachCurrentThreadToMessageThread(void);
void DetachCurrentThreadFromMessageThread(void);
void CheckForActiveClients(void);

TString ReleasedInterfacePath(ErrorCluster *error = NULL);
TString LocalInterfacePath(ErrorCluster *error = NULL);
TString CommonInterface_FileName(bool IncludePath);

TString VerifyHwtDeviceCommonInterface( ErrorCluster *error );
TString VerifyAppInterfaceVersions( ErrorCluster *error );

//////////////////////////////////////////////////////////////////////////////

// Global Variables:
extern HINSTANCE hInst;				// current instance
extern HWND hWnd;					// main window handle
extern DWORD MessageLoopThreadID;	// main message thread ID
extern ProcessLog RefCount;			// Log of Attached Processes
extern bool InDebugMode;			// debug mode flag

// Application Windows Messages
#define WM_NOTIFY_MSG			WM_USER+100
#define WM_REPORT_ERR			WM_USER+101
#define WM_SERVICE_EXIT			WM_USER+102

#endif
