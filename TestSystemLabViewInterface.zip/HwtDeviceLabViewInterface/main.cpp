
#include "stdafx.h"
#include "main.h"
#include "Interface.h"
#include "external\IndirectCallTypeDef.h"
#include "ClientObject.h"
#include "external\RPC_Tools.h"

HMODULE This_Lib = NULL;

LVClientObject Client("HwtDeviceCommonInterface");

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:	// Init Code here
			This_Lib = (HMODULE)hModule;
			break;

		case DLL_THREAD_ATTACH:		// Thread-specific init code here
			break;

		case DLL_THREAD_DETACH:		// Thread-specific cleanup code here.
			break;

		case DLL_PROCESS_DETACH:	// Cleanup code here
			break;
    }
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////

static int CountCharacters( const char *Str, char ch )
{
	for( int Size = 0, i = 0; Str[i] != '\0'; i++ )
	{
		if( Str[i] == ch )
			Size++;
	}
	return Size;
}

static TStringArray SplitIntoSections( const char *Cmd )
{
	char *Buffer = new char[strlen(Cmd) + 1];	// create temp buffer for use by strtok function
	strcpy( Buffer, Cmd );
	char *ptr;

	int Size = CountCharacters( Buffer, ',' ) + 1;	// Count ',' to determine number of sections

	TStringArray Sections(Size);

	for( int i = 0; i < Size; i++ )		// Extract Sections
	{
		ptr = strtok( (i == 0) ? Buffer : NULL, ",");

		if( ptr != NULL )
		{
			Sections[i] = ptr;
			Sections[i].Trim();
		}
	}

	delete [] Buffer;

	return Sections;
}


static uInt32Array ParseParamInfo( ErrorCluster *error, const TString &ParamInfo )
{
	uInt32Array ParamCodes;

	if( ParamInfo.IsEmpty() )
		return ParamCodes;

	TStringArray Parameters = SplitIntoSections( ParamInfo );

	ParamCodes.Initialize( 0, Parameters.GetSize() );

	for( int i = 0; !error->Status() && i < Parameters.GetSize(); i++ )
	{
		uInt32 ParamCode = 0;

		Parameters[i].MakeUpper();

		char ValRefPtr[4] = { '\0' };
		char ParamType[6] = { '\0' };
		char ParamSize[5] = { '\0' };
		char extra[2]     = { '\0' };

		int cnt = sscanf( Parameters[i], "%3[%&*@]%5[^(]%4[()]%1s", ValRefPtr, ParamType, ParamSize, extra );

		if( cnt < 2 || cnt > 3 )
			error->SetError( 42, "Invalid Parameter Info '%s'", Parameters[i].CStr() );

		else
		{
			if     ( ValRefPtr[0] == '%' && ValRefPtr[1] == '\0' )		ParamCode |= DataTypeByVAL;
			else if( ValRefPtr[0] == '&' && ValRefPtr[1] == '\0' )		ParamCode |= DataTypeByREF;
			else if( ValRefPtr[0] == '*' && ValRefPtr[1] == '\0' )		ParamCode |= DataTypeByPTR;

			else if( ValRefPtr[0] == '@' && ValRefPtr[1] == '%' && ValRefPtr[2] == '\0' )		ParamCode |= DataTypeByVAL | DataTypeRETURN;
			else if( ValRefPtr[0] == '@' && ValRefPtr[1] == '&' && ValRefPtr[2] == '\0' )		ParamCode |= DataTypeByREF | DataTypeRETURN;
			else if( ValRefPtr[0] == '@' && ValRefPtr[1] == '*' && ValRefPtr[2] == '\0' )		ParamCode |= DataTypeByPTR | DataTypeRETURN;

			else
				error->SetError( 42, "Invalid Parameter Info Char '%c'", ValRefPtr[0] );

			if     ( strcmp( ParamType, "I8"   ) == 0 ) ParamCode |= DataTypeI8;
			else if( strcmp( ParamType, "I16"  ) == 0 )	ParamCode |= DataTypeI16;
			else if( strcmp( ParamType, "I32"  ) == 0 )	ParamCode |= DataTypeI32;
			else if( strcmp( ParamType, "I64"  ) == 0 )	ParamCode |= DataTypeI64;
			else if( strcmp( ParamType, "U8"   ) == 0 )	ParamCode |= DataTypeU8;
			else if( strcmp( ParamType, "U16"  ) == 0 )	ParamCode |= DataTypeU16;
			else if( strcmp( ParamType, "U32"  ) == 0 )	ParamCode |= DataTypeU32;
			else if( strcmp( ParamType, "U64"  ) == 0 )	ParamCode |= DataTypeU64;
			else if( strcmp( ParamType, "SGL"  ) == 0 )	ParamCode |= DataTypeSGL;
			else if( strcmp( ParamType, "DBL"  ) == 0 )	ParamCode |= DataTypeDBL;
			else if( strcmp( ParamType, "BOOL" ) == 0 )	ParamCode |= DataTypeBOOL;
			else if( strcmp( ParamType, "STR"  ) == 0 )	ParamCode |= DataTypeSTR;
			else if( strcmp( ParamType, "CSTR" ) == 0 )	ParamCode |= DataTypeCSTR;
			else
				error->SetError( 42, "Invalid Parameter Info Param Type '%s'", ParamType );

			if     ( strcmp( ParamSize, ""     ) == 0 ) ParamCode |= DataTypeNonArray;
			else if( strcmp( ParamSize, "()"   ) == 0 )	ParamCode |= DataTypeArray;
			else if( strcmp( ParamSize, "()()" ) == 0 )	ParamCode |= DataTypeArrayArray;
			else
				error->SetError( 42, "Invalid Parameter Info Param Size '%s'", ParamType );

			ParamCodes[i] = ParamCode;
		}
	}

	return ParamCodes;
}

//////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_DeviceFunctionCall(LV_ErrorCluster *error, LStrHandle FunctionName, LStrHandle ParamInfo, LV_uInt8ArrayHandle Data)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);				// Declare C++ 'ErrorCluster' Class
	uInt8Array C_Data;

	uInt32Array ParamCodes = ParseParamInfo( &Err, TString(ParamInfo) );
	ParamCodes.Insert( TypeErrPTR, 0 );

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( TString(FunctionName) );
		Input.Flatten( ParamCodes );
		Input.Flatten(&Err);
		Input.FlattenRAW(Data);
		Input.BufferStatus(&Err);
		Host->RemoteCall( &Err, Input, Output, "RemDeviceFunction", RemDeviceFunction );
		Output.unFlatten(&Err);
		Output.unFlattenRAW(&C_Data);
		Output.BufferStatus(&Err);
	}

	C_Data.SetLV_Array( &Err, &Data );  // Update LabVIEW String

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_UplinkFunctionCall(LV_ErrorCluster *error, LStrHandle FunctionName, LStrHandle ParamInfo, LV_uInt8ArrayHandle Data)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);				// Declare C++ 'ErrorCluster' Class
	uInt8Array C_Data;

	uInt32Array ParamCodes = ParseParamInfo( &Err, TString(ParamInfo) );
	ParamCodes.Insert( TypeErrPTR, 0 );

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( TString(FunctionName) );
		Input.Flatten( ParamCodes );
		Input.Flatten(&Err);
		Input.FlattenRAW(Data);
		Input.BufferStatus(&Err);
		Host->RemoteCall( &Err, Input, Output, "RemUplinkFunction", RemUplinkFunction );
		Output.unFlatten(&Err);
		Output.unFlattenRAW(&C_Data);
		Output.BufferStatus(&Err);
	}

	C_Data.SetLV_Array( &Err, &Data );  // Update LabVIEW String

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_DeviceAndUplinkFunctionCall(LV_ErrorCluster *error, LStrHandle FunctionName, LStrHandle ParamInfo, LV_uInt8ArrayHandle Data)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);				// Declare C++ 'ErrorCluster' Class
	uInt8Array C_Data;

	uInt32Array ParamCodes = ParseParamInfo( &Err, TString(ParamInfo) );
	ParamCodes.Insert( TypeErrPTR, 0 );

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( TString(FunctionName) );
		Input.Flatten( ParamCodes );
		Input.Flatten(&Err);
		Input.FlattenRAW(Data);
		Input.BufferStatus(&Err);
		Host->RemoteCall( &Err, Input, Output, "RemDeviceAndUplinkFunction", RemDeviceAndUplinkFunction );
		Output.unFlatten(&Err);
		Output.unFlattenRAW(&C_Data);
		Output.BufferStatus(&Err);
	}

	C_Data.SetLV_Array( &Err, &Data );  // Update LabVIEW String

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_ControllerDebugFunctionCall(LV_ErrorCluster *error, LStrHandle FunctionName, LStrHandle ParamInfo, LV_uInt8ArrayHandle Data)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);				// Declare C++ 'ErrorCluster' Class
	TString C_FunctionName(FunctionName);	// Declare C++ 'TString' Class
	uInt8Array C_Data;

	bool OmitErrorCluster = C_FunctionName[0] == '-';
	C_FunctionName.TrimLeft("-");

	uInt32Array ParamCodes = ParseParamInfo( &Err, TString(ParamInfo) );

	if( !OmitErrorCluster )
		ParamCodes.Insert( TypeErrPTR, 0 );

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( C_FunctionName );
		Input.Flatten( ParamCodes );
		if( !OmitErrorCluster )
			Input.Flatten(&Err);
		Input.FlattenRAW(Data);
		Input.BufferStatus(&Err);
		Host->RemoteCall( &Err, Input, Output, "RemControllerDebugFunction", RemControllerDebugFunction );
		Output.unFlatten(&Err);
		Output.unFlattenRAW(&C_Data);
		Output.BufferStatus(&Err);
	}

	C_Data.SetLV_Array( &Err, &Data );  // Update LabVIEW String

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_ControllerDirectAccessFunctionCall(LV_ErrorCluster *error, LStrHandle FunctionName, LStrHandle ParamInfo, LV_uInt8ArrayHandle Data)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);				// Declare C++ 'ErrorCluster' Class
	TString C_FunctionName(FunctionName);	// Declare C++ 'TString' Class
	uInt8Array C_Data;

	bool OmitErrorCluster = C_FunctionName[0] == '-';
	C_FunctionName.TrimLeft("-");

	uInt32Array ParamCodes = ParseParamInfo( &Err, TString(ParamInfo) );

	if( !OmitErrorCluster )
		ParamCodes.Insert( TypeErrPTR, 0 );

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( C_FunctionName );
		Input.Flatten( ParamCodes );
		if( !OmitErrorCluster )
			Input.Flatten(&Err);
		Input.FlattenRAW(Data);
		Input.BufferStatus(&Err);
		Host->RemoteCall( &Err, Input, Output, "RemControllerDirectAccessFunction", RemControllerDirectAccessFunction );
		Output.unFlatten(&Err);
		Output.unFlattenRAW(&C_Data);
		Output.BufferStatus(&Err);
	}

	C_Data.SetLV_Array( &Err, &Data );  // Update LabVIEW String

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}
