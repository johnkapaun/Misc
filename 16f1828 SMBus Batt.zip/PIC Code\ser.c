/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: ser.c
*   revision: 1.0
*   date: 1/19/15 9:52p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* This will write (TX) the txfifo buffer. It will handle
* the transmission. The enable is done in main.c during the
* initialization.
*
*******************************************************************************/

#include <pic.h>
#include <stdlib.h>
#include <stdio.h>
#include "globals.h"

//	unsigned char txfifo[10];	// Transmit Buffer

void SendData(void)
{

// The TXIF interrupt can be enabled by setting the TXIE
// interrupt enable bit of the PIE1 register. However, the
// TXIF flag bit will be set whenever the TXREG is empty,
// regardless of the state of TXIE enable bit.
//	GIE = 0; 	// Disable global Interrupts while sending data

	SMBusTimeOut=0;
 	if(TXIF == 1/* && TRMT == 1*/)
	{
		// Send buffer based on the number of characters specified by txfifo[0]
		for( unsigned char a = 1; a <= 10; a++)
		{
			TXREG = txfifo[a];  // The transmission of the Start bit, 
								// data bits and Stop bit sequence commences 
								// immediately following the transfer of the 
								// data to the TSR from the TXREG.
			
			// TXIF may not be valid for one instruction cycle. This will 
			// poll the flag looking for the TXREG to become empty indicating
			// the data has been shifted to TSR.  Polling 500 times eliminates
			// a lockup condition that may occur if something 'bad' happens.		
			for( int poll = 0; poll < 500 && TXIF != 1; poll++);
		}
		
		status &= 0b11011111;	// Clear TREG Busy Flag
	}
	else
		status |= 0b0010000; 	// TXREG Busy, Transmit Not Made
		
//	GIE = 1; 	// Re-enable global Interrupts
	
//	TXEN = 0;	// Disable the transmitter (not using interrupt)
	
}	// End SendData

void WaitForSSP1IF(void)
	{
		int n;
		for(n = 0; n < 1600 && SSP1IF != 1; n++);
	}
void WaitForACKTIMnot(void)
	{
		int n;
		for(n = 0; n < 1600 && ACKTIM != 0; n++);
	}
void WaitForACKTIM(void)
	{
		int n;
		for(n = 0; n < 1600 && ACKTIM != 1; n++);
	}

