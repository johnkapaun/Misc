﻿Imports System.Windows.Forms
Imports System.Collections.Specialized

Public Class equipmentClass



    Public Function scanEquipment(ByVal strConfigEquipment As String) As String
        Dim colConfigList As stringcollection
        Dim eqForm As frmEquipment
        Dim intI As Integer
        Dim intJ As Integer
        Dim strEquipmentTable As String
        Dim arrEquipmentTable As String(,)
        Try
            '
            colConfigList = New StringCollection
            colConfigList.AddRange(Split(strConfigEquipment, ";"))
            '
            eqForm = New frmEquipment
            eqForm.ConfigEquipment = colConfigList
            eqForm.ShowDialog()
            '
            arrEquipmentTable = eqForm.EquipmentList
            '
            strEquipmentTable = ""
            For intI = 0 To arrEquipmentTable.GetUpperBound(0)
                For intJ = 0 To arrEquipmentTable.GetUpperBound(1)
                    strEquipmentTable = strEquipmentTable & arrEquipmentTable(intI, intJ) & ";"
                Next
                '
                ' remove the very last semicolon from the string 
                strEquipmentTable = Left(strEquipmentTable, strEquipmentTable.Length - 1)
                ' make sure no extra line feeds at the end
                If intI < arrEquipmentTable.GetUpperBound(0) Then
                    strEquipmentTable = strEquipmentTable & vbCrLf
                End If
            Next
            '
            Return strEquipmentTable
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION scanEquipment")
            Return Nothing
        End Try
    End Function

End Class
