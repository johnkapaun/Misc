/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: main.c
*   revision: 1.0
*   date: 1/19/15 8:37p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* This source code file contains the intialization PIC setup.  After the PIC 
* has been setup, a while loop will execute.  If  the instrument has been 
* configured to run in the �Normal� or �ADC Trim� mode, ADC conversions will 
* be executed here.  An average (5 measurements) of the ADC_Conversions are 
* used to report the Supply In RSOC.  The ADC_Conversion is as follows:  
*			Volts = (Raw_ADC/1023) * 4.096 
* The RSOC is reported as a ratio of the averaged ADC measurment with respect 
* to a battery range provided at the top of this file.  Batt_High  (0x33A; 15V) 
* and  Batt_Low = (0x295;  12V)  provide the limits and range.  RSOC is calculated 
* as follows:
*	RSOC = ( ADC_Conversion - Batt_Low)/Batt_Range))*100);  
*	Where: 
*		Batt_Range = Batt_High  - Batt_Low
* When an ADC Trim is being made, the ADC_Conversion is uplinked to the PC.  
* When the device is in �Normal� mode, the RSOC will be stored in index 0 
* of the primary data array.  Index 3 will contain the PEC/8-bit crc for this 
* value (see crc.h in the Appendix of this document).  This allows for the 
* instrument to transmit the calculated RSOC to the controller on the SMBus.
*
* Please note that the ADC_Conversion requires and ADC_Offset trim.  
* This value is available just below the following includes in this file.
*
*******************************************************************************/

#include <pic.h>
#include <htc.h>
#include "globals.h";
//#include "crc.h";
#include "delay.h";

// ADC TRIMS ARE SET HERE.
// The ADC_Offset is the trim.  This LV VI used to verify this
// value will provide an offset adjustment.  This value needs
// to be added or subtracted from the value defined here.
//		new ADC_Offset = current ADC_Offset +/- LV reported value
// Batt_High and Batt_Low are used to define the percent range
// for RSOC. Do not add an offset to the Batt_High or Batt_Low values.

int ADC_Offset=0;	//??? Read from EEPROM when initialized or mode4 changes
//??? int Batt_High = 0x33A;	// 15 Volts*.2206*1023/4.096
//??? int Batt_Low = 0x295;	// 12 Volts


// This is configuration word.  They are defined in pic16lf1828.h and
// are used to configure the chip upon power up.

 __CONFIG(FCMEN_OFF & MCLRE_OFF & BOREN_OFF & CPD_OFF & CP_OFF & CLKOUTEN_OFF & IESO_OFF & PWRTE_OFF & WDTE_OFF & FOSC_INTOSC & LVP_ON & PLLEN_ON);

// This is the starting point of this code upon power-up.  When the device
// is turned on, the registers will be configured or setup for serial 
// communication and the device inputs and outputs will be configured. 
void main(void)
{
// This following will setup everything needed for the serial interface.
// and the inputs and outputs.  If parameters are changed from these starting 
// values by functions executing within this code structure they should be reset 
// by that function before exiting the call.

	// This sets the internal clock frequency.  Much of this was done using
	// configuration word 1&2 (see __CONFIG in main)
	OSCCON = 0xF0;		// 32MHz internal clock
						// The FOSC bits in Configuration Word 1 must be
						// set to use the INTOSC source as the device
						// system clock (FOSC<2:0> = 100).
						// The IRCF bits in the OSCCON register must be
						// set to the 8 MHz HFINTOSC selection
						// (IRCF<3:0> = 1110).
						// The SPLLEN bit in the OSCCON register must be
						// set to enable the 4xPLL, or the PLLEN bit of the
						// Configuration Word 2 must be programmed to a
						// �1'

	// This configures special items. This device has two registers to configure functions on
	// to alternate pins.  The default settings are being used.
	APFCON0 = 0b00000000;	// ALTERNATE PIN FUNCTION CONTROL
							// RXDTSEL SDOSEL(1) SSSEL(1) � T1GSEL TXCKSEL � �
							// Using the default settings.
	APFCON1 = 0b00000000;	// � � � � P1DSEL P1CSEL P2BSEL CCP2SEL
							// Using the default settings.
	
	// The following will set up the communications (TX and RX) rate.  This
	// is setting the prescale factors.  The rate is relative to the FOSC.
	SPBRG = 0x22;		// baud rate = ~57600 (57140)
						// SYNC = 0, BRGH = 0, BRG16 = 1
						// calc baud rate err ~-0.79% for 57600
	
	RCSTA = 0b10110000;	// SPEN RX9 SREN CREN ADDEN FERR OERR RX9D
						// SPEN will enable the EUSART and the TX/CK pin is automatically made an 
						// output. Since the PIN maybe used for some analog function, it must be 
						// disabled by clearing the corresponding bit of the ANSEL register
						
	TXSTA = 0b00100000;	//	TRANSMIT STATUS AND CONTROL REGISTER
						//	CSRC TX9 TXEN SYNC SENDB BRGH TRMT TX9D
	
	BAUDCON = 0b0001000;// ABDOVF RCIDL � SCKP BRG16 � WUE ABDEN
	
	// This sets the fixed voltage reference for the ADC
	FVRCON = 0b10000011;// FVRCON: FIXED VOLTAGE REFERENCE CONTROL REGISTER
						// FVREN FVRRDY Reserved Reserved CDAFVR1 CDAFVR0 ADFVR1 ADFVR0
						// FVRRDY is a status flag but will always read as set
						// ADFVR1 ADFVR0 set the ref to 4x or 4.096 volts

	ADCON0 = 0b00000000;// Start with ADC disconnected.


	ADCON1 = 0b10100011;// ADCON1: A/D CONTROL REGISTER 1
						// ADFM ADCS<2:0> � ADNREF ADPREF<1:0>  
						// The msb (set to 1) will cause 
						// the data to be right justified
						// making the conversion easier. 
						// This also sets the conversion
						// clock cycle to FOSC/32 (1 us)per bit.
						// ADPREF of 11, sets the reference
						// voltage to internal 4.096 (4x).

	// These configure port A that will be digital outputs and analog in...	
	PORTA = 0b00000000;	// Power up values are okay.  Init Port: RA0 to RA5...
	
	TRISA = 0b00010000; 	// TRISA: PORTA TRI-STATE REGISTER
							// � � TRISA5 TRISA4 TRISA3 TRISA2 TRISA1 TRISA0
							// bit set = input bit cleared = output
							// RA4 is 3.3v regulator output.

	
	ANSELA = 0b00000000;	// ANSELA: PORTA ANALOG SELECT REGISTER
							// � � � ANSA4 � ANSA2 ANSA1 ANSA0
							// bit set = Analog bit cleared = digital

	// These configure port B that will be digital outputs and analog in...
	//  RB4 = SDA		RB5 = RX		
	//  RB6 = SCLK		RB7 = TX
	PORTB = 0b00000000;	// Power up values are okay.  Init Port: RB4, RB5, RB6, RB7...
	
//	TRISB = 0b00110000; 	// TRISB: PORTB TRI-STATE REGISTER
							// TRISB7 TRISB6 TRISB5 TRISB4 � � � �
							// bit set = input bit cleared = output
	
	ANSELB = 0b00000000;	// ANSELB: PORTB ANALOG SELECT REGISTER
							// ANSB7 ANSB6 ANSB5 ANSB4 � � � �
							// bit set = Analog bit cleared = digital
	
	// This sets up the SMBus baud rate, address, and slave mode
	SSP1STAT = 0b11000000;	// SMP CKE D/A P S R/W UA BF (Status..mainly)
							// (b7)Slew rate control disabled for standard speed mode (100 kHz and 1 MHz)
							// (b6)Enable input logic so that thresholds are compliant with SMbus specification
							   	
//???	SSP1CON1 = 0b00100110;	// WCOL SSP1OV SSP1EN CKP SSP1M<3:0>
	SSP1CON1 = 0b00110110;	// WCOL SSP1OV SSP1EN CKP SSP1M<3:0>
							// (b5)Enables the serial port and configures the SDA and SCL pins as the source of the serial port pins
							// (b4) 0 = Holds clock low (clock stretch). (Used to ensure data setup time.)??Want this??
							// (b3-0) I2C Slave mode, 7-bit address with Start and Stop bit interrupts enabled


	SSP1CON3 = 0b00001011;	// SDAHT: SDA Hold Time Selection bit (set this because it looks like
//???	SSP1CON3 = 0b00001000;	// SDAHT: SDA Hold Time Selection bit (set this because it looks like
							// there is a lot of capacitance.  This is also a 'Normal' setting
							// for this IC when connectors are being used in the communications
							// path.
//	SSP1MSK = 0b11111110;	// Mask and Address. Bits set in Mask indicates bit that are
 	SSP1ADD = 0b00010110;	// compared. Bit 0 is not ever tested (Address = 0x16)
							// Baud Rate is also set in SSP1ADD. Rate is as follows:
							// FCLOCK (100kHz BRG 0x4F) = FOSC(32MHz)/(4(SSP1ADD+1))
	// These configure port C that will be digital outputs and analog in...
	//		RC3 = AN7 (Supply Measurement)
	//		RC1 = AN5 (Battery Measurement)
	PORTC = 0b00000000;	// Power up values are okay.  Init Port: RC0 to RC7..
	
	TRISC = 0b01011111; 	// TRISC: PORTC TRI-STATE REGISTER ??????
							// TRISC7(1) TRISC6(1) TRISC5 TRISC4 TRISC3 TRISC2 TRISC1 TRISC0
							// bit set = input bit cleared = output

	ANSELC = 0b00001010;	// ANSELC: PORTC ANALOG SELECT REGISTER 
							// ANSC7(1) ANSC6(1) � � ANSC3 ANSC2 ANSC1 ANSC0
							// All of PortC = Digital output
							// MWM 24jun2015 change 0b10000010 to 0b00001010
							//    since AN7 is RC3 for Supply ADC - no effect
	
	// This can be used to set up a timer. It may be useful for placing
	// time stamps on the SMBus but I'm not sure if that is real useful.
	//OPTION_REG = 0b00000100;		// WPUEN INTEDG TMR0CS TMR0SE PSA PS<2:0>
									// PSA cleared to assign a prescaler
									// PS<2:0> of 0x100 sets the prescaler to 1:32
									// And the Timer mode is selected by clearing the
									// TMR0CS bit of the OPTION register (FOSC/4).
	
	// This sets up Timer0 for uplinking Battery Cut Out count
	OPTION_REG = 0b10000110;		// PS<2:0> of 0x110 sets the prescaler to 1:128
							// MWM 24jun2015 WPUEN_not must be set if OPTION_REG is
							// written to here else pullup is on AN7 - Supply ADC

	// This enables the interrupts (also contains some flags)
	INTCON = 0b11100000;// GIE PEIE TMR0IE INTE IOCIE TMR0IF INTF IOCIF

	SSP1CON2 = 0b00000001;	//??? Set SEN(b0) to enable clock stretching in SLAVE Receive Mode.
							// Clock stretching is automatic for SLAVE transmit mode.
							// Placed here after Slave mode is set up.
	PIE1 = 0b00101000;	// TMR1GIE ADIE RCIE TXIE SSP1IE CCP1IE TMR2IE TMR1IE
	PIR1 = 0b00000000;	// TMR1GIF ADIF RCIF TXIF SSP1IF CCP1IF TMR2IF TMR1IF (clear Flags)

	CM1CON0 = 0b10000110; // C1OUT set if Battery is off
                              // C1ON(1) C1OUT(OUT)   C1OE(0:RA1,p17) C1POL(0)
                              // -       C1SP(0:slow) C1HYS(1)        C1SYNC(0)
	CM1CON1 = 0b10010001; // Connect C1 Neg in to C12IN1(RC1) and Pos in
                              // to DAC with C1IF on pos edge
	DACCON0 = 0b10000000; //DACEN(1)
  	DACCON1 = 0b00001000; // - - - DACR4 DACR3 DACR2 DACR1 DACR0  01000 = 25% FS



  	PIE2 = 0b00100000;	// OSFIF C2IF C1IF EEIF BCLIF - - CCP2IF


	// The following is done here to avoid recalculating it (save instruction cycles).
	// (I don't always care.)It is used to calculate the percent charge. 
	//???	int Batt_Range =(Batt_High - Batt_Low);

	Test_Mode = 0x00; 	// Start in 'Normal' Mode 

//// write EEPROM CODE start *****************************************
//// Need to uncomment include "crc.h" to run this code or comment out
////		to save program space if needed.
//// Also need to change ADC offset in the loop bellow
////		for each fixture per the following table.
//// Be sure to uncheck the EEPROM Data Enabled box in the PICKit 2 programmer GUI
////		before programming if this EEPROM CODE block is disabled.	
////
////		Fixture		VSupply ADC offset	VBatt ADC offset			
////		SN1				-10					 0
////		SN2				-8					n/a
////		SN3				-3					n/a
////		SN4				 0					 0
////		SN5				 0					 0
////		SN6				-1					-1
////		SN7				-13					-14
//	unsigned char x,i;
//	int value;
//
//	GIE = 0;
//  	for(x = 0; x < 103; x++)
//  	{
//		if (x==101)			// EEADRL=102;
//			value=-8;		// VSupply ADC offset - update this for each Test Fixture!!!
//		else if (x==102)	// EEADRL=103;
//			value=-1;		// VBatt ADC offset - update this for each Test Fixture!!!
//		else
//			value=PEC_CRC[x];
// 	 	for(i = 0; i < 5; i++)
//	  	{
//			WREN=1;
//
//			EEDATL=value;
//			EEADRL=x+1;			//??? PICKit2 erases Addr 0
//			EECON2=0x55;
//			EECON2=0xAA;
//			WR=1;
//			WREN=0;
//			while(WR!=0);
//			EEIF=0;
//		}
//	GIE = 1;
//	}
//// write EEPROM CODE end ******************************************


	// Do the following forever.
	while(1)	
	{
		// This will read voltage on AN3 over-over again and updates the first 
		// 3 indexes of the Primary Data array.  The intent is so a
		// variable power suppy could be used in place of an actual battery.
	
		// Could use a double to do the average but doubt it is really
		// needed. (Try to keep data space down to < 90% so adding small changes
		// doesn't create a major re-write.)
		int RSOC = 99;  			// Battery Percent Charge (RSOC- this value never used).
		int ADC_Conversion = 0x00;	// Always start at 0 because new conversions
									// will be added.


		ADIF = 0;	// This is the A/D flag. Make sure
					// it is cleared because it will
					// be set any time a conversion is
					// made regaurdless of the interrupt
					// enable.

		//	ADIE = 1;	// This is the interrupt enable.
						// The peripheral interrupt and
						// the global interrupt are also
						// needed for this to be used.
						// (Currently not used)

		if ((Test_Mode == 0x04)&&(ADCON0 == 0b00011101))	// run once after
		{													// changing Test_Mode
			ADCON0 = 0b00001101;	// Sets 3.3V Reg channel (AN3) and turns on
			ADC_Offset = 0;			// the ADC. Regulated 3.3V ADC offset=0.
			DelayMs(1000);			// Wait for TMR1 interupt so that VI read
									// will catch the 3.3V measurement
		}
		else if ((Test_Mode == 0x04)&&(ADCON0 == 0b0001101))// run once after
		{													// changing Test_Mode
			ADCON0 = 0b00010101;	// Sets Battery channel (AN5) and turns on
			DelayMs(1);				//  the ADC. Wait for channel to settle
			CutOutCnt=0; 			// Clear Count of Battery cut outs
			EEADRL=103;				// EEPROM Data Addr... Addr 102 is used to
									// store for the Supply channel (AN7) and
									// is retrieved in isr.c
			RD=1;					// Read the EEPROM
			ADC_Offset = EEDATL;	// VBatt ADC offset
		}
		else if ((Test_Mode != 0x02)&&(Test_Mode != 0x04)&&(ADCON0 != 0b0011101))
		{							// if not 'Write Battery' or 'Trim' mode
			ADCON0 = 0b00011101;	// Sets channel (AN7) and turns on the ADC
												// -- CHS<4:0> GO/DONE ADON
			EEADRL=102;				// EEPROM Data Addr
			RD=1;					// Read the EEPROM
			ADC_Offset = EEDATL;	// VSupply ADC offset
		}
		if (ADC_Offset>63)
			ADC_Offset=(int)ADC_Offset | 0xFF00;	// convert 8 bit signed to 16 bit

		// Wait for A2D amp to settle and capacitor to charge.
		// This time is based on the input impedence, cap and
		// voltage.  We aren't switching channel but for now 
		// we are using a fixed 4 uSec delay anyway.
		// This will also track measurments for average
		char x = 0;	// Make local char x to prevent ISR from using it
		for(x = 0; x < 32; x++);// Use instruction cycles

		// Let's do an average of 5 measurements
		for(x = 0; x < 5; x++)
		{ 
			ADGO = 1;	// start the conversion. This bit will be cleared
						// when the conversion completes.
				
			// Please note that a conversion takes:
			// 1/(FOSC/64) * (10 bits + 1) or 22 uSec to complete when 
			// the OSC is set to 32 mHz and ADCS<2:0> of ADCON1 is set
			// to FOSC/64.
			while(ADGO) continue;  	// Poll for the conversion to
									// complete.  You don't need
									// the interrupt flag.
		
			// Get the 10 bit result. A trim should be done.  The
			// value (ADC_Offset) is in global.h but is set at the
			// top of this file along with Batt_High and Batt_Low.
			//		Volts = (Raw_ADC/1023) * 4.096

			ADC_Conversion += (int)((ADRESH << 8) | ADRESL) + ADC_Offset; 
		}
			
		ADC_Conversion = (ADC_Conversion/x); // Set the average
		
		if(ADC_Conversion >= 0x33A)			// Batt_High 
			RSOC = 100;
		else if(ADC_Conversion <= 0x295)	// Batt_Low
			RSOC = 0;
		else
			RSOC = (int)(((double)( ADC_Conversion - 0x295)/(0x33A-0x295))*100); // Just returns a rough %. 
																				 // Batt_High Batt_Low	
					
		// This is used for the ADC_Offset Trim.  It will transmit
		// the MSB followed by the LSB of the most recent conversion.
		// This value is always read and sent 
			txfifo[7] = (char)((ADC_Conversion >> 8) & 0x00FF); // Send ADC MSB
			txfifo[8] = (char)(ADC_Conversion & 0x00FF); 		// Send ADC LSB


		if(Test_Mode == 0x00)	// If not Test Mode
		{	
			GIE = 0;
			// Set Primary_Data array with new values
			Primary_Data[0] = RSOC; 			// New charge Value (RSOC)
			Primary_Data[1] = 0x00;				// Is this ever used?
			EEADRL=RSOC+1;						// EEPROM Data Addr
			RD=1;								// Read the EEPROM
			Primary_Data[2] = EEDATL;			// Here is the CRC
			txfifo[6] = RSOC;
			GIE = 1;
//	RC5=0;	// PIC Pin 5 Scope 17.4uS trigger
//	for(x = 0; x < 7; x++) RC5=0;
//	for(x = 0; x < 7; x++) RC5=1;
//	RC5=0;
		}
		if (Test_Mode == 0x04)	// Battery Test Mode
		{
			txfifo[1] = (char)((CutOutCnt >> 8) & 0x00FF);	// Send MSB
			txfifo[2] = (char)(CutOutCnt & 0x00FF); 		// Send LSB
			txfifo[6] = RSOC;
		}
		if(txfifo[0]&&0x06)	// rxfifo[0] = E or Test_mode = 4 TMR
		{
			SendData();
			txfifo[0] = 0x00;	//??? Clear
		}
		if((SMBusTimeOut>10)&&(Test_Mode != 0x04))
		{
			SMBusTimeOut=0;
			SSP1BUF;
			SSPOV = 0;	// Clear overflow bit
			SSP1IF = 0;	// Clear flag
			CKP = 1;	// Enable CLK
		}
	}

}