/* this ALWAYS GENERATED file contains the RPC client stubs */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Aug 25 15:52:49 2008
 */
/* Compiler settings for C:\c_code\HwtDeviceLabViewInterface\external\Interface.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )

#include <string.h>
#if defined( _ALPHA_ )
#include <stdarg.h>
#endif

#include "Interface.h"

#define TYPE_FORMAT_STRING_SIZE   39                                
#define PROC_FORMAT_STRING_SIZE   25                                

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;

/* Standard interface: HWT_CRM_DEV, ver. 1.0,
   GUID={0xc08f354c,0xc4b2,0x4310,{0xae,0xd0,0x39,0x91,0xb2,0x20,0x97,0x1d}} */



static const RPC_CLIENT_INTERFACE HWT_CRM_DEV___RpcClientInterface =
    {
    sizeof(RPC_CLIENT_INTERFACE),
    {{0xc08f354c,0xc4b2,0x4310,{0xae,0xd0,0x39,0x91,0xb2,0x20,0x97,0x1d}},{1,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    0,
    0,
    0,
    0,
    0,
    0
    };
RPC_IF_HANDLE HWT_CRM_DEV_v1_0_c_ifspec = (RPC_IF_HANDLE)& HWT_CRM_DEV___RpcClientInterface;

extern const MIDL_STUB_DESC HWT_CRM_DEV_StubDesc;

static RPC_BINDING_HANDLE HWT_CRM_DEV__MIDL_AutoBindHandle;


void AddRef( 
    /* [in] */ handle_t h1,
    /* [in] */ unsigned long ProcessID)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          0);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = ProcessID;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void Release( 
    /* [in] */ handle_t h1,
    /* [in] */ unsigned long ProcessID)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          1);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U;
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++ = ProcessID;
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemDeviceFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          2);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemUplinkFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          3);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemDeviceAndUplinkFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          4);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemLoadControllerLibrary( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          5);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemLoadDeviceLibrary( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          6);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemID_Device( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          7);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemControllerDLL_FileNames( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          8);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemDeviceDLL_FileName( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          9);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemVerifyCommonDeviceDllVersion( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          10);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemVerifyDeviceSpecificDllVersion( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          11);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemUpdateLocalDLL( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          12);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemFormattedVersionInfo( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          13);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemLoadFirmwareMap( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          14);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemDeviceModelName( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          15);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemCheckForFirmwarePatch( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          16);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemMenuPath( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          17);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemProgramCacheControl( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          18);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemSupportedFunctions( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          19);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemControllerDebugFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          20);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemVerifyHwtDeviceCommonInterface( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          21);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemVerifyAppInterfaceVersions( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          22);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemControllerDirectAccessFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          23);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemDllAndInterfaceVersionInfo( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          24);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


void RemRevisionCheckFile( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut)
{

    RPC_BINDING_HANDLE _Handle	=	0;
    
    RPC_MESSAGE _RpcMessage;
    
    MIDL_STUB_MESSAGE _StubMsg;
    
    if(!DataIn)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!lSizeOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    if(!DataOut)
        {
        RpcRaiseException(RPC_X_NULL_REF_POINTER);
        }
    RpcTryFinally
        {
        NdrClientInitializeNew(
                          ( PRPC_MESSAGE  )&_RpcMessage,
                          ( PMIDL_STUB_MESSAGE  )&_StubMsg,
                          ( PMIDL_STUB_DESC  )&HWT_CRM_DEV_StubDesc,
                          25);
        
        
        _Handle = h1;
        
        
        _StubMsg.BufferLength = 0U + 4U + 4U;
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                      (unsigned char __RPC_FAR *)DataIn,
                                      (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrGetBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg, _StubMsg.BufferLength, _Handle );
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = lSizeIn;
        
        _StubMsg.MaxCount = lSizeIn;
        
        NdrConformantArrayMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                                    (unsigned char __RPC_FAR *)DataIn,
                                    (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6] );
        
        NdrSendReceive( (PMIDL_STUB_MESSAGE) &_StubMsg, (unsigned char __RPC_FAR *) _StubMsg.Buffer );
        
        if ( (_RpcMessage.DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
            NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
        
        *lSizeOut = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
        
        NdrPointerUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR * __RPC_FAR *)&DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20],
                              (unsigned char)0 );
        
        }
    RpcFinally
        {
        NdrFreeBuffer( (PMIDL_STUB_MESSAGE) &_StubMsg );
        
        }
    RpcEndFinally
    
}


static const MIDL_STUB_DESC HWT_CRM_DEV_StubDesc = 
    {
    (void __RPC_FAR *)& HWT_CRM_DEV___RpcClientInterface,
    MIDL_user_allocate,
    MIDL_user_free,
    &HWT_CRM_DEV__MIDL_AutoBindHandle,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x10001, /* Ndr library version */
    0,
    0x50100a4, /* MIDL Version 5.1.164 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    1,  /* Flags */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {
			0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  2 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/*  4 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/*  6 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  8 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 10 */	
			0x4d,		/* FC_IN_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 12 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */
/* 14 */	
			0x51,		/* FC_OUT_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 16 */	NdrFcShort( 0x10 ),	/* Type Offset=16 */
/* 18 */	
			0x51,		/* FC_OUT_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 20 */	NdrFcShort( 0x14 ),	/* Type Offset=20 */
/* 22 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x0,	/* FC_RP */
/*  4 */	NdrFcShort( 0x2 ),	/* Offset= 2 (6) */
/*  6 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/*  8 */	NdrFcShort( 0x1 ),	/* 1 */
/* 10 */	0x28,		/* Corr desc:  parameter, FC_LONG */
			0x0,		/*  */
#ifndef _ALPHA_
/* 12 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 14 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */
/* 16 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 18 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 20 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] */
/* 22 */	NdrFcShort( 0x2 ),	/* Offset= 2 (24) */
/* 24 */	
			0x12, 0x0,	/* FC_UP */
/* 26 */	NdrFcShort( 0x2 ),	/* Offset= 2 (28) */
/* 28 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 30 */	NdrFcShort( 0x1 ),	/* 1 */
/* 32 */	0x28,		/* Corr desc:  parameter, FC_LONG */
			0x54,		/* FC_DEREFERENCE */
#ifndef _ALPHA_
/* 34 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 36 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */

			0x0
        }
    };
