// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__F3973C22_5450_11D6_B4F9_FB23C9D2552B__INCLUDED_)
#define AFX_STDAFX_H__F3973C22_5450_11D6_B4F9_FB23C9D2552B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>

// TODO: reference additional headers your program requires here
#include <windows.h>
#include <string.h>
#include <ctype.h>
#include <iostream>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <process.h>

//#include <string>
//#include <list>
//#include <vector>
//#include <deque>
//#include <set>
using namespace std ;

#pragma pack(push,1)
#include "external\extcode.h"
#include "external\tstring.h"
#include "external\crm_dev.h"
#include "external\tarray.h"
#pragma pack(pop)

#include "external\rpc_tools.h"

#ifndef HWND_MESSAGE
#define HWND_MESSAGE     ((HWND)-3)
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__F3973C22_5450_11D6_B4F9_FB23C9D2552B__INCLUDED_)
/*
#include <windows.h>
#include <string.h>
#include <ctype.h>
#include <iostream.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <io.h>
#include <process.h>
#include "external\extcode.h"
*/
