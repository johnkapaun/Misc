#include "stdafx.h"
#include "main.h"
#include "Interface.h"
#include "external\IndirectCallTypeDef.h"
#include "ClientObject.h"
#include "ResourceLock.h"


/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
//////////////// LabVIEW Client Object //////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

LVClientObject::LVClientObject( TString ServerName, TString PipeName )
{
	RemoteApp = NULL;
	mServerName = ServerName;
	mPipeName   = PipeName;
	mPortNumber = 0;
	mAppName = "";

	InitializeCriticalSection(&RemoteAppPtrCriticalSection);	// Initialize
}

LVClientObject::LVClientObject( TString ServerName, uInt16 PortNumber )
{
	RemoteApp = NULL;
	mServerName = ServerName;
	mPipeName   = "";
	mPortNumber = PortNumber;
	mAppName = "";

	InitializeCriticalSection(&RemoteAppPtrCriticalSection);	// Initialize
}

LVClientObject::LVClientObject( TString AppName )
{
	RemoteApp = NULL;
	mServerName = "";
	mPipeName   = "";
	mPortNumber = 0;
	mAppName = AppName;

	InitializeCriticalSection(&RemoteAppPtrCriticalSection);	// Initialize
}

LVClientObject::~LVClientObject()
{
	if( RemoteApp != NULL )
	{
		ErrorCluster Err;
		RemoteApp->RemoteCall( &Err, GetCurrentProcessId(), "Release", Release );

		delete RemoteApp;
		RemoteApp = NULL;
	}

	DeleteCriticalSection(&RemoteAppPtrCriticalSection);	// release resources
}

void LVClientObject::RegisterApplication(ErrorCluster *error)
{
	if( RemoteApp == NULL || error->Status() == true )
		return;

	ApplicationResourceLock Lock( error, true );

	if( error->Status() == true )
		return;

	RemoteApp->RemoteCall( error, GetCurrentProcessId(), "AddRef", AddRef );

	if( error->Status() == true )
	{
		error->ResetStatus();

		if( _spawnl( _P_NOWAIT, "c:\\CRM_HWT\\Interface\\HwtDeviceCommonInterface.exe", "", NULL ) == -1 )
			error->SetError( 42, "Unable to Start 'HwtDeviceCommonInterface'" );

		if( error->Status() == false )	// If we started 'HwtDeviceCommonInterface' 
		{
			for( int i = 0; i == 0 || (error->Status() == true && i < 5); i++ )
			{
				error->ResetStatus();
				Sleep(1000);
				RemoteApp->RemoteCall( error, GetCurrentProcessId(), "AddRef", AddRef );
			}
		}
	}

	if( !error->Status() )
		InstallApplicationHook();
}

ClientObject* LVClientObject::RemoteAppPtr(ErrorCluster *error)
{
	if( error->Status() )
		return NULL;

	EnterCriticalSection(&RemoteAppPtrCriticalSection);

	if( RemoteApp == NULL )
	{
		if( !mAppName.IsEmpty() )
			RemoteApp = new ClientObject( error, mAppName );

		else if( !mPipeName.IsEmpty() )
			RemoteApp = new ClientObject( error, mServerName, mPipeName );

		else
			RemoteApp = new ClientObject( error, mServerName, mPortNumber );

		RegisterApplication( error );

		if( error->Status() == true )
		{
			delete RemoteApp;
			RemoteApp = NULL;
		}
	}

	LeaveCriticalSection(&RemoteAppPtrCriticalSection);

	return RemoteApp;
}
