﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace EquipmentBarcodeScanner
{
    public class manageEquipment
    {

        #region exposed properties

        /// <summary>
        /// Equipment description from the config file. Separated by semicolons
        /// </summary>
        public string ConfigEquipment
        {
            set { g_strListOfEquipmentFromConfigFile = value; }
        }

        /// <summary>
        /// The list of equipmet to pre-populate the table with
        /// </summary>
        public string InitialEquipment
        {
            set { g_strInitialEquipment = value; }
        }

        /// <summary>
        /// Test Executor name
        /// </summary>
        public string TestExecutor
        {
            set { g_strTestExecutor = value; }
        }

        /// <summary>
        /// Test name
        /// </summary>
        public string TestName
        {
            set { g_strTestName = value; }
        }

        #endregion

        private string g_strListOfEquipmentFromConfigFile = "";
        private string g_strTestExecutor = "";
        private string g_strTestName = "";
        private string g_strInitialEquipment = "";



        /// <summary>
        /// things that need to be defined 
        /// ConfigEquipment : a string containing equipment from the test config file 
        ///                     separated by semi-colons
        /// InitialEquipment : a string containing initial equipment to be displayed 
        ///                     to the user separated by semi-colons
        /// TestExecutor : the name of the test executor 
        /// TestName : The name of the test
        /// </summary>
        /// <returns></returns>
        public string scanEquipment()
        {
            try
            {
                frmMain mainForm = new frmMain();
                mainForm.ConfigFileEquipment = g_strListOfEquipmentFromConfigFile;
                mainForm.TestExecutor = g_strTestExecutor;
                mainForm.TestName = g_strTestName;
                mainForm.InitialEquipment = g_strInitialEquipment;
                mainForm.TopMost = true;
                mainForm.ShowDialog();
                return mainForm.EnteredEquipment;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }


        }




    }
}
