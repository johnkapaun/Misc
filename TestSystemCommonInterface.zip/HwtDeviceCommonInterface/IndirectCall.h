
class IndirectFunctionCallStack
{
	struct ParamTrackingInfo
	{
		ParamTrackingInfo( uInt32 DataType, void *Stack )
		{
			Type = DataType;
			StackPtr = Stack;
		}

		uInt32 Type;
		void *StackPtr;
	};

	typedef deque<ParamTrackingInfo, allocator<ParamTrackingInfo> >   ParamInfoList;

	private:
		unsigned char *CallStack;
		int StackSize;
		ParamInfoList ParamInfo;
		TString FunctionName;
		unFlattenData *DataIn;
		FlattenData *DataOut;
		bool FunctionCallComplete;
		int ReturnValuePassedInRegisters;	// 0 = None, 1 = EDX:EAX, 2 = float32, 3 = float64

	public:
		IndirectFunctionCallStack(void);
		~IndirectFunctionCallStack();

		void FunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut );
		void DirectControllerObjectFunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut );
		void DebugControllerFunctionCall( ErrorCluster *error, unFlattenData *FlatDataIn, FlattenData *FlatDataOut );

	private:
		void unFlattenFunctionCall( ErrorCluster *error );
		void FunctionCall( void *IndirectFunction, void *ThisPtr = NULL);
		void FlattenResults( ErrorCluster *error );
		void AdjustStackForReturnValue( ErrorCluster *error, uInt32 DataType );

		bool HasValidVTable( void *ptr ) { return *((void**)ptr) != NULL; }

		int DeleteMethod( const ParamTrackingInfo &Param, void *ptr );
		bool Ptr_Or_PtrToPtr( const ParamTrackingInfo &Param );
		bool OutputData( ErrorCluster *error, const ParamTrackingInfo &Param );

	private:
		void unFlattenERR( ErrorCluster *error, uInt32 DataType );
		void FlattenERR( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenSTR( ErrorCluster *error, uInt32 DataType );
		void FlattenSTR( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenI8( ErrorCluster *error, uInt32 DataType );
		void FlattenI8( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenI16( ErrorCluster *error, uInt32 DataType );
		void FlattenI16( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenI32( ErrorCluster *error, uInt32 DataType );
		void FlattenI32( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenU8( ErrorCluster *error, uInt32 DataType );
		void FlattenU8( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenU16( ErrorCluster *error, uInt32 DataType );
		void FlattenU16( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenU32( ErrorCluster *error, uInt32 DataType );
		void FlattenU32( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenFloat32( ErrorCluster *error, uInt32 DataType );
		void FlattenFloat32( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenFloat64( ErrorCluster *error, uInt32 DataType );
		void FlattenFloat64( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenBOOL( ErrorCluster *error, uInt32 DataType );
		void FlattenBOOL( ErrorCluster *error, ParamTrackingInfo &Param );

		void unFlattenCSTR( ErrorCluster *error, uInt32 DataType );
		void FlattenCSTR( ErrorCluster *error, ParamTrackingInfo &Param );
};
