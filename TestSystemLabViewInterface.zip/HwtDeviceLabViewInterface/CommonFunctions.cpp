
#include "stdafx.h"
#include "main.h"
#include "Interface.h"
#include "ClientObject.h"
#include "external\RPC_Tools.h"

extern LVClientObject Client;


extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_LoadControllerLibrary(LV_ErrorCluster *error, LStrHandle DllName, LStrHandle VersionInfo)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_DllName(DllName);		// Declare C++ String
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( C_DllName );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemLoadControllerLibrary", RemLoadControllerLibrary );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_LoadDeviceLibrary(LV_ErrorCluster *error, LStrHandle DllName, LStrHandle DeviceName)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_DllName(DllName);		// Declare C++ String
	TString C_DeviceName;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( C_DllName );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemLoadDeviceLibrary", RemLoadDeviceLibrary );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_DeviceName );
		Output.BufferStatus( &Err );
	}

	C_DeviceName.SetLV_String( &Err, &DeviceName );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_ID_Device(LV_ErrorCluster *error, LStrHandle DllName )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_DllName;				// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemID_Device", RemID_Device );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_DllName );
		Output.BufferStatus( &Err );
	}

	C_DllName.SetLV_String( &Err, &DllName );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_ControllerDLL_FileNames(LV_ErrorCluster *error, LV_stringArrayHandle FileNames, uInt8 IncludePath )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TStringArray C_FileNames;		// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( IncludePath != 0 );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemControllerDLL_FileNames", RemControllerDLL_FileNames );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_FileNames );
		Output.BufferStatus( &Err );
	}

	C_FileNames.SetLV_Array( &Err, &FileNames );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_DeviceDLL_FileName(LV_ErrorCluster *error, LStrHandle FileName, uInt8 IncludePath )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_FileName;				// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( IncludePath != 0 );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemDeviceDLL_FileName", RemDeviceDLL_FileName );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_FileName );
		Output.BufferStatus( &Err );
	}

	C_FileName.SetLV_String( &Err, &FileName );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_VerifyHwtDeviceCommonInterface(LV_ErrorCluster *error, LStrHandle VersionInfo)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemVerifyHwtDeviceCommonInterface", RemVerifyHwtDeviceCommonInterface );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_VerifyAppInterfaceVersions(LV_ErrorCluster *error, LStrHandle VersionInfo)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemVerifyAppInterfaceVersions", RemVerifyAppInterfaceVersions );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_VerifyCommonDeviceDllVersion(LV_ErrorCluster *error, LStrHandle VersionInfo)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemVerifyCommonDeviceDllVersion", RemVerifyCommonDeviceDllVersion );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_VerifyDeviceSpecificDllVersion( LV_ErrorCluster *error, LStrHandle DllName, LStrHandle VersionInfo )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( TString(DllName) );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemVerifyDeviceSpecificDllVersion", RemVerifyDeviceSpecificDllVersion );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_UpdateLocalDLL( LV_ErrorCluster *error, LStrHandle DllName )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( TString(DllName) );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemUpdateLocalDLL", RemUpdateLocalDLL );

		Output.unFlatten( &Err );
		Output.BufferStatus( &Err );
	}

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_FormattedVersionInfo(LV_ErrorCluster *error, LStrHandle VersionInfo)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_VersionInfo;			// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemFormattedVersionInfo", RemFormattedVersionInfo );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_String( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_LoadFirmwareMap(LV_ErrorCluster *error, LStrHandle Path, LStrHandle File, LStrHandle UsedFileName, LStrHandle MissingVariables)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_Path(Path);			// Declare C++ String
	TString C_File(File);			// Declare C++ String
	TString C_UsedFileName;			// Declare C++ String
	TString C_MissingVariables;		// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( C_Path );
		Input.Flatten( C_File );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemLoadFirmwareMap", RemLoadFirmwareMap );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_UsedFileName );
		Output.unFlatten( &C_MissingVariables );
		Output.BufferStatus( &Err );
	}

	C_UsedFileName.SetLV_String( &Err, &UsedFileName );
	C_MissingVariables.SetLV_String( &Err, &MissingVariables );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_DeviceModelName(LV_ErrorCluster *error, LStrHandle ModelName)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_ModelName(ModelName);	// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemDeviceModelName", RemDeviceModelName );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_ModelName );
		Output.BufferStatus( &Err );
	}

	C_ModelName.SetLV_String( &Err, &ModelName );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_CheckForFirmwarePatch(LV_ErrorCluster *error, LV_stringArrayHandle PatchVIs, int32 *ReID_Code)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TStringArray C_PatchVIs;		// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( *ReID_Code );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemCheckForFirmwarePatch", RemCheckForFirmwarePatch );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_PatchVIs );
		Output.unFlatten( ReID_Code );
		Output.BufferStatus( &Err );
	}

	C_PatchVIs.SetLV_Array( &Err, &PatchVIs );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_MenuPath(LV_ErrorCluster *error, LStrHandle Path)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_Path;					// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemMenuPath", RemMenuPath );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_Path );
		Output.BufferStatus( &Err );
	}

	C_Path.SetLV_String( &Err, &Path );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_ProgramCacheControl(LV_ErrorCluster *error, LStrHandle Cache, uInt16 *Cache_State)
{
	// New_Cache_State Values
	// 0 = Disable
	// 1 = Enable
	// 2 = Reset
	// 3 = No Change

	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_Path;					// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( TString(Cache) );
		Input.Flatten( *Cache_State );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemProgramCacheControl", RemProgramCacheControl );

		Output.unFlatten( &Err );
		Output.unFlatten( Cache_State );
		Output.BufferStatus( &Err );
	}

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_SupportedFunctions(LV_ErrorCluster *error, LV_stringArrayHandle RequestedFunctionList, LV_stringArrayHandle SupportedFunctionList )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);										// Declare C++ 'ErrorCluster' Class
	TStringArray C_RequestedFunctionList(RequestedFunctionList);	// Declare C++ String Array
	TStringArray C_SupportedFunctionList;							// Declare C++ String Array

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.Flatten( C_RequestedFunctionList );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemSupportedFunctions", RemSupportedFunctions );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_SupportedFunctionList );
		Output.BufferStatus( &Err );
	}

	C_SupportedFunctionList.SetLV_Array( &Err, &SupportedFunctionList );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_DllAndInterfaceVersionInfo(LV_ErrorCluster *error, LV_stringArrayHandle VersionInfo, LVBoolean *Released, LVBoolean *Match )
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);			// Declare C++ 'ErrorCluster' Class
	TStringArray C_VersionInfo;			// Declare C++ String Array

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemDllAndInterfaceVersionInfo", RemDllAndInterfaceVersionInfo );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_VersionInfo );
		Output.unFlatten( Released );
		Output.unFlatten( Match );
		Output.BufferStatus( &Err );
	}

	C_VersionInfo.SetLV_Array( &Err, &VersionInfo );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}

extern "C" CIN MgErr LABVIEW_INTERFACE_API LabVIEW_RevisionCheckFile(LV_ErrorCluster *error, LStrHandle FilePath)
{
	if (error->status != LVBooleanFalse)  // Check for Error In
		return noErr;

	ErrorCluster Err(error);		// Declare C++ 'ErrorCluster' Class
	TString C_FilePath;				// Declare C++ String

	ClientObject* Host = Client.RemoteAppPtr(&Err);

	if( !Err.Status() )
	{
		FlattenData   Input;
		unFlattenData Output;

		Input.Flatten( &Err );
		Input.BufferStatus( &Err );

		Host->RemoteCall( &Err, Input, Output, "RemRevisionCheckFile", RemRevisionCheckFile );

		Output.unFlatten( &Err );
		Output.unFlatten( &C_FilePath );
		Output.BufferStatus( &Err );
	}

	C_FilePath.SetLV_String( &Err, &FilePath );

	return Err.LVErr(error);	// Update LabVIEW Error Cluster
}
