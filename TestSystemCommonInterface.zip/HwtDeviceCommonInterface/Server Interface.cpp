
#include <StdAfx.h>
#include "Interface.h"
#include "main.h"
#include "ResourceLocks.h"

//////////////////////////////////////////////////////////////////////////////////////

static RPC_STATUS WINAPI Security_Callback( void *Interface, void *Context )
{
	// No additional security checks required
	return RPC_S_OK;
}

// Main Host Server Function
// 
unsigned __stdcall ServerThread( LPVOID lpParameter )
{
//	unsigned char * pszProtocolSequence = (unsigned char *)"ncacn_np";				// Named Pipe
	unsigned char * pszProtocolSequence = (unsigned char *)"ncalrpc";				// Application
//	unsigned char * pszProtocolSequence = (unsigned char *)"ncacn_ip_tcp";			// TCP/IP Port
	unsigned char * pszSecurity			= NULL;
//	unsigned char * pszEndpoint			= (unsigned char *)"\\pipe\\RPC_Service";	// Named Pipe
	unsigned char * pszEndpoint			= (unsigned char *)SZAPPNAME;				// Application
//	unsigned char * pszEndpoint			= (unsigned char *)"52101";					// TCP/IP Port
	unsigned int    cMinCalls			= 200;
	unsigned int    cMaxCalls			= RPC_C_LISTEN_MAX_CALLS_DEFAULT;
	unsigned int    fDontWait			= TRUE;

	// local variables used to track status info
	RPC_STATUS Status = RPC_S_INTERNAL_ERROR;
	int Retry = 0;

	// tell the RPC run-time library to use the specified protocol sequence combined
	// with the specified endpoint for receiving remote procedure calls.
	// Because one copy of this application could be shutting down when another copy is starting up, try several times
	// if a duplicate endpoint error is returned.
	for( Status = RPC_S_DUPLICATE_ENDPOINT, Retry = 0; RPC_S_DUPLICATE_ENDPOINT == Status && Retry <= 3; Retry++ )
	{
		if( Retry > 0 )		// Add a one second delay on retrys to give time for another copy to shutdown
			Sleep(1000);

		Status = RpcServerUseProtseqEp(pszProtocolSequence, cMaxCalls, pszEndpoint, pszSecurity);
	}

	// register the interface with the RPC run-time library
	if( Status == RPC_S_OK )
		Status = RpcServerRegisterIfEx(HWT_CRM_DEV_v1_0_s_ifspec, NULL, NULL, 0, 0, Security_Callback);

	// register the authentication information with the RPC run-time library
	if( Status == RPC_S_OK )
		Status = RpcServerRegisterAuthInfo( NULL, RPC_C_AUTHN_WINNT, NULL, NULL );

	// listen for remote procedure calls
	if( Status == RPC_S_OK )
		Status = RpcServerListen(cMinCalls, cMaxCalls, fDontWait);

	if( Status == RPC_S_OK )
	{
		// Wait for the server application calls RpcMgmtStopServerListening and all active remote
		// procedure calls complete, or a fatal error occurs in the RPC run-time library.
		RpcMgmtWaitServerListen();

		RpcServerUnregisterIf(NULL, NULL, TRUE);

		// Unload Device and Controller DLLs
		ErrorCluster Err;
		LoadControllerLibrary(&Err,"nul");	// unloading the controller DLL also unloads the device DLL
	}

	// Signal the windows message thread to shutdown
	PostMessage( hWnd, WM_SERVICE_EXIT, (WPARAM)0, (LPARAM) 0 );

	return Status;
}

void ServerStop(void)
{
    // Stop's the server, wakes the server's main thread.

    RpcMgmtStopServerListening(0);
}

//////////////////////////////////////////////////////////////////////////////////////

// This function is called by a separate thread for each client application.
// It returns when the client application terminates or disconnects
unsigned __stdcall WaitForProcessExitThread( LPVOID lpParameter )
{
	// Get Process ID - Process ID is passed in via lpParameter
	ProcessInfo Info = RefCount.GetProcessInfo( *( (unsigned long *)lpParameter ) );

	delete ((unsigned long *)lpParameter);	// release memory for passed in data

	if( Info.ProcessID == 0 )	// should never happen, display message box to aid in debugging
	{
		PostMessage( hWnd, WM_REPORT_ERR, (WPARAM)0, (LPARAM)"Invalid ProcessInfo detected in 'WaitForProcessExitThread'" );
		return 0;
	}

	// Get a handle to the specified process with Synchronize Access
	HANDLE hProcess = OpenProcess( SYNCHRONIZE, FALSE, Info.ProcessID );

	if( hProcess != NULL )	// If valid handle received
	{
		HANDLE lpHandles[2];				// Build array of two handles to wait on
		lpHandles[0] = hProcess;			// process (waiting for process to terminate)
		lpHandles[1] = Info.ReleaseEvent;	// Event handle (received when process disconnects)

		// wait for process to terminate or disconnect
		DWORD Reason = WaitForMultipleObjects( 2, lpHandles, FALSE, INFINITE );

		if( Reason == WAIT_OBJECT_0 )					// should always be 'WAIT_OBJECT_0' but check anyway
			RefCount.ReleaseProcess( Info.ProcessID );	// if not already done, remove process from client list

		CloseHandle( hProcess );	// close the process handle
		CheckForActiveClients();	// check if all Client applications have closed, if so, shutdown server
	}
	else	// should never happen, display message box to aid in debugging
		PostMessage( hWnd, WM_REPORT_ERR, (WPARAM)0, (LPARAM)"Unable to create 'WaitForProcessExitThread' handle" );

	return 0;
}

// This function launches a seperate thread to detect when the specified process terminates
static void StartWaitForProcessExitThread( unsigned long ProcessID )
{
	unsigned ThreadID = 0;
	HANDLE hThread = NULL;

	unsigned long *pProcessID = new unsigned long;

	*pProcessID = ProcessID;

	if( ( hThread = (HANDLE)_beginthreadex( NULL, 0, WaitForProcessExitThread, (LPVOID)pProcessID, 0, &ThreadID ) ) == NULL )
	{
		// should never happen, display message box to aid in debugging
		PostMessage( hWnd, WM_REPORT_ERR, (WPARAM)0, (LPARAM)"Unable to create 'WaitForProcessExitThread' thread" );
		delete pProcessID;
	}
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

// Interface function used by the client to indicate it is connecting to the host
void AddRef(handle_t h1, unsigned long ProcessID )
{
	// Note: a ProcessID of zero is a debug code specifying the Host
	// Application will not close when the last client closes

	if( RefCount.AddRef( ProcessID ) && ProcessID != 0 )
		StartWaitForProcessExitThread( ProcessID );
}

// Interface function used by the client to indicate it is disconnecting from the host
void Release(handle_t h1, unsigned long ProcessID )
{
	RefCount.ReleaseRef( ProcessID );

	CheckForActiveClients();	// check if all Client applications have disconnected, if so, shutdown server
}
