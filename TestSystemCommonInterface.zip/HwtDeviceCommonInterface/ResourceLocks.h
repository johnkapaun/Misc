
class DeviceResourceLock
{
	private:
		static HANDLE LockHandle;

		bool Locked;

	public:
		DeviceResourceLock(ErrorCluster *error, bool LockResource = true);
		void Lock(ErrorCluster *error);
		void UnLock(void);
		~DeviceResourceLock();

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		DeviceResourceLock(const DeviceResourceLock& objectSrc);	// no implementation
		void operator=(const DeviceResourceLock& objectSrc);		// no implementation
};

class UplinkResourceLock
{
	private:
		static HANDLE LockHandle;

		bool Locked;

	public:
		UplinkResourceLock(ErrorCluster *error, bool LockResource = true);
		void Lock(ErrorCluster *error);
		void UnLock(void);
		~UplinkResourceLock();

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		UplinkResourceLock(const UplinkResourceLock& objectSrc);	// no implementation
		void operator=(const UplinkResourceLock& objectSrc);		// no implementation
};

class ApplicationResourceLock
{
	private:
		static HANDLE LockHandle;

		bool Locked;

	public:
		ApplicationResourceLock(ErrorCluster *error, bool LockResource = true);
		void Lock(ErrorCluster *error);
		void UnLock(void);
		~ApplicationResourceLock();

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		ApplicationResourceLock(const ApplicationResourceLock& objectSrc);	// no implementation
		void operator=(const ApplicationResourceLock& objectSrc);			// no implementation
};
