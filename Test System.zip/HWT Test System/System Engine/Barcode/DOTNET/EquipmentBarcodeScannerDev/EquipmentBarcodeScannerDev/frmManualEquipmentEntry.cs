﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EquipmentBarcodeScanner
{
    internal partial class frmManualEquipmentEntry : Form
    {

        internal frmManualEquipmentEntry(List<string> lstAllAvailableEquipment)
        {
            InitializeComponent();
            g_lstAllAvailableEquipment = lstAllAvailableEquipment;
        }

        internal List<string> SelectedEquipment
        {
            get { return g_lstSelectedEquipment; }
        }

        private List<string> g_lstAllAvailableEquipment = new List<string>();
        private List<string> g_lstSelectedEquipment = new List<string>();

        private void frmManualEquipmentEntry_Load(object sender, EventArgs e)
        {
            cbxAllEquipmnent.DataSource = g_lstAllAvailableEquipment;
            cbxAllEquipmnent.AutoCompleteMode = AutoCompleteMode.Suggest;
            cbxAllEquipmnent.AutoCompleteSource = AutoCompleteSource.ListItems;

        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {

            if (cbxAllEquipmnent.SelectedItem != null &&
                !lbxSelectedEquipment.Items.Contains(cbxAllEquipmnent.SelectedItem.ToString()))
                lbxSelectedEquipment.Items.Add(cbxAllEquipmnent.SelectedItem.ToString());
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lbxSelectedEquipment.Items.Count; i++)
                g_lstSelectedEquipment.Add(lbxSelectedEquipment.Items[i].ToString());
            Close();
        }

        private void cbxAllEquipmnent_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                if (cbxAllEquipmnent.SelectedItem != null &&
                !lbxSelectedEquipment.Items.Contains(cbxAllEquipmnent.SelectedItem.ToString()))
                    lbxSelectedEquipment.Items.Add(cbxAllEquipmnent.SelectedItem.ToString());
 
            }
        }

        private void cbxAllEquipmnent_SelectedValueChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("cbxAllEquipmnent_SelectedValueChanged");
        }

        private void cbxAllEquipmnent_SelectionChangeCommitted(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("cbxAllEquipmnent_SelectionChangeCommitted");
        }

        private void cbxAllEquipmnent_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("cbxAllEquipmnent_SelectedIndexChanged");
        }

        private void cbxAllEquipmnent_TextChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("cbxAllEquipmnent_TextChanged");
        }

        private void cbxAllEquipmnent_TextUpdate(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("cbxAllEquipmnent_TextUpdate");
        }

         

        


        /*
        private void cbxAllEquipmnent_SelectionChangeCommitted(object sender, EventArgs e)
        {

                if (cbxAllEquipmnent.SelectedItem != null &&
                !lbxSelectedEquipment.Items.Contains(cbxAllEquipmnent.SelectedItem.ToString()))
                    lbxSelectedEquipment.Items.Add(cbxAllEquipmnent.SelectedItem.ToString());
 
        }
        */

    }
}
