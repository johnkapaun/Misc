This test is intended to check the case of a missing/misnamed config file.

Loads correctly.