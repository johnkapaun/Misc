/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: delay.h
*   revision: 1.0
*   date: 1/19/15 9:16p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* This file contains delay functions.
*
* Function available:
*		DelayUs(x)	Delay specified number of microseconds
*
* Note that there are range limits: x must not exceed 255 - for xtal
* frequencies > 12MHz the range for DelayUs is even smaller.
*
* This code is NOT compiled with full optimization in Lite-Mode!
* (Don't really care. Doesn't need to be very acorate)
*
*******************************************************************************/

#ifndef	XTAL_FREQ
#define	XTAL_FREQ	32MHZ	// Crystal frequency in MHz
#endif

#define	MHZ	*1000L			// number of kHz in a MHz
#define	KHZ	*1				// number of kHz in a kHz

#if	XTAL_FREQ >= 12MHZ

// Note: this function is off 13 counts in 100
#define	DelayUs(x)	{ unsigned char _dcnt; \
			  _dcnt = (x)*((XTAL_FREQ)/(12MHZ)); \
			  while(--_dcnt != 0) \
				  continue; }
#else

#define	DelayUs(x)	{ unsigned char _dcnt; \
			  _dcnt = (x)/((12MHZ)/(XTAL_FREQ))|1; \
			  while(--_dcnt != 0) \
				  continue; }
#endif

extern void DelayMs(unsigned char cnt);// Requires delay.c


