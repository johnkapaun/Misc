
#pragma once

#include <rpc.h>
#include <rpcndr.h>

#pragma pack(push,8)

extern "C" void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
extern "C" void __RPC_USER MIDL_user_free( void __RPC_FAR * );
extern "C" void __RPC_FAR * __RPC_USER midl_user_reallocate(void __RPC_FAR * ptr, size_t len);

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////

class LVClientObject
{
	public:
		LVClientObject( TString ServerName, TString PipeName );
		LVClientObject( TString ServerName, uInt16 PortNumber );
		LVClientObject( TString AppName );

		ClientObject* RemoteAppPtr(ErrorCluster *error);

		~LVClientObject();

	private:
		ClientObject* RemoteApp;

	private:
		void RegisterApplication( ErrorCluster *error );

	private:
		TString mServerName;
		TString mPipeName;
		uInt16  mPortNumber;
		TString mAppName;

		CRITICAL_SECTION RemoteAppPtrCriticalSection;	// Critical-section object
};

#pragma pack(pop)
