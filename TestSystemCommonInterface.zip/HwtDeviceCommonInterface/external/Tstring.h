
#ifndef TSTRING_H
#define TSTRING_H

#pragma pack(push,1)

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the TSTRING_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// TSTRING_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#ifdef STATIC_CRM_DEV
#define TSTRING_API
#else
#ifdef TSTRING_EXPORTS
#define TSTRING_API __declspec(dllexport)
#else
#define TSTRING_API __declspec(dllimport)
#endif
#endif

class ErrorCluster;

class TSTRING_API TString {
    private:
		static char *NullPtr;
        char *StrPtr;         // pointer to char[] holding the string
        size_t StrLength;     // string length
    public:
        TString(void);                                          // default constructor
        TString(const TString& TStringObject );                 // copy constructor
        TString(const char *CharPtr);                           // conversion constructor
		TString(const char *CharPtr, size_t MaxLen);			// conversion constructor
		TString(const LStrHandle string);                       // conversion constructor
		virtual ~TString();										// destructor
        operator const char* (void) const { return StrPtr; }    // conversion function
		const char* CStr(void) const { return StrPtr; }			// conversion function
        size_t Length(void) const { return StrLength; }         // return String length
		void SetLV_String(ErrorCluster *error, LStrHandle *LVStr) const;

		// Format Functions
		void Format(const char *format, ... );
		void vFormat(const char *format, va_list marker );

		// Trim Functions
		void Trim(void);					// Trim spaces,tabs,newlines from start and end of string
		void Trim(const char *targets);		// Trim specified char's from start and end of string
		void TrimLeft(void);				// Trim spaces,tabs,newlines from start of string
		void TrimLeft(const char *targets);	// Trim specified char's from start of string
		void TrimRight(void);				// Trim spaces,tabs,newlines from end of string
		void TrimRight(const char *targets);// Trim specified char's from end of string

		bool IsEmpty(void) const { return(StrLength == 0); }

		void MakeUpper(void);	// Convert string to uppercase
		void MakeLower(void);	// Convert string to lowercase
		void MakeReverse(void);	// Reverse characters in string

		TString Mid(int nFirst, int nCount = -1) const;	// Extracts the middle part of the string 
		TString Right(int nCount) const;				// Extracts the right part of the string 
		TString Left(int nCount) const;					// Extracts the left part of the string 

        // Overload operators '=', '+=', '+' taking 'TString' object as argument.
        TString& operator=(const TString& TStringObject);
        TString& operator+=(const TString& OtherStr );
        TString operator+(const TString& OtherStr ) const;
        // Overload operators '=', '+=', '+' taking char pointer as argument.
        TString& operator=(const char* CharPtr);
        TString& operator+=(const char* CharPtr );
        TString operator+(const char* CharPtr ) const;
		// Overload friend operator '+' taking char pointer and TString as arguments.
		friend TSTRING_API TString operator +( const char *CharPtr, const TString& string );

        // The Relational and Equality Operators <, <=, >, >=, ==, != 
        // are implemented as case-sensitive comparisons
        bool operator==(const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) == 0 ? true : false; }
        bool operator!=(const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) != 0 ? true : false; }
        bool operator<( const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) <  0 ? true : false; }
        bool operator<=(const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) <= 0 ? true : false; }
        bool operator>( const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) >  0 ? true : false; }
        bool operator>=(const TString& Obj) const
            { return strcmp( StrPtr, Obj.StrPtr ) >= 0 ? true : false; } 
};

#ifndef STATIC_CRM_DEV

TSTRING_API istream& operator>>(istream& is, TString& str);

#endif // STATIC_CRM_DEV

#pragma pack(pop)

#endif	// TSTRING_H
