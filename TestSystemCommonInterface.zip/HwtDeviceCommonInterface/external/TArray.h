
#ifndef TARRAY_H
#define TARRAY_H

#pragma pack(push,1)

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the TARRAY_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// TARRAY_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#ifdef STATIC_CRM_DEV
#define TARRAY_API
#else
#ifdef TARRAY_EXPORTS
#define TARRAY_API __declspec(dllexport)
#else
#define TARRAY_API __declspec(dllimport)
#endif
#endif

template<class TYPE, NumType typeCode, class LV_ArrayHandle>
class TARRAY_API TArray
{
    protected:
        TYPE *DataPtr;			// pointer to [] holding the data
        int ArraySize;			// Array length
    public:
		TArray(void) {DataPtr = NULL; ArraySize = 0; }			// default constructor
		TArray(int Size);
		TArray(int Size, TYPE d0, ... );
		TArray(const TArray& TArrayObject );					// copy constructor
		TArray(const TYPE *DataPtr, int Size = 1);				// conversion constructor
		TArray(LV_ArrayHandle handle);							// conversion constructor
		virtual ~TArray();										// destructor
		operator const TYPE* (void) const { return DataPtr; }	// conversion function
		TArray& operator=(const TArray& TArrayObject);			// Overload assignment operator
		TArray SubArray(int StartIndex, int ArrayLength = -1) const;
		// overloaded operator helpers
		TYPE operator[](int Index) const;
		TYPE& operator[](int Index);
		void SetLV_Array(ErrorCluster *error, LV_ArrayHandle *handle) const;
		// Utility Functions
		int GetSize(void) const { return ArraySize; }			// return Array length
		int GetUpperBound(void) const { return ArraySize - 1; }	// return Array Upper Bound
		TArray& Insert(const TArray& TArrayObject, int Index = -1); // Insert Array
		TArray& Insert(TYPE Data, int Index = -1);				// Insert one Value
		TArray& Initialize(TYPE Value, int Size = -1);			// Initialize Array

		// The Equality Operators
		bool operator==(const TArray& TArrayObject) const;
		bool operator!=(const TArray& TArrayObject) const;
		bool operator< (const TArray& TArrayObject) const;
		bool operator<=(const TArray& TArrayObject) const;
		bool operator> (const TArray& TArrayObject) const;
		bool operator>=(const TArray& TArrayObject) const;

	protected:
		// Internal Functions
		int CompareTest(const TArray& TArrayObject) const;		// Compare Arrays, returns +1, 0, or -1
};

/////////////////////////////////////////////////////////////////////////////

typedef TArray<int8,    iB, LV_int8ArrayHandle   >  int8Array;
typedef TArray<uInt8,   uB, LV_uInt8ArrayHandle  >  uInt8Array;
typedef TArray<int16,   iW, LV_int16ArrayHandle  >  int16Array;
typedef TArray<uInt16,  uW, LV_uInt16ArrayHandle >  uInt16Array;
typedef TArray<int32,   iL, LV_int32ArrayHandle  >  int32Array;
typedef TArray<uInt32,  uL, LV_uInt32ArrayHandle >  uInt32Array;
typedef TArray<float32, fS, LV_float32ArrayHandle>  float32Array;
typedef TArray<float64, fD, LV_float64ArrayHandle>  float64Array;
typedef TArray<bool,    iB, LV_boolArrayHandle   >  boolArray;

/////////////////////////////////////////////////////////////////////////////

class TARRAY_API TStringArray
{
    protected:
        TString **DataPtr;		// pointer to [] of pointers holding the data
        int ArraySize;			// Array length
    public:
		TStringArray(void) {DataPtr = NULL; ArraySize = 0; }		// default constructor
		TStringArray(int Size);
		TStringArray(int Size, TString d0, ... );
		TStringArray(int Size, const char *d0, ... );
		TStringArray(const TStringArray& TStringArrayObject );		// copy constructor
		TStringArray(const TString *Data, int Size = 1);			// conversion constructor
		TStringArray(const char **Data, int Size = 1);				// conversion constructor
		TStringArray(LV_stringArrayHandle handle);					// conversion constructor
		virtual ~TStringArray();									// destructor
		operator const TString* (void) const { return *DataPtr; }	// conversion function
		TStringArray& operator=(const TStringArray& TStringArrayObject);	// Overload assignment operator
		TStringArray SubArray(int StartIndex, int ArrayLength = -1) const;
		// overloaded operator helpers
		TString operator[](int Index) const;
		TString& operator[](int Index);
		void SetLV_Array(ErrorCluster *error, LV_stringArrayHandle *handle) const;
		// Utility Functions
		int GetSize(void) const { return ArraySize; }				// return Array length
		int GetUpperBound(void) const { return ArraySize - 1; }		// return Array Upper Bound
		TStringArray& Insert(const TStringArray& TStringArrayObject, int Index = -1); // Insert Array
		TStringArray& Insert(TString Data, int Index = -1);			// Insert one Value
		TStringArray& Initialize(TString Value, int Size = -1);		// Initialize Array

		// The Equality Operators
		bool operator==(const TStringArray& TStringArrayObject) const;
		bool operator!=(const TStringArray& TStringArrayObject) const;
		bool operator< (const TStringArray& TStringArrayObject) const;
		bool operator<=(const TStringArray& TStringArrayObject) const;
		bool operator> (const TStringArray& TStringArrayObject) const;
		bool operator>=(const TStringArray& TStringArrayObject) const;

	protected:
		// Internal Functions
		void Empty(void);												// Empty Array
		TStringArray(TString **Data, int Size);							// conversion constructor
		int CompareTest(const TStringArray& TStringArrayObject) const;	// Compare Arrays, returns +1, 0, or -1
};

/////////////////////////////////////////////////////////////////////////////

template<class TArray, class DataElement, class LV_ArrayArrayHandle>
class TARRAY_API TArrayArray
{
	protected:
		TArray **DataPtr;
		int ArraySize;
	public:
		TArrayArray(void) {DataPtr = NULL; ArraySize = 0; }				// default constructor
		TArrayArray(int Size);
		TArrayArray(int Size, const TArray *d0, ... );
		TArrayArray(int PrimaryArraySize, int SecondaryArraySize1, ...);
		TArrayArray(const TArrayArray& TArrayArrayObject );				// copy constructor
		TArrayArray(const TArray *Data, int Size = 1);					// conversion constructor
		TArrayArray(LV_ArrayArrayHandle handle);						// conversion constructor
		virtual ~TArrayArray();											// destructor
		TArrayArray& operator=(const TArrayArray& TArrayArrayObject);	// Overload assignment operator
		TArrayArray SubArray(int StartIndex, int ArrayLength = -1) const;
		// overloaded operator helpers
		TArray operator[](int Index) const;
		TArray& operator[](int Index);
		void SetLV_Array(ErrorCluster *error, LV_ArrayArrayHandle *handle) const;
		// Utility Functions
		int GetSize(void) const { return ArraySize; }					// return Array length
		int GetUpperBound(void) const { return ArraySize - 1; }			// return Array Upper Bound
		int32Array GetSizes(void) const;								// return array of array sizes
		int32 GetTotalElements(void) const;								// return count of all elements
		TArrayArray& Insert(const TArrayArray& TArrayArrayObject, int Index = -1);	// Insert ArrayArray
		TArrayArray& Insert(const TArray& Data, int Index = -1);		// Insert Array
		TArrayArray& Initialize(const TArray& Value, int Size = -1);	// Initialize Array with Array
		TArrayArray& Initialize(const DataElement& Value);				// Initialize Array with Value
		TArray CreateFlattenedArray(void) const;						// Create Flattened to one-dim array
	protected:
		void Empty(void);												// Empty Array
		TArrayArray(TArray **Data, int Size);							// conversion constructor
};

/////////////////////////////////////////////////////////////////////////////

typedef TArrayArray<int8Array,		int8,		LV_int8ArrayArrayHandle   >  int8ArrayArray;
typedef TArrayArray<uInt8Array,		uInt8,		LV_uInt8ArrayArrayHandle  >  uInt8ArrayArray;
typedef TArrayArray<int16Array,		int16,		LV_int16ArrayArrayHandle  >  int16ArrayArray;
typedef TArrayArray<uInt16Array,	uInt16,		LV_uInt16ArrayArrayHandle >  uInt16ArrayArray;
typedef TArrayArray<int32Array,		int32,		LV_int32ArrayArrayHandle  >  int32ArrayArray;
typedef TArrayArray<uInt32Array,	uInt32,		LV_uInt32ArrayArrayHandle >  uInt32ArrayArray;
typedef TArrayArray<float32Array,	float32,	LV_float32ArrayArrayHandle>  float32ArrayArray;
typedef TArrayArray<float64Array,	float64,	LV_float64ArrayArrayHandle>  float64ArrayArray;
typedef TArrayArray<boolArray,		bool,		LV_boolArrayArrayHandle   >  boolArrayArray;
typedef TArrayArray<TStringArray,	TString,	LV_stringArrayArrayHandle >  TStringArrayArray;

/////////////////////////////////////////////////////////////////////////////

#ifndef STATIC_CRM_DEV

typedef Value_StateCache<int8Array>		int8Array_StateCache;
typedef Value_StateCache<uInt8Array>	uInt8Array_StateCache;
typedef Value_StateCache<int16Array>	int16Array_StateCache;
typedef Value_StateCache<uInt16Array>	uInt16Array_StateCache;
typedef Value_StateCache<int32Array>	int32Array_StateCache;
typedef Value_StateCache<uInt32Array>	uInt32Array_StateCache;
typedef Value_StateCache<float32Array>	float32Array_StateCache;
typedef Value_StateCache<float64Array>	float64Array_StateCache;
typedef Value_StateCache<TStringArray>	TStringArray_StateCache;
typedef Value_StateCache<boolArray>		boolArray_StateCache;

#endif // STATIC_CRM_DEV

/////////////////////////////////////////////////////////////////////////////

#ifndef STATIC_CRM_DEV

CRM_DEV_API bool ReadFileVersionInformation( const char *PathFile, uInt16Array *FileVersion = NULL, uInt16Array *ProductVersion = NULL , uInt32 *Flags = NULL );

#endif // STATIC_CRM_DEV

#pragma pack(pop)

#endif	// TARRAY_H
