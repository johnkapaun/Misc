This test is intended to check the case of a malformed config file.

Error exit HWTSys