
#ifndef CRM_DEV_H
#define CRM_DEV_H

#pragma pack(push,1)

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CRM_DEV_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CRM_DEV_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.

#ifdef STATIC_CRM_DEV
#define CRM_DEV_API
#else
#ifdef CRM_DEV_EXPORTS
#define CRM_DEV_API __declspec(dllexport)
#else
#define CRM_DEV_API __declspec(dllimport)
#endif
#endif

//////////////////////////////////////////////////////////

// Define LabView Error Cluster
typedef struct { LVBoolean status; int32 code; LStrHandle source; } LV_ErrorCluster;

// Define LabView numeric one-dimensional arrays
typedef struct { int32 dimSize; int8		values[1]; } LV_int8Array,    **LV_int8ArrayHandle;
typedef struct { int32 dimSize; uInt8		values[1]; } LV_uInt8Array,   **LV_uInt8ArrayHandle;
typedef struct { int32 dimSize; int16		values[1]; } LV_int16Array,   **LV_int16ArrayHandle;
typedef struct { int32 dimSize; uInt16		values[1]; } LV_uInt16Array,  **LV_uInt16ArrayHandle;
typedef struct { int32 dimSize; int32		values[1]; } LV_int32Array,   **LV_int32ArrayHandle;
typedef struct { int32 dimSize; uInt32		values[1]; } LV_uInt32Array,  **LV_uInt32ArrayHandle;
typedef struct { int32 dimSize; float32		values[1]; } LV_float32Array, **LV_float32ArrayHandle;
typedef struct { int32 dimSize; float64		values[1]; } LV_float64Array, **LV_float64ArrayHandle;
typedef struct { int32 dimSize; LStrHandle	values[1]; } LV_stringArray,  **LV_stringArrayHandle;
typedef struct { int32 dimSize; LVBoolean	values[1]; } LV_boolArray,    **LV_boolArrayHandle;

// Define LabView one-dimensional arrays of cluster containing one one-dimensional array (Arrays of Arrays)
typedef struct { int32 dimSize; LV_int8ArrayHandle    values[1]; } LV_int8ArrayArray,    **LV_int8ArrayArrayHandle;
typedef struct { int32 dimSize; LV_uInt8ArrayHandle   values[1]; } LV_uInt8ArrayArray,   **LV_uInt8ArrayArrayHandle;
typedef struct { int32 dimSize; LV_int16ArrayHandle   values[1]; } LV_int16ArrayArray,   **LV_int16ArrayArrayHandle;
typedef struct { int32 dimSize; LV_uInt16ArrayHandle  values[1]; } LV_uInt16ArrayArray,  **LV_uInt16ArrayArrayHandle;
typedef struct { int32 dimSize; LV_int32ArrayHandle   values[1]; } LV_int32ArrayArray,   **LV_int32ArrayArrayHandle;
typedef struct { int32 dimSize; LV_uInt32ArrayHandle  values[1]; } LV_uInt32ArrayArray,  **LV_uInt32ArrayArrayHandle;
typedef struct { int32 dimSize; LV_float32ArrayHandle values[1]; } LV_float32ArrayArray, **LV_float32ArrayArrayHandle;
typedef struct { int32 dimSize; LV_float64ArrayHandle values[1]; } LV_float64ArrayArray, **LV_float64ArrayArrayHandle;
typedef struct { int32 dimSize; LV_boolArrayHandle    values[1]; } LV_boolArrayArray,    **LV_boolArrayArrayHandle;
typedef struct { int32 dimSize; LV_stringArrayHandle  values[1]; } LV_stringArrayArray,  **LV_stringArrayArrayHandle;

//////////////////////////////////////////////////////////

class CRM_DEV_API ErrorCluster
{
    private:
		bool status;
		int32 code;
		TString source;
		MgErr fatal;

    public:
		ErrorCluster(void)
			{source = ""; code = 0; status = false; fatal = noErr; }			// default constructor
		ErrorCluster(bool err_status, int32 err_code, TString err_source);		// conversion constructor
		ErrorCluster(const LV_ErrorCluster *LV_Err);							// conversion constructor
		ErrorCluster(const ErrorCluster& ErrorClusterObject );					// copy constructor
		virtual ~ErrorCluster() { }												// destructor
		ErrorCluster& operator=(const ErrorCluster& TStringObject);				// assignment operator
		MgErr LVErr(LV_ErrorCluster *error);									// update LabVIEW Error Cluster
		bool Status(void) const {return( status || (fatal != noErr) );}			// Return true if error flag or MgErr is set
		bool FatalStatus(void) const {return(fatal != noErr);}					// Return true if MgErr is set
		int32 Code(void) const {return code;}									// Return error code
		TString Source(void) const {return source;}								// Return error source string
		MgErr FatalCode(void) const {return fatal;}								// Return fatal error code (LabView internal error)
		MgErr SetFatal(MgErr error);											// Sets the MgErr (LabView internal error flag)
		void ResetStatus(void) { status = false; }								// Resets the error flag
		void ResetAll(void) { status = false, source = "", code = 0; }			// Resets the error flag, code, source
		void SetError(int32 err_code, const char *format, ... );				// Sets the error flag, code,
																				//   and the error source using a printf type format
		void SetWarning(int32 err_code, const char *format, ... );				// Sets the code and the error source using a printf type format,
};																				//   the error flag in not set

//////////////////////////////////////////////////////////

#ifndef STATIC_CRM_DEV

//////////////////////////////////////////////////////////

CRM_DEV_API FARPROC GetDeviceFunctionAddress(ErrorCluster *, const char *);
CRM_DEV_API TString LoadDeviceLibrary(ErrorCluster *, const TString &);
CRM_DEV_API TString ID_Device(ErrorCluster *);

CRM_DEV_API TString LoadControllerLibrary(ErrorCluster *, TString);
CRM_DEV_API FARPROC GetControllerFunctionAddress(ErrorCluster *, const char *);
CRM_DEV_API void* AcquireControllerObjectPointer(ErrorCluster *error, TString FamilyRev, int ControllerNumber = 1);

//////////////////////////////////////////////////////////

class CRM_DEV_API StateCache
{
    private:
		static bool GlobalEnable;		// Global Enable Flag
		static StateCache *ChainStart;	// Start of linked object chain

		StateCache *Previous;			// Previous object in chain
		StateCache *Next;				// Next object in chain

		bool ValidState;				// Current valid state

    public:
		StateCache(void);				// constructor
		virtual ~StateCache();			// destructor

		bool Valid(void) const {return(ValidState && GlobalEnable); }	// return valid state
		bool Valid(bool State);						// set valid state & return previous state
		bool Valid(ErrorCluster *error);			// set valid state equal to NOT ErrorCluster -
													//   error flag & returns previous state
		bool ValueValid(void) const {return(ValidState);}	// Returns the valid state of the cached value
															// This differs from the 'Value' function
															// because the state is independent of the 'GlobalEnable'.
		// Global Control Functions
		static bool CacheEnable(void) {return GlobalEnable;}	// Return current Enable state
		static bool CacheEnable(bool Enable);					// Sets new Enable state
		static void InvalidateAll(void);	// Sets the valid state to false for all StateCache objects

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		StateCache(const StateCache& objectSrc);		// no implementation
		void operator=(const StateCache& objectSrc);	// no implementation
};

//////////////////////////////////////////////////////////

#ifdef CRM_DEV_EXPORTS					// How do you specify a forward referance a
	#pragma warning( push )				// 'class template instantiation'?
	#pragma warning( disable : 4251 )	// If there is a problem the Linker should
#endif									//   catch it.

template<class ValueType>
class CRM_DEV_API Value_StateCache : protected StateCache
{
    private:
        ValueType mValue;

    public:
		Value_StateCache(void) {}			// constructor
		virtual ~Value_StateCache() {}		// destructor

		bool Valid(void) const { return StateCache::Valid(); } // return valid state
		bool Valid(const ValueType &Value) const;	// compare value and return valid state
		// set valid state equal to NOT ErrorCluster error flag & returns previous state
		bool Update(ErrorCluster *error, const ValueType &Value);

		const ValueType& Value(void) const { return mValue; } // Returns the current Cached Value
		bool ValueValid(void) const { return StateCache::ValueValid(); }// Returns the valid state of the cached
															  // value.  This differs from 'Value'
															  // function in so much as the state
															  // is independent of the 'GlobalEnable'
		void Invalidate(void) { StateCache::Valid(false); }	  // make the current state invalid
};

#ifdef CRM_DEV_EXPORTS
	#pragma warning( pop )	// Restore Warning (class 'type' needs to have dll-interface)
#endif

typedef Value_StateCache<int8>		int8_StateCache;
typedef Value_StateCache<uInt8>		uInt8_StateCache;
typedef Value_StateCache<int16>		int16_StateCache;
typedef Value_StateCache<uInt16>	uInt16_StateCache;
typedef Value_StateCache<int32>		int32_StateCache;
typedef Value_StateCache<uInt32>	uInt32_StateCache;
typedef Value_StateCache<float32>	float32_StateCache;
typedef Value_StateCache<float64>	float64_StateCache;
typedef Value_StateCache<TString>	TString_StateCache;
typedef Value_StateCache<bool>		bool_StateCache;

//////////////////////////////////////////////////////////

class CRM_DEV_API AddressCache
{
	private:
		static AddressCache *ChainStart;	// Start of linked object chain
		AddressCache *Previous;				// Previous object in chain
		AddressCache *Next;					// Next object in chain
		bool ValidState;					// Current valid state

		static int FailureCounter;
		static TString FailureList[];
		static void ClearFailureList(void);

	protected:
		virtual bool LookupFirmwareAddress(void) = 0;	// translates address names to values
		virtual void SetValidState(bool State);			// set the valid state
		void UpdateFailureList(const char *AddressName);

    public:
		AddressCache(void);					// constructor
		virtual ~AddressCache();			// destructor

		virtual bool Valid(void) const;		// virtual function returning the address valid state

		// Global Control Functions
		static void InvalidateAll(void);	// Sets the valid state to false for all derived objects 
		static void InvalidateAll(ErrorCluster *error);
		static void UpdateAll(void);		// Forces all derived objects to refresh their stored address values
		static void UpdateAll(ErrorCluster *error);
		static TString RetrieveFailureList(ErrorCluster *error);

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		AddressCache(const AddressCache& objectSrc);		// no implementation
		void operator=(const AddressCache& objectSrc);		// no implementation
};

//////////////////////////////////////////////////////////

CRM_DEV_API uInt8  uInt8Round( double x );	// round floating point number to 8 bit unsigned interger
CRM_DEV_API int8   int8Round( double x );	// round floating point number to 8 bit signed interger
CRM_DEV_API uInt16 uInt16Round( double x );	// round floating point number to 16 bit unsigned interger
CRM_DEV_API int16  int16Round( double x );	// round floating point number to 16 bit signed interger
CRM_DEV_API uInt32 uInt32Round( double x );	// round floating point number to 32 bit unsigned interger
CRM_DEV_API int32  int32Round( double x );	// round floating point number to 32 bit signed interger

//////////////////////////////////////////////////////////

CRM_DEV_API void Sleep( ErrorCluster *, DWORD dwMilliseconds );   // sleep time in milliseconds

//////////////////////////////////////////////////////////

class TStringArray;	// forward reference

CRM_DEV_API TString LabVIEW_FilePath(void);
CRM_DEV_API TString CommonDLL_FileName(bool IncludePath = false);
CRM_DEV_API TString DeviceDLL_FileName(bool IncludePath = false);
CRM_DEV_API TString ControllerDLL_FileName(bool IncludePath = false);
CRM_DEV_API TStringArray ControllerDLL_FileNames(bool IncludePath = false);
CRM_DEV_API bool DoesFileExists( const TString &FileName );
CRM_DEV_API TString RemovePathFromFileName( const TString &FileName );
CRM_DEV_API TString RemoveFileNameFromPath( const TString &PathFile );
CRM_DEV_API void CreateDirectoryTree( ErrorCluster *error, TString Tree);
CRM_DEV_API TString FindFile( const TString &Path, const TString &File );
CRM_DEV_API TString FormattedSystemErrorMessage(void);

//////////////////////////////////////////////////////////

CRM_DEV_API TString VerifyCommonDeviceDllVersion( ErrorCluster *error );
CRM_DEV_API TString VerifyDeviceSpecificDllVersion( ErrorCluster *error, TString DLL_Name );
CRM_DEV_API void UpdateLocalDLL( ErrorCluster *error, TString DLL_Name );
CRM_DEV_API TString FormattedVersionInfo( ErrorCluster *error );

//////////////////////////////////////////////////////////

CRM_DEV_API void ReloadCommonDllResourceFile(ErrorCluster *error);
CRM_DEV_API TString ReleasedDllPath(ErrorCluster *error = NULL);
CRM_DEV_API TString FirmwarePath(ErrorCluster *error = NULL);
CRM_DEV_API TString ProfilePath(ErrorCluster *error = NULL);
CRM_DEV_API TString ControllerListFile(ErrorCluster *error = NULL);
CRM_DEV_API TString RevisionCheckFile(ErrorCluster *error = NULL);
CRM_DEV_API TString LocalDllPath(ErrorCluster *error = NULL);
CRM_DEV_API TString MenuPath(ErrorCluster *error = NULL);

//////////////////////////////////////////////////////////

class CRM_DEV_API ResourceLock
{
	#ifdef CRM_DEV_EXPORTS
	friend BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved );
	#endif

	private:
		static HANDLE LockHandle;
		static bool SharedMemStatus;
		static HANDLE SharedMemHandle;
		static LPVOID SharedMemAddress;

		bool Locked;

	public:
		ResourceLock(ErrorCluster *error, bool LockResource = true);
		void Lock(ErrorCluster *error);
		void UnLock(void);
		~ResourceLock();

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		ResourceLock(const ResourceLock& objectSrc);		// no implementation
		void operator=(const ResourceLock& objectSrc);		// no implementation
};

//////////////////////////////////////////////////////////

#endif // STATIC_CRM_DEV

//////////////////////////////////////////////////////////

#pragma pack(pop)

#endif	// CRM_DEV_H
