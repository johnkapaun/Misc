﻿Imports System.Xml
Imports System.Data.OracleClient
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Collections.Generic
Imports System.Collections.Specialized


Friend Class frmEquipment

#Region " Disable the (x) button "

    Private Const MF_BYPOSITION As Integer = &H400
    Private Const MF_REMOVE As Integer = &H1000

    Private Declare Function RemoveMenu Lib "user32" (ByVal hMenu As IntPtr, ByVal nPosition As Int32, _
                                                      ByVal wFlags As Int32) As Int32
    Private Declare Function GetSystemMenu Lib "user32" (ByVal hWnd As IntPtr, ByVal bRevert As Boolean) As IntPtr
    Private Declare Function GetMenuItemCount Lib "user32" (ByVal hMenu As IntPtr) As Integer
    Private Declare Function DrawMenuBar Lib "user32" (ByVal hwnd As IntPtr) As Boolean

    Public Sub DisableCloseButton(ByVal hwnd As IntPtr)
        Dim hMenu As IntPtr
        Dim menuItemCount As Int32
        hMenu = GetSystemMenu(hwnd, False)
        menuItemCount = GetMenuItemCount(hMenu)
        Call RemoveMenu(hMenu, menuItemCount - 1, MF_BYPOSITION)
        Call RemoveMenu(hMenu, menuItemCount - 2, MF_BYPOSITION)
        Call DrawMenuBar(hwnd)
    End Sub

#End Region

#Region " public properties "

    Public WriteOnly Property ConfigEquipment() As stringcollection
        Set(ByVal value As stringcollection)
            g_colCnfgEquipment = value
        End Set
    End Property
    'Public WriteOnly Property ConfigEquipment() As ArrayList
    '    Set(ByVal value As ArrayList)
    '        g_colCnfgEquipment = value
    '    End Set
    'End Property

    Public ReadOnly Property EquipmentList() As String(,)
        Get
            Return g_arrEquipmentList
        End Get
    End Property

#End Region





#Region " private members "
    Public Shared Connection As New OracleConnection
    Private g_ManualEntryForm As frmEnterEquipmentNumber
    Private g_arrEquipmentList As String(,)
    Private g_colCnfgEquipment As StringCollection
    Private lstHeader As New ArrayList

    Private Time1nothing As Boolean = True
    Private Time1 As DateTime
    Private Time2 As DateTime
    Private Span As TimeSpan
    Private Const NA As String = "NA"

#End Region

#Region " form events "

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        '//////////////////////////////////////////////////////////////////
        ' the first thing is to 
        ConnectToDB()


    End Sub


    Private Sub frmEquipment_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        g_ManualEntryForm.Dispose()
        Connection.Close()
    End Sub



    Private Sub frmEquipment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Dim intI As Integer
        Dim dgvFont As Font
        Try
            ' change the font for the datagridviews (make it bigger)
            dgvFont = New Font(DGV.Font.Name, 12, FontStyle.Bold)
            DGV.Font = dgvFont
            DGVcnfg.Font = dgvFont
            '
            DisableCloseButton(Me.Handle) ' disable the (x) button
            '
            ' fill the left datagridview with equipment from the config file (passed from LV)
            For Each eq As String In g_colCnfgEquipment
                DGVcnfg.Rows.Add(eq)
            Next


            'For intI = 0 To g_colCnfgEquipment.Count - 1
            '    DGVcnfg.Rows.Add(g_colCnfgEquipment(intI).ToString)
            'Next
            '
            DGVcnfg.CurrentCell = Nothing
            '
            ' up/down arrows on the buttons
            'btnUp.Text = ChrW(221)
            'btnUp.Text = Chr(221)
            'btnDown.Text = ChrW(223)
            'btnDown.Text = Chr(223)
            '
            g_ManualEntryForm = New frmEnterEquipmentNumber
            '
            Me.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION frmEquipment_Load", MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmScanEquipment_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Dim k As New KeysConverter
        Dim strItem As String
        Dim intI As Integer

        DGV.Focus()
        Try
            If Time1nothing = True Then
                Time1nothing = False
                Time1 = DateTime.Now
                lstHeader = New ArrayList
                lstHeader.Add(k.ConvertToString(e.KeyData))
            Else
                Time2 = DateTime.Now
                Span = Time2.Subtract(Time1)
                '
                If Span.TotalMilliseconds < 60 Then
                    If e.KeyCode = Keys.Enter Then
                        ' -----------------------------------------------------------------------*
                        ' *** Remove non-printing keypresses ***
                        intI = 0
                        While intI < lstHeader.Count
                            If lstHeader(intI).ToString = "Shift+ShiftKey" Then
                                lstHeader.RemoveAt(intI)
                            Else
                                intI += 1
                            End If
                        End While
                        ' -----------------------------------------------------------------------*
                        ' *** UCase/LCase ***
                        For intI = 0 To lstHeader.Count - 1
                            If CStr(lstHeader(intI)).StartsWith("Shift+") = True Then
                                lstHeader(intI) = Replace(CStr(lstHeader(intI)), "Shift+", "")
                                lstHeader(intI) = UCase(CStr(lstHeader(intI)))
                            Else
                                lstHeader(intI) = LCase(CStr(lstHeader(intI)))
                            End If
                        Next
                        ' -----------------------------------------------------------------------*
                        strItem = ""
                        For intI = 0 To lstHeader.Count - 1
                            strItem = strItem & lstHeader(intI).ToString
                        Next
                        ' -----------------------------------------------------------------------*
                        ' check if the scanned item already exists in the table (has been scanned before)
                        For intI = 0 To DGV.Rows.Count - 1
                            If DGV.Item("EquipmentNumber", intI).Value.ToString = strItem Then
                                lstHeader = New ArrayList
                                Exit Sub
                            End If
                        Next
                        '
                        DGV.Rows.Add()
                        intI = DGV.Rows.Count - 1
                        ' --------------------------------------
                        DGV.Item("EquipmentNumber", intI).Value = strItem
                        DGV.Item("Description", intI).Value = getDescription(strItem)
                        DGV.Item("CalDueDate", intI).Value = getCalDueDate(strItem)
                        DGV.Item("Manufacturer", intI).Value = getManufacturer(strItem)
                        ' --------------------------------------
                        lstHeader = New ArrayList
                        Time1nothing = True
                        Coloring()
                        DGV.Rows(intI).Selected = True
                        '
                    Else ' if the entered Character is not 'Enter'
                        lstHeader.Add(k.ConvertToString(e.KeyData))
                    End If
                Else ' if the timespan is > 60ms
                    lstHeader = New ArrayList
                    Time1nothing = True
                End If
                '
                Time1 = Time2
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception frmScanEquipment_KeyDown", MessageBoxButtons.OK, MessageBoxIcon.Error)
            lstHeader = New ArrayList
            Time1nothing = True
        End Try
    End Sub

#End Region

#Region " Buttons "

    Private Sub btnUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUp.Click
        Try
            If DGV.RowCount <= 0 Then
                Exit Sub
            End If
            Dim intSelectedRow As Integer = DGV.SelectedRows.Item(0).Index
            Dim intI As Integer
            '
            If intSelectedRow = 0 Then
                Exit Sub
            End If
            '
            DGV.Rows.Insert(intSelectedRow - 1)
            '
            For intI = 0 To DGV.Columns.Count - 1
                DGV.Item(intI, intSelectedRow - 1).Value = DGV.Item(intI, intSelectedRow + 1).Value
            Next
            '
            DGV.Rows.RemoveAt(intSelectedRow + 1)
            '
            DGV.CurrentCell = DGV.Item(0, intSelectedRow - 1)
            '
            Coloring()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception btnUp_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDown.Click
        Try
            If DGV.RowCount <= 0 Then
                Exit Sub
            End If
            Dim intSelectedRow As Integer = DGV.SelectedRows.Item(0).Index
            Dim intI As Integer
            '
            If intSelectedRow = DGV.Rows.Count - 1 Then
                Exit Sub
            End If
            '
            DGV.Rows.Insert(intSelectedRow)
            '
            For intI = 0 To DGV.Columns.Count - 1
                DGV.Item(intI, intSelectedRow).Value = DGV.Item(intI, intSelectedRow + 2).Value
            Next
            '
            DGV.Rows.RemoveAt(intSelectedRow + 2)
            '
            DGV.CurrentCell = DGV.Item(0, intSelectedRow + 1)
            '
            Coloring()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception btnDown_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim intI As Integer
        Dim intJ As Integer
        Dim strRed As String = ""
        Try

            ReDim g_arrEquipmentList(DGV.Rows.Count - 1, DGV.Columns.Count - 1)
            '
            For intI = 0 To DGV.Rows.Count - 1
                For intJ = 0 To DGV.Columns.Count - 1
                    g_arrEquipmentList(intI, intJ) = DGV.Item(intJ, intI).Value.ToString
                Next
            Next
            '
            Connection.Close()
            Me.Close()
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION btnOK_Click")
        End Try
    End Sub

    Private Sub btnBlankRow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBlankRow.Click
        Try
            Dim arrD() As String = {NA, NA, NA, NA}
            DGV.Rows.Add(arrD)
            Coloring()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION btnBlankRow_Click")
        End Try
    End Sub

    Private Sub btnDeleteRow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteRow.Click
        Try

            If DGV.SelectedRows.Count = 0 Then
                Exit Sub
            End If
            DGV.Rows.Remove(DGV.SelectedRows(0))
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION btnDeleteRow_Click")
        End Try
    End Sub

#End Region

#Region " DB Helpers "

    Private Function getCalDueDate(ByVal strEquipmentNumber As String) As String
        Dim strSQL As String
        Dim DA As OracleDataAdapter
        Dim DT As DataTable
        Dim strCalDueDate As String
        Try
            strSQL = "SELECT  DUE_DATE " & "FROM  EQ_SCHED_ALL_DEPT " & _
                                 "WHERE  PROP_NUM = '" & strEquipmentNumber & "' "
            '
            DA = New OracleDataAdapter(strSQL, Connection)
            DT = New DataTable
            '
            DA.Fill(DT)
            If DT.Rows.Count = 0 Then
                strCalDueDate = NA
            Else
                strCalDueDate = DT.Rows(0).Item(0).ToString
            End If
            '
            If IsDate(strCalDueDate) Then
                strCalDueDate = Format(CType(strCalDueDate, DateTime), "ddMMMyy")
            End If
            '
            Return strCalDueDate
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception getCalDueDate", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ""
        End Try
    End Function

    Private Function getDescription(ByVal strEquipmentNumber As String) As String
        Dim strSQL As String
        Dim DA As OracleDataAdapter
        Dim DT As DataTable
        Dim strDescription As String
        Try
            strSQL = "SELECT  DESCRIPTION " & "FROM  EQUIP_ALL_DEPT " & _
                                "WHERE  PROP_NUM = '" & strEquipmentNumber & "' "
            '
            '
            DA = New OracleDataAdapter(strSQL, Connection)
            DT = New DataTable
            '
            DA.Fill(DT)
            If DT.Rows.Count = 0 Then
                strDescription = NA
            Else
                strDescription = DT.Rows(0).Item(0).ToString
            End If
            '
            Return Replace(strDescription, ";", ",")
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception getDescription", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ""
        End Try

    End Function

    Private Function getManufacturer(ByVal strEquipmentNumber As String) As String
        Dim strSQL As String
        Dim DA As OracleDataAdapter
        Dim DT As DataTable
        Dim strManufacturer As String
        Try
            strSQL = "SELECT  MANUFACTURER " & "FROM  EQUIP_ALL_DEPT " & _
                    "WHERE  PROP_NUM = '" & strEquipmentNumber & "' "
            '
            DA = New OracleDataAdapter(strSQL, Connection)
            DT = New DataTable
            '
            DA.Fill(DT)
            If DT.Rows.Count = 0 Then
                strManufacturer = NA
            Else
                strManufacturer = DT.Rows(0).Item(0).ToString
            End If
            '
            Return strManufacturer
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception getManufacturer", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return ""
        End Try
    End Function

    Private Sub ConnectToDB()
        Try
            Connection = New OracleConnection("Data Source=PGAGECLB.PACE.MEDTRONIC.COM;Persist Security Info=True;User ID=Siteadmin_user;Password=readonly4prd;Unicode=True")
            Connection.Open()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception ConnectToDB", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Is150165(ByVal strEquipNum As String) As Boolean
        Dim strSQL As String
        Dim DA As OracleDataAdapter
        Dim DT As DataTable
        Try
            strSQL = "SELECT  PROP_NUM " & "FROM  EQUIPMENT_150165 " & _
                    "WHERE  PROP_NUM = '" & strEquipNum & "' "
            '
            DA = New OracleDataAdapter(strSQL, Connection)
            DT = New DataTable
            '
            DA.Fill(DT)
            '
            If DT.Rows.Count = 0 Then
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception getManufacturer", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End Try
    End Function

#End Region

#Region " Colors "


    Sub ColorRow(ByVal intRow As Integer, ByVal cColor As System.Drawing.Color)
        Dim intI As Integer
        For intI = 0 To DGV.Columns.Count - 1
            DGV.Item(intI, intRow).Style.BackColor = cColor
        Next
    End Sub

    Private Sub Coloring()

        Dim intRow As Integer
        Dim strCalDueDate As String
        Dim strTodaysDate As String
        Dim intDays As Integer
        Try


            For intRow = 0 To DGV.Rows.Count - 1
                strCalDueDate = DGV.Item("CalDueDate", intRow).Value.ToString
                strTodaysDate = DateTime.Today.ToShortDateString
                '
                '
                If IsDate(strCalDueDate) = False Then
                    If DGV.Item("Description", intRow).Value.ToString = NA And _
                        DGV.Item("CalDueDate", intRow).Value.ToString = NA And _
                        DGV.Item("Manufacturer", intRow).Value.ToString = NA Then
                        ColorRow(intRow, Color.Red)
                    Else
                        ColorRow(intRow, Color.LimeGreen)
                    End If
                Else
                    ' compare dates 
                    intDays = CType(strCalDueDate, Date).Subtract(CType(strTodaysDate, Date)).Days
                    '
                    If intDays <= 30 And intDays > 0 Then
                        ColorRow(intRow, Color.Yellow)
                    ElseIf intDays <= 0 Then
                        ColorRow(intRow, Color.Red)
                    Else
                        ColorRow(intRow, Color.LimeGreen)
                    End If
                    '
                    '

                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception Coloring", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DGV_CellMouseEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellMouseEnter
        Try
            If e.RowIndex < 0 Or e.ColumnIndex < 0 Then
                Exit Sub
            End If
            '
            Dim strText As String = ""
            '
            If DGV.Item(e.ColumnIndex, e.RowIndex).Style.BackColor = Color.Red Then
                strText = "Past due/Not in the System"
            ElseIf DGV.Item(e.ColumnIndex, e.RowIndex).Style.BackColor = Color.Yellow Then
                strText = "Due in 30 days or less"
            ElseIf DGV.Item(e.ColumnIndex, e.RowIndex).Style.BackColor = Color.LimeGreen Then
                strText = "Not Due for at least 31 days"
            End If
            '
            DGV.Item(e.ColumnIndex, e.RowIndex).ToolTipText = strText
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION DGV_CellMouseEnter")
        End Try
    End Sub

    Private Sub DGV_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles DGV.RowsRemoved
        Coloring()
    End Sub

#End Region

#Region " Focus DGV (always) "


    Private Sub Focus_Clicks(ByVal sender As Object, _
                              ByVal e As System.Windows.Forms.MouseEventArgs) _
                              Handles _
                              btnUp.MouseUp, btnDown.MouseUp, _
                              btnBlankRow.MouseUp, btnDeleteRow.MouseUp, _
                              btnOK.MouseUp, DGVcnfg.MouseUp
        Try
            DGV.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION Focus_Clicks")
        End Try

    End Sub

#End Region

#Region " Manual entry "

    Private Sub DGV_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellDoubleClick
        Try
            If e.RowIndex < 0 Then
                Exit Sub
            End If
            Dim strEquipNum As String
            Dim strDescription As String
            g_ManualEntryForm.ShowDialog()
            strEquipNum = g_ManualEntryForm.EquipmentNumber
            If strEquipNum Is Nothing Then
                Exit Sub
            End If
            '
            DGV.Item("EquipmentNumber", e.RowIndex).Value = strEquipNum
            strDescription = getDescription(strEquipNum)
            If Is150165(strEquipNum) = False Then
                strDescription = "*OUTSIDE COST CENTER*" & strDescription
            End If
            DGV.Item("Description", e.RowIndex).Value = strDescription
            DGV.Item("CalDueDate", e.RowIndex).Value = getCalDueDate(strEquipNum)
            DGV.Item("Manufacturer", e.RowIndex).Value = getManufacturer(strEquipNum)
            Coloring()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception: DGV_CellDoubleClick")
        End Try
    End Sub

#End Region


#Region " always maximized "

    Private Sub frmMain_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        Me.WindowState = FormWindowState.Maximized
    End Sub

#End Region




End Class




