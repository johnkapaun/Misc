﻿Imports System.Windows.Forms


Public Class equipmentClass



    Public Function scanEquipment(ByVal strConfigEquipment As String) As String
        Dim lstConfigList As ArrayList
        Dim eqForm As frmEquipment
        Dim arrConfigEquipment As String()
        Dim intI As Integer
        Dim intJ As Integer
        Dim strEquipmentTable As String
        Dim arrEquipmentTable As String(,)
        Try
            arrConfigEquipment = Split(strConfigEquipment, ";")
            '
            lstConfigList = New ArrayList
            For intI = 0 To arrConfigEquipment.GetUpperBound(0)
                lstConfigList.Add(arrConfigEquipment(intI))
            Next
            '
            eqForm = New frmEquipment
            eqForm.ConfigEquipment = lstConfigList
            eqForm.ShowDialog()
            '
            arrEquipmentTable = eqForm.EquipmentList
            '
            strEquipmentTable = ""
            For intI = 0 To arrEquipmentTable.GetUpperBound(0)
                For intJ = 0 To arrEquipmentTable.GetUpperBound(1)
                    strEquipmentTable = strEquipmentTable & arrEquipmentTable(intI, intJ) & ";"
                Next
                '
                ' remove the very last semicolon from the string 
                strEquipmentTable = Left(strEquipmentTable, strEquipmentTable.Length - 1)
                ' make sure no extra line feeds at the end
                If intI < arrEquipmentTable.GetUpperBound(0) Then
                    strEquipmentTable = strEquipmentTable & vbCrLf
                End If
            Next

            '
            Return strEquipmentTable
            '
        Catch ex As Exception
            MessageBox.Show(ex.Message, "EXCEPTION scanEquipment")
            Return Nothing
        End Try
    End Function

End Class
