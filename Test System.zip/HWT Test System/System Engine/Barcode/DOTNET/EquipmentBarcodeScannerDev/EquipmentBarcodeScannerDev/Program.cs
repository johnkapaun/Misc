﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
namespace EquipmentBarcodeScanner
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            ////
            ////
            //Thread newThread = new Thread(new ThreadStart(myMain));
            //newThread.SetApartmentState(ApartmentState.STA);
            //newThread.Start();
            ///*
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());
            //*/
        }
       
    }
}
