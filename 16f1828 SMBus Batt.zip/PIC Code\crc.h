/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: crc.h
*   revision: 1.0
*   date: 1/19/15 9:58p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* To speed up the lookup and calculation for the crc, this array has been 
* created.  The relative state of charge will be the index containing the
* PEC_CRC-8.  The polynomial for this calculation is: CRC = x^8+x^2+x+1  
* The algorithm uses a bit-wise calculation that mimics the hardware shift 
* register method and can be found on the TI website.
*
*  The PEC CRC is calculated using the following packet items:
*		Address+Write (0x16)
*		Command Code (0x0D)
*		Address+Read (0x17)
*		Data LSB (measured % charge 0 to 100 dec)
*		Data MSB (0x00)
*
*******************************************************************************/

//unsigned char PEC_CRC[101] = Index 0 to 100;

// This has to be in program space (4096 bytes) because this PIC only has 
// 256 bytes of data space.
const unsigned char PEC_CRC[] ={
						0x33, //0%
						0x26, //1
						0x19, //2
						0x0C, //3
						0x67, //4
						0x72, //5
						0x4D, //6
						0x58, //7
						0x9B, //8
						0x8E, //9
						0xB1, //10
						0xA4, //11
						0xCF, //12
						0xDA, //13
						0xE5, //14
						0xF0, //15
						0x64, //16
						0x71, //17
						0x4E, //18
						0x5B, //19
						0x30, //20
						0x25, //21
						0x1A, //22
						0x0F, //23
						0xCC, //24
						0xD9, //25
						0xE6, //26
						0xF3, //27
						0x98, //28
						0x8D, //29
						0xB2, //30
						0xA7, //31
						0x9D, //32
						0x88, //33
						0xB7, //34
						0xA2, //35
						0xC9, //36
						0xDC, //37
						0xE3, //38
						0xF6, //39
						0x35, //40
						0x20, //41
						0x1F, //42
						0x0A, //43
						0x61, //44
						0x74, //45
						0x4B, //46
						0x5E, //47
						0xCA, //48
						0xDF, //49
						0xE0, //50
						0xF5, //51
						0x9E, //52
						0x8B, //53
						0xB4, //54
						0xA1, //55
						0x62, //56
						0x77, //57
						0x48, //58
						0x5D, //59
						0x36, //60	
						0x23, //61
						0x1C, //62
						0x09, //63
						0x68, //64
						0x7D, //65
						0x42, //66
						0x57, //67
						0x3C, //68
						0x29, //69
						0x16, //70
						0x03, //71
						0xC0, //72
						0xD5, //73
						0xEA, //74
						0xFF, //75
						0x94, //76
						0x81, //77
						0xBE, //78
						0xAB, //79
						0x3F, //80
						0x2A, //81
						0x15, //82
						0x00, //83
						0x6B, //84
						0x7E, //85
						0x41, //86
						0x54, //87
						0x97, //88
						0x82, //89
						0xBD, //90
						0xA8, //91
						0xC3, //92
						0xD6, //93
						0xE9, //94
						0xFC, //95
						0xC6, //96
						0xD3, //97
						0xEC, //98
						0xF9, //99
						0x92  //100
};