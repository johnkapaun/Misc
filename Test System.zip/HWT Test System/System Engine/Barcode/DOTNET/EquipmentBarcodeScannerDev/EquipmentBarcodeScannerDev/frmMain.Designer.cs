﻿namespace EquipmentBarcodeScanner
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvConfigEquipment = new System.Windows.Forms.DataGridView();
            this.EquipmentFromConfigFile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.dgvDbEquipment = new System.Windows.Forms.DataGridView();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EquipmentNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CalibrationDueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manufacturer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAddEmptyRow = new System.Windows.Forms.Button();
            this.btnMoveRowDown = new System.Windows.Forms.Button();
            this.btnMoveRowUp = new System.Windows.Forms.Button();
            this.btnDeleteRow = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDone = new System.Windows.Forms.Button();
            this.btnManualEntry = new System.Windows.Forms.Button();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConfigEquipment)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDbEquipment)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvConfigEquipment);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(989, 416);
            this.splitContainer1.SplitterDistance = 169;
            this.splitContainer1.TabIndex = 0;
            // 
            // dgvConfigEquipment
            // 
            this.dgvConfigEquipment.AllowUserToAddRows = false;
            this.dgvConfigEquipment.AllowUserToDeleteRows = false;
            this.dgvConfigEquipment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConfigEquipment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EquipmentFromConfigFile});
            this.dgvConfigEquipment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConfigEquipment.Enabled = false;
            this.dgvConfigEquipment.Location = new System.Drawing.Point(0, 0);
            this.dgvConfigEquipment.Name = "dgvConfigEquipment";
            this.dgvConfigEquipment.ReadOnly = true;
            this.dgvConfigEquipment.RowHeadersVisible = false;
            this.dgvConfigEquipment.Size = new System.Drawing.Size(165, 412);
            this.dgvConfigEquipment.TabIndex = 0;
            // 
            // EquipmentFromConfigFile
            // 
            this.EquipmentFromConfigFile.HeaderText = "Equipment From Config File";
            this.EquipmentFromConfigFile.Name = "EquipmentFromConfigFile";
            this.EquipmentFromConfigFile.ReadOnly = true;
            this.EquipmentFromConfigFile.Width = 250;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.dgvDbEquipment);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.btnAddEmptyRow);
            this.splitContainer2.Panel2.Controls.Add(this.btnMoveRowDown);
            this.splitContainer2.Panel2.Controls.Add(this.btnMoveRowUp);
            this.splitContainer2.Panel2.Controls.Add(this.btnDeleteRow);
            this.splitContainer2.Panel2.Controls.Add(this.label1);
            this.splitContainer2.Panel2.Controls.Add(this.btnDone);
            this.splitContainer2.Panel2.Controls.Add(this.btnManualEntry);
            this.splitContainer2.Panel2.Controls.Add(this.Label6);
            this.splitContainer2.Panel2.Controls.Add(this.Label7);
            this.splitContainer2.Size = new System.Drawing.Size(812, 412);
            this.splitContainer2.SplitterDistance = 693;
            this.splitContainer2.TabIndex = 0;
            // 
            // dgvDbEquipment
            // 
            this.dgvDbEquipment.AllowUserToAddRows = false;
            this.dgvDbEquipment.AllowUserToDeleteRows = false;
            this.dgvDbEquipment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDbEquipment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Description,
            this.EquipmentNumber,
            this.Status,
            this.CalibrationDueDate,
            this.Manufacturer,
            this.Department});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Gold;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDbEquipment.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDbEquipment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDbEquipment.Location = new System.Drawing.Point(0, 0);
            this.dgvDbEquipment.MultiSelect = false;
            this.dgvDbEquipment.Name = "dgvDbEquipment";
            this.dgvDbEquipment.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDbEquipment.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDbEquipment.RowHeadersWidth = 30;
            this.dgvDbEquipment.Size = new System.Drawing.Size(693, 412);
            this.dgvDbEquipment.TabIndex = 0;
            this.dgvDbEquipment.SelectionChanged += new System.EventHandler(this.dgvDbEquipment_SelectionChanged);
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Description.Width = 150;
            // 
            // EquipmentNumber
            // 
            this.EquipmentNumber.HeaderText = "Equipment Number";
            this.EquipmentNumber.Name = "EquipmentNumber";
            this.EquipmentNumber.ReadOnly = true;
            this.EquipmentNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EquipmentNumber.Width = 120;
            // 
            // Status
            // 
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CalibrationDueDate
            // 
            this.CalibrationDueDate.HeaderText = "Calibration Due Date";
            this.CalibrationDueDate.Name = "CalibrationDueDate";
            this.CalibrationDueDate.ReadOnly = true;
            this.CalibrationDueDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CalibrationDueDate.Width = 125;
            // 
            // Manufacturer
            // 
            this.Manufacturer.HeaderText = "Manufacturer";
            this.Manufacturer.Name = "Manufacturer";
            this.Manufacturer.ReadOnly = true;
            this.Manufacturer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Manufacturer.Width = 75;
            // 
            // Department
            // 
            this.Department.HeaderText = "Department";
            this.Department.Name = "Department";
            this.Department.Width = 75;
            // 
            // btnAddEmptyRow
            // 
            this.btnAddEmptyRow.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEmptyRow.Image")));
            this.btnAddEmptyRow.Location = new System.Drawing.Point(58, 224);
            this.btnAddEmptyRow.Name = "btnAddEmptyRow";
            this.btnAddEmptyRow.Size = new System.Drawing.Size(50, 45);
            this.btnAddEmptyRow.TabIndex = 42;
            this.toolTip1.SetToolTip(this.btnAddEmptyRow, "Add empty row");
            this.btnAddEmptyRow.UseVisualStyleBackColor = true;
            this.btnAddEmptyRow.Click += new System.EventHandler(this.btnAddEmptyRow_Click);
            // 
            // btnMoveRowDown
            // 
            this.btnMoveRowDown.Image = ((System.Drawing.Image)(resources.GetObject("btnMoveRowDown.Image")));
            this.btnMoveRowDown.Location = new System.Drawing.Point(58, 173);
            this.btnMoveRowDown.Name = "btnMoveRowDown";
            this.btnMoveRowDown.Size = new System.Drawing.Size(50, 45);
            this.btnMoveRowDown.TabIndex = 41;
            this.toolTip1.SetToolTip(this.btnMoveRowDown, "Move selected row down");
            this.btnMoveRowDown.UseVisualStyleBackColor = true;
            this.btnMoveRowDown.Click += new System.EventHandler(this.btnMoveRowDown_Click);
            // 
            // btnMoveRowUp
            // 
            this.btnMoveRowUp.Image = ((System.Drawing.Image)(resources.GetObject("btnMoveRowUp.Image")));
            this.btnMoveRowUp.Location = new System.Drawing.Point(5, 173);
            this.btnMoveRowUp.Name = "btnMoveRowUp";
            this.btnMoveRowUp.Size = new System.Drawing.Size(50, 45);
            this.btnMoveRowUp.TabIndex = 40;
            this.toolTip1.SetToolTip(this.btnMoveRowUp, "Move selected row up");
            this.btnMoveRowUp.UseVisualStyleBackColor = true;
            this.btnMoveRowUp.Click += new System.EventHandler(this.btnMoveRowUp_Click);
            // 
            // btnDeleteRow
            // 
            this.btnDeleteRow.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnDeleteRow.Image = ((System.Drawing.Image)(resources.GetObject("btnDeleteRow.Image")));
            this.btnDeleteRow.Location = new System.Drawing.Point(5, 224);
            this.btnDeleteRow.Name = "btnDeleteRow";
            this.btnDeleteRow.Size = new System.Drawing.Size(50, 45);
            this.btnDeleteRow.TabIndex = 39;
            this.btnDeleteRow.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnDeleteRow, "Delete selected row");
            this.btnDeleteRow.UseVisualStyleBackColor = true;
            this.btnDeleteRow.Click += new System.EventHandler(this.btnDeleteRow_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.PaleGreen;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(4, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 45);
            this.label1.TabIndex = 38;
            this.label1.Text = "Good";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDone
            // 
            this.btnDone.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnDone.Image = ((System.Drawing.Image)(resources.GetObject("btnDone.Image")));
            this.btnDone.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDone.Location = new System.Drawing.Point(5, 326);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(104, 45);
            this.btnDone.TabIndex = 36;
            this.btnDone.Text = "Done";
            this.btnDone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnDone, "Done");
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // btnManualEntry
            // 
            this.btnManualEntry.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnManualEntry.Image = ((System.Drawing.Image)(resources.GetObject("btnManualEntry.Image")));
            this.btnManualEntry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManualEntry.Location = new System.Drawing.Point(5, 275);
            this.btnManualEntry.Name = "btnManualEntry";
            this.btnManualEntry.Size = new System.Drawing.Size(104, 45);
            this.btnManualEntry.TabIndex = 35;
            this.btnManualEntry.Text = "Manual Entry";
            this.btnManualEntry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolTip1.SetToolTip(this.btnManualEntry, "Enter equipment manually");
            this.btnManualEntry.UseVisualStyleBackColor = true;
            this.btnManualEntry.Click += new System.EventHandler(this.btnManualEntry_Click);
            // 
            // Label6
            // 
            this.Label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Label6.BackColor = System.Drawing.Color.Gold;
            this.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label6.Location = new System.Drawing.Point(4, 49);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(107, 45);
            this.Label6.TabIndex = 26;
            this.Label6.Text = "Due in 30 days, or out of department";
            this.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label7
            // 
            this.Label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Label7.BackColor = System.Drawing.Color.Tomato;
            this.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label7.Location = new System.Drawing.Point(4, 4);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(107, 45);
            this.Label7.TabIndex = 27;
            this.Label7.Text = "Invalid, unavailable, or past due\r\n";
            this.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 416);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scan Equipment";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyDown);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConfigEquipment)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDbEquipment)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label7;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridView dgvConfigEquipment;
        private System.Windows.Forms.DataGridView dgvDbEquipment;
        private System.Windows.Forms.Button btnManualEntry;
        private System.Windows.Forms.DataGridViewTextBoxColumn EquipmentFromConfigFile;
        private System.Windows.Forms.Button btnDone;
        internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDeleteRow;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn EquipmentNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn CalibrationDueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manufacturer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.Button btnMoveRowDown;
        private System.Windows.Forms.Button btnMoveRowUp;
        private System.Windows.Forms.Button btnAddEmptyRow;
    }
}

