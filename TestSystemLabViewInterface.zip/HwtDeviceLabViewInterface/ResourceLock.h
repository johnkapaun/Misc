
#pragma once

class ApplicationResourceLock
{
	private:
		HANDLE LockHandle;
		bool Locked;

	public:
		ApplicationResourceLock(ErrorCluster *error, bool LockResource = true);
		void Lock(ErrorCluster *error);
		void UnLock(void);
		~ApplicationResourceLock();

	// Disable the copy constructor and assignment so you will get compiler errors 
	//		instead of unexpected behaviour if you pass objects by value or assign objects.
	private:
		ApplicationResourceLock(const ApplicationResourceLock& objectSrc);	// no implementation
		void operator=(const ApplicationResourceLock& objectSrc);			// no implementation
};
