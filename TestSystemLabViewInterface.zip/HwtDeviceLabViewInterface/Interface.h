/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Aug 25 15:52:49 2008
 */
/* Compiler settings for C:\c_code\HwtDeviceLabViewInterface\external\Interface.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __Interface_h__
#define __Interface_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __HWT_CRM_DEV_INTERFACE_DEFINED__
#define __HWT_CRM_DEV_INTERFACE_DEFINED__

/* interface HWT_CRM_DEV */
/* [auto_handle][unique][version][uuid] */ 

void AddRef( 
    /* [in] */ handle_t h1,
    /* [in] */ unsigned long ProcessID);

void Release( 
    /* [in] */ handle_t h1,
    /* [in] */ unsigned long ProcessID);

void RemDeviceFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemUplinkFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemDeviceAndUplinkFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemLoadControllerLibrary( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemLoadDeviceLibrary( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemID_Device( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemControllerDLL_FileNames( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemDeviceDLL_FileName( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemVerifyCommonDeviceDllVersion( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemVerifyDeviceSpecificDllVersion( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemUpdateLocalDLL( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemFormattedVersionInfo( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemLoadFirmwareMap( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemDeviceModelName( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemCheckForFirmwarePatch( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemMenuPath( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemProgramCacheControl( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemSupportedFunctions( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemControllerDebugFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemVerifyHwtDeviceCommonInterface( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemVerifyAppInterfaceVersions( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemControllerDirectAccessFunction( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemDllAndInterfaceVersionInfo( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);

void RemRevisionCheckFile( 
    /* [in] */ handle_t h1,
    /* [in] */ long lSizeIn,
    /* [size_is][in] */ unsigned char __RPC_FAR *DataIn,
    /* [out] */ long __RPC_FAR *lSizeOut,
    /* [size_is][size_is][out] */ unsigned char __RPC_FAR *__RPC_FAR *DataOut);



extern RPC_IF_HANDLE HWT_CRM_DEV_v1_0_c_ifspec;
extern RPC_IF_HANDLE HWT_CRM_DEV_v1_0_s_ifspec;
#endif /* __HWT_CRM_DEV_INTERFACE_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
