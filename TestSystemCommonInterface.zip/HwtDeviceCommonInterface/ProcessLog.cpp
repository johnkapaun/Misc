
#include "stdafx.h"
#include "main.h"

//////////////////////////////////////////////////////////////////////
////////////////////////////// ProcessInfo ///////////////////////////
//////////////////////////////////////////////////////////////////////

ProcessInfo::ProcessInfo(void)
{
	ProcessID = 0;			// Initialize ProcessInfo object to
	HandleCount = 0;		// and empty object
	ReleaseEvent = NULL;
}

//////////////////////////////////////////////////////////////////////
////////////////////////////// ProcessLog ////////////////////////////
//////////////////////////////////////////////////////////////////////

ProcessLog::ProcessLog(void)	// Constructor
{
	InitializeCriticalSection(&ObjectCriticalSection);
}

ProcessLog::~ProcessLog()		// Destructor
{
	DeleteCriticalSection(&ObjectCriticalSection);
}

// The AddRef function is called when the Client application
// calls the 'AddRef' interface function
bool ProcessLog::AddRef( unsigned long ProcessID )
{
	bool NewProcessFlag = false;

	EnterCriticalSection(&ObjectCriticalSection);

	// Search table for previous entry for process
	ProcessTable::iterator ptr = Table.find( ProcessID );

	if( ptr == Table.end() )	// if no previous entry
	{
		ProcessInfo Info;		// create new process entry

		Info.ProcessID = ProcessID;
		Info.HandleCount = 1;
		Info.ReleaseEvent = CreateEvent( NULL, false, false, NULL ); // Create Event Object

		Table.insert(ProcessTable::value_type( ProcessID, Info ));
		NewProcessFlag = true;
	}

	else	// else, update handle count for existing entry
		ptr->second.HandleCount += 1;


	LeaveCriticalSection(&ObjectCriticalSection);

	return NewProcessFlag;
}

// The ReleaseRef function is called when the Client application
// calls the 'Release' interface function
void ProcessLog::ReleaseRef( unsigned long ProcessID )
{
	EnterCriticalSection(&ObjectCriticalSection);

	// Search table for process entry
	ProcessTable::iterator ptr = Table.find( ProcessID );

	if( ptr != Table.end() )	// if entry found (should alway be found)
	{
		ptr->second.HandleCount -= 1;	// reduce the handle count

		if( ptr->second.HandleCount == 0 )	// if handle count is now zero
		{
			if( ptr->second.ReleaseEvent != NULL )	// if valid Event was created during 'AddRef'
			{
				SetEvent( ptr->second.ReleaseEvent );		// Signal the 'WaitForProcessExitThread' function
															// the Process has disconnected.
				CloseHandle( ptr->second.ReleaseEvent );	// close the Event Handle
			}
			Table.erase( ptr );	// remove the process from the table
		}
	}

	LeaveCriticalSection(&ObjectCriticalSection);
}

// The ReleaseProcess function is called when the 'WaitForProcessExitThread'
// function detects the Client application has disconnected (shutdown).
void ProcessLog::ReleaseProcess( unsigned long ProcessID )
{
	if( ProcessID == 0 )
		return;

	EnterCriticalSection(&ObjectCriticalSection);

	// Search table for process entry
	ProcessTable::iterator ptr = Table.find( ProcessID );

	if( ptr != Table.end() )	// if entry is found
		Table.erase( ptr );		// delete entry

	LeaveCriticalSection(&ObjectCriticalSection);
}

// Returns the 'ProcessInfo' object for the specified process
// an empty object (ProcessID == 0) if the process is not found
ProcessInfo ProcessLog::GetProcessInfo( unsigned long ProcessID )
{
	ProcessInfo Info;	// create empty ProcessInfo object

	EnterCriticalSection(&ObjectCriticalSection);

	ProcessTable::iterator ptr = Table.find( ProcessID );

	// Search table for process entry
	if( ptr != Table.end() )
	{
		Info = ptr->second;	// if found, update ProcessInfo object
	}

	LeaveCriticalSection(&ObjectCriticalSection);

	return Info;	// return Process Info
}

// returns the number of connected Client applications
unsigned int ProcessLog::ActiveClients(void)
{
	EnterCriticalSection(&ObjectCriticalSection);

	unsigned int Size = Table.size();

	LeaveCriticalSection(&ObjectCriticalSection);

	return Size;
}

// Given a procesID this function returns the process name
static TString GetProcessName( unsigned dwPID )
{
	HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
	MODULEENTRY32 me32;

	TString ProcessName;

	// Create a default return value should we have an error
	ProcessName.Format( "ProcessID = %08X", dwPID );

	//  Take a snapshot of all modules in the specified process.
	hModuleSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE, dwPID );

	// if error creating a snapshot
	if( hModuleSnap == INVALID_HANDLE_VALUE )
		return ProcessName;	// exit using default string
 
	//  Set the size of the structure before using it.
	me32.dwSize = sizeof( MODULEENTRY32 );
 
	//  Retrieve information about the first module
	if( Module32First( hModuleSnap, &me32 ) )	// if no errors
		ProcessName = me32.szModule;			// update string to be returned

	//  Clean up the snapshot object
	CloseHandle( hModuleSnap );

	return ProcessName;
}

/////////////////////////////////////
/////////////////////////////////////

// create a report listing all the attached Client applications
TString ProcessLog::ProcessReport(void)
{
	TString buffer;	// string to hold report of all clients
	TString temp;	// string to hold report for one client during the report build

	EnterCriticalSection(&ObjectCriticalSection);

	// for each process in the process table
	for(ProcessTable::iterator ptr = Table.begin(); ptr != Table.end(); ptr++)
	{
		// convert processID into process name, add to report
		temp.Format("%s\r\n", GetProcessName(ptr->first).CStr() );
		buffer += temp;
	}

	LeaveCriticalSection(&ObjectCriticalSection);

	return buffer;	// return report
}

// create a report listing all the process ID and Handle count of all Client applications
TString ProcessLog::ProcessReportRaw(void)
{
	TString buffer;	// string to hold report of all clients
	TString temp;	// string to hold report for one client during the report build

	EnterCriticalSection(&ObjectCriticalSection);

	// for each process in the process table
	for(ProcessTable::iterator ptr = Table.begin(); ptr != Table.end(); ptr++)
	{
		// build report for current processID, add to report
		temp.Format("ProcessID = %08X    HandleCount = %d\r\n", ptr->first, ptr->second.HandleCount );
		buffer += temp;
	}

	LeaveCriticalSection(&ObjectCriticalSection);

	return buffer;	// return report
}

// Returns a list of all modules in all Client application that are located
// in the folder identified by the LocalInterfacePath function (C:\CRM_HWT\Interface\)
TStringArray ProcessLog::InterfaceList( ErrorCluster *error )
{
	TStringArray List;
	TStringArray ReducedList;

	if( error->Status() )
		return List;

	EnterCriticalSection(&ObjectCriticalSection);

	// Build list of all Application Interfaces used on all Client Applications
	for(ProcessTable::iterator ptr = Table.begin(); ptr != Table.end(); ptr++)
		List.Insert( GetInterfaceListForProcess( error, ptr->first ) );

	LeaveCriticalSection(&ObjectCriticalSection);

	// Remove Duplicate entries
	for( int i = 0; i < List.GetSize(); i++ )
	{
		bool isDuplicate = false;

		for( int ii = 0; isDuplicate == false && ii < ReducedList.GetSize(); ii++ )
			isDuplicate = stricmp( List[i], ReducedList[ii] ) == 0 ;

		if( !isDuplicate )
			ReducedList.Insert( List[i] );
	}

	return ReducedList;
}

// Returns a list of all modules in the specified process that are located
// in the folder identified by the LocalInterfacePath function (C:\CRM_HWT\Interface\)
TStringArray ProcessLog::GetInterfaceListForProcess( ErrorCluster *error, unsigned dwPID ) const
{
	TString InterfacePath = LocalInterfacePath();
	HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
	MODULEENTRY32 me32;
	TStringArray List;

	if( error->Status() )
		return List;

	//  Take a snapshot of all modules in the specified process.
	hModuleSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE, dwPID );

	if( hModuleSnap == INVALID_HANDLE_VALUE )
	{
		error->SetError( 42, "Get Interface List For Process '%s' Failed", GetProcessName(dwPID).CStr() );
		return List;
	}

	//  Set the size of the structure before using it.
	me32.dwSize = sizeof( MODULEENTRY32 );
  
	//  Retrieve information about the first module, and exit if unsuccessful
	if( !Module32First( hModuleSnap, &me32 ) )
	{
		error->SetError( 42, "Get Interface List For Process '%s' Failed", GetProcessName(dwPID).CStr() );
		CloseHandle( hModuleSnap );		// Must clean up the snapshot object!
		return List;
	}

	//  Walk the module list of the process, and save paths to interface modules
	do
	{
		if( _strnicmp( me32.szExePath, InterfacePath, InterfacePath.Length() ) == 0 )
			List.Insert( me32.szExePath );

	} while( Module32Next( hModuleSnap, &me32 ) );

	//  Clean up the snapshot object
	CloseHandle( hModuleSnap );

	return List;
}

/////////////////////////////////////////////////////////////////
