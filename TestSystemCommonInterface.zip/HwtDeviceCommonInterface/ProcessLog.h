


struct ProcessInfo
{ 
	ProcessInfo(void);

	unsigned long ProcessID;
	unsigned HandleCount;
	HANDLE ReleaseEvent;
};


class ProcessLog
{
	typedef map<unsigned long, ProcessInfo, less<unsigned long>, allocator<ProcessInfo> > ProcessTable;

	private:
		ProcessTable Table;

		CRITICAL_SECTION ObjectCriticalSection;	// Critical-section object

	public:
		ProcessLog(void);
		~ProcessLog();

		bool AddRef( unsigned long ProcessID );

		void ReleaseRef( unsigned long ProcessID );

		void ReleaseProcess( unsigned long ProcessID );

		ProcessInfo ProcessLog::GetProcessInfo( unsigned long ProcessID );

		unsigned int ActiveClients(void);

		TString ProcessReport(void);
		TString ProcessReportRaw(void);

		TStringArray InterfaceList( ErrorCluster *error );

	private:
		TStringArray GetInterfaceListForProcess( ErrorCluster *error, unsigned dwPID ) const;
};
