
#include "stdafx.h"
#include "ResourceLock.h"

ApplicationResourceLock::ApplicationResourceLock(ErrorCluster *error, bool LockResource )
{
	LockHandle = CreateMutex(NULL, FALSE, "CRM_DEV ApplicationLock");

	Locked = false;

	if( error->Status() )
		return;

	if( LockResource )
		Lock(error);

	else if( LockHandle == NULL )
		error->SetError(72,"Application Resource Lock not Found!");
}

void ApplicationResourceLock::Lock(ErrorCluster *error)
{
	if( error->Status() || Locked )
		return;

	if( LockHandle == NULL )
	{
		error->SetError(72,"Application Resource Lock not Found!");
		return;
	}

	switch( WaitForSingleObject( LockHandle, 60000 ) ) // Wait for up to 60 Seconds
	{
		case WAIT_OBJECT_0:
			Locked = true;
			break;

		case WAIT_TIMEOUT:
			Locked = false;
			error->SetError(72,"Application Resource Lock Timeout!");
			break;

		case WAIT_ABANDONED:
			Locked = true;
			error->SetError(72,"Application Resource Lock in a Undefined State!");
			break;

		default:
			Locked = false;
			error->SetError(72,"Application Resource Lock request returned unexpected response!");
			break;
	}
}

void ApplicationResourceLock::UnLock(void)
{
	if( Locked )
		Locked = (ReleaseMutex( LockHandle )) ? false : Locked;
}

ApplicationResourceLock::~ApplicationResourceLock()
{
	UnLock();

	if( LockHandle != NULL )
		CloseHandle( LockHandle );

	LockHandle = NULL;
}
