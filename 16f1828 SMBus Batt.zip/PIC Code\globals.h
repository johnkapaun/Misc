/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: globals.h
*   revision: 1.0
*   date: 1/19/15 9:29p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* This file contains the definitions of items needing to be used by
* multiple functions...sometimes.  These would include trim type values.
* Most of the reason it was done this way was to speed up writing this
* code due to one of the debugger tools used.   
*
*******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <pic16f1828.h>

// Using Internal Clock of 32 Mhz
	#define FOSC 32000000L

//  Test Modes, Status, and other
	extern volatile unsigned char Test_Mode; 	// Controls response behavior (isr.c)
	
//  The System Error and Status is Defined as follows:
//	XXXX XXX1	RX Size 1 byte Command unKnown Error
//  XXXX XX1X	RX Size 2 byte Command unKnown Error
//	XXXX X1XX	Test_Mode Select Error
//  XXXX 1XXX	Primary or Secondary RAM write Error
//  XXX1 XXXX 	RX Command Recieved Error
//	XX1X XXXX	TXREG Flag Error (Data Uplink Didn't Occur)
//	00XX XXXX	Normal Operations
//	01XX XXXX	Test Mode Enabled
//  10XX XXXX	ADC Offset Trim Enabled
//	11XX XXXX	SMBus State Unkown (*Only uplink when test mode is enabled)
	extern unsigned char status;				// Instrument Error and Status (isr.c)

	extern volatile char ResponseType;			// SMBus response array used (isr.c)
	extern int ResponseStartIndex;				// DataArray Start Index (isr.c)
	extern int ResponseLength;					// DataArray Start Index (isr.c)

	extern int CutOutCnt; //Count of Battery cut outs
	volatile int SMBusTimeOut=0; //Count of Battery cut outs

//	extern int ADC_Offset;	// ADC Offset Trim (main.c)
//	extern int Batt_High;	// RSOC 100% voltage value (main.c)
//	extern int Batt_Low;	// RSOC 0% voltage value (main.c)

// Serial Interface defs
//	#define SER_BUFFER_SIZE		26	// Transmit and Receive Buffer Size
//	extern volatile unsigned char rxfifo[SER_BUFFER_SIZE]; 		// Receive Buffer. Size = Primary_Data array size + 1
																// If the array being downloaded contains 26 values,
																// the first value [0] will contain 'P' or 'S' to
																// show if the primary or secondary data is being
																// updated in RAM.
//	extern unsigned char txfifo[11];				// Transmit Buffer (ser.c)
	volatile unsigned char txfifo[] = {0x08,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xA5,0xA5};

	extern void WaitForACKTIM(void);
	extern void WaitForACKTIMnot(void);
	extern void WaitForSSP1IF(void);
	void SendData(void); 		// Transmit data function

	// This array is used to detirmine if a command read is supported.  If it
	// is found in this array, the index it is found will be stored because it
	// is later used to sort the Primary_Data and/or Secondary_Data array values
	// that may be used.  Only commands that generate a response on the SMBus
	// should be listed.  The order they are listed must match the Array Index
	// Control (AIC).  Comparisons to this array will start at index [0] so
	// it may be worth having the most used commands early in this array.
	// NOTE: Index 0 must always reference the state of Charge!
	// The last value should be a repeat of the first item.  This is used
	// to capture commands not found.
//	unsigned int Command_Lookup[7];    // a RAM array that you can write to.
	volatile unsigned char Command_Lookup[]={0x0D,0x00,0x17,0x1B,0x1C,0x70,0x0D};

	// Array Index Control (AIC) - The Command_Lookup array is used to sort this 
	// array which contains two values for each command.  The first value is the 
	// start index in the Primary or Secondary Array values being sent back.  
	// The second value is the length or number of bytes that will be written back.
	//     Command_Lookup match index * 2 = the start index location 
	//     (Command_Lookup match index * 2)+1 = the length
	// NOTE: Index 0 & 1 must always reference the state of Charge!
//	unsigned int AIC[12];    // a RAM array that you can write to.
	volatile unsigned char AIC[]={0x00,0x03,0x03,0x03,0x06,0x03,0x09,0x03,0x0C,0x03,0x0F,0x0A};

	// These arrays contain the data the unit will respond with.  The Primary_Data 
	// will also be used when the Test_Mode is not enabled.  However, when not in
	// Test_Mode, index [0] will contain a charge percent measured on AN3 and index
	// [1] and [2] will contain a valid CRC. When in Test_Mode the array will be
	// constant.
//	unsigned int Primary_Data[25];    // a RAM array that you can write to.
	volatile unsigned char Primary_Data[]={0x5D,0x00,0xD6,0x00,0x00,0xCD,0x05,0x00,0x89,0x37,0x43,0x7C,0x7B,0x00,0x77,0x08,0x30,0x30,0x30,0x35,0x33,0x38,0x38,0x39,0x6D};

	// The following array will only be used when in Test_Mode
//	unsigned int Secondary_Data[25];    // a RAM array that you can write to.
	volatile unsigned char Secondary_Data[]={0x5D,0x00,0xEE,0x00,0x00,0xFF,0x05,0x00,0xFF,0xF0,0x44,0xFF,0x22,0x00,0xFF,0x08,0x30,0x30,0x30,0x35,0x33,0x38,0x38,0x39,0xFF};

	// These arrays are used to control secondary data when Test Mode is enabled
	volatile unsigned char Set_Secondary[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	volatile unsigned char Current_Secondary[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};