/* this ALWAYS GENERATED file contains the RPC server stubs */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Aug 25 15:52:49 2008
 */
/* Compiler settings for C:\c_code\HwtDeviceLabViewInterface\external\Interface.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )

#include <string.h>
#include "Interface.h"

#define TYPE_FORMAT_STRING_SIZE   39                                
#define PROC_FORMAT_STRING_SIZE   25                                

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;

extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;

/* Standard interface: HWT_CRM_DEV, ver. 1.0,
   GUID={0xc08f354c,0xc4b2,0x4310,{0xae,0xd0,0x39,0x91,0xb2,0x20,0x97,0x1d}} */


extern RPC_DISPATCH_TABLE HWT_CRM_DEV_v1_0_DispatchTable;

static const RPC_SERVER_INTERFACE HWT_CRM_DEV___RpcServerInterface =
    {
    sizeof(RPC_SERVER_INTERFACE),
    {{0xc08f354c,0xc4b2,0x4310,{0xae,0xd0,0x39,0x91,0xb2,0x20,0x97,0x1d}},{1,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    &HWT_CRM_DEV_v1_0_DispatchTable,
    0,
    0,
    0,
    0,
    0
    };
RPC_IF_HANDLE HWT_CRM_DEV_v1_0_s_ifspec = (RPC_IF_HANDLE)& HWT_CRM_DEV___RpcServerInterface;

extern const MIDL_STUB_DESC HWT_CRM_DEV_StubDesc;

void __RPC_STUB
HWT_CRM_DEV_AddRef(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned long ProcessID;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[0] );
            
            ProcessID = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        
        AddRef(h1,ProcessID);
        
        }
    RpcFinally
        {
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_Release(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned long ProcessID;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[0] );
            
            ProcessID = *(( unsigned long __RPC_FAR * )_StubMsg.Buffer)++;
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        
        Release(h1,ProcessID);
        
        }
    RpcFinally
        {
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemDeviceFunction(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M48;
    unsigned char __RPC_FAR *_M49;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M48;
        DataOut = &_M49;
        _M49 = 0;
        
        RemDeviceFunction(
                     h1,
                     lSizeIn,
                     DataIn,
                     lSizeOut,
                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemUplinkFunction(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M50;
    unsigned char __RPC_FAR *_M51;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M50;
        DataOut = &_M51;
        _M51 = 0;
        
        RemUplinkFunction(
                     h1,
                     lSizeIn,
                     DataIn,
                     lSizeOut,
                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemDeviceAndUplinkFunction(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M52;
    unsigned char __RPC_FAR *_M53;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M52;
        DataOut = &_M53;
        _M53 = 0;
        
        RemDeviceAndUplinkFunction(
                              h1,
                              lSizeIn,
                              DataIn,
                              lSizeOut,
                              DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemLoadControllerLibrary(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M54;
    unsigned char __RPC_FAR *_M55;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M54;
        DataOut = &_M55;
        _M55 = 0;
        
        RemLoadControllerLibrary(
                            h1,
                            lSizeIn,
                            DataIn,
                            lSizeOut,
                            DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemLoadDeviceLibrary(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M56;
    unsigned char __RPC_FAR *_M57;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M56;
        DataOut = &_M57;
        _M57 = 0;
        
        RemLoadDeviceLibrary(
                        h1,
                        lSizeIn,
                        DataIn,
                        lSizeOut,
                        DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemID_Device(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M58;
    unsigned char __RPC_FAR *_M59;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M58;
        DataOut = &_M59;
        _M59 = 0;
        
        RemID_Device(
                h1,
                lSizeIn,
                DataIn,
                lSizeOut,
                DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemControllerDLL_FileNames(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M60;
    unsigned char __RPC_FAR *_M61;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M60;
        DataOut = &_M61;
        _M61 = 0;
        
        RemControllerDLL_FileNames(
                              h1,
                              lSizeIn,
                              DataIn,
                              lSizeOut,
                              DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemDeviceDLL_FileName(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M62;
    unsigned char __RPC_FAR *_M63;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M62;
        DataOut = &_M63;
        _M63 = 0;
        
        RemDeviceDLL_FileName(
                         h1,
                         lSizeIn,
                         DataIn,
                         lSizeOut,
                         DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemVerifyCommonDeviceDllVersion(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M64;
    unsigned char __RPC_FAR *_M65;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M64;
        DataOut = &_M65;
        _M65 = 0;
        
        RemVerifyCommonDeviceDllVersion(
                                   h1,
                                   lSizeIn,
                                   DataIn,
                                   lSizeOut,
                                   DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemVerifyDeviceSpecificDllVersion(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M66;
    unsigned char __RPC_FAR *_M67;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M66;
        DataOut = &_M67;
        _M67 = 0;
        
        RemVerifyDeviceSpecificDllVersion(
                                     h1,
                                     lSizeIn,
                                     DataIn,
                                     lSizeOut,
                                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemUpdateLocalDLL(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M68;
    unsigned char __RPC_FAR *_M69;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M68;
        DataOut = &_M69;
        _M69 = 0;
        
        RemUpdateLocalDLL(
                     h1,
                     lSizeIn,
                     DataIn,
                     lSizeOut,
                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemFormattedVersionInfo(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M70;
    unsigned char __RPC_FAR *_M71;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M70;
        DataOut = &_M71;
        _M71 = 0;
        
        RemFormattedVersionInfo(
                           h1,
                           lSizeIn,
                           DataIn,
                           lSizeOut,
                           DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemLoadFirmwareMap(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M72;
    unsigned char __RPC_FAR *_M73;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M72;
        DataOut = &_M73;
        _M73 = 0;
        
        RemLoadFirmwareMap(
                      h1,
                      lSizeIn,
                      DataIn,
                      lSizeOut,
                      DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemDeviceModelName(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M74;
    unsigned char __RPC_FAR *_M75;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M74;
        DataOut = &_M75;
        _M75 = 0;
        
        RemDeviceModelName(
                      h1,
                      lSizeIn,
                      DataIn,
                      lSizeOut,
                      DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemCheckForFirmwarePatch(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M76;
    unsigned char __RPC_FAR *_M77;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M76;
        DataOut = &_M77;
        _M77 = 0;
        
        RemCheckForFirmwarePatch(
                            h1,
                            lSizeIn,
                            DataIn,
                            lSizeOut,
                            DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemMenuPath(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M78;
    unsigned char __RPC_FAR *_M79;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M78;
        DataOut = &_M79;
        _M79 = 0;
        
        RemMenuPath(
               h1,
               lSizeIn,
               DataIn,
               lSizeOut,
               DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemProgramCacheControl(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M80;
    unsigned char __RPC_FAR *_M81;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M80;
        DataOut = &_M81;
        _M81 = 0;
        
        RemProgramCacheControl(
                          h1,
                          lSizeIn,
                          DataIn,
                          lSizeOut,
                          DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemSupportedFunctions(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M82;
    unsigned char __RPC_FAR *_M83;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M82;
        DataOut = &_M83;
        _M83 = 0;
        
        RemSupportedFunctions(
                         h1,
                         lSizeIn,
                         DataIn,
                         lSizeOut,
                         DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemControllerDebugFunction(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M84;
    unsigned char __RPC_FAR *_M85;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M84;
        DataOut = &_M85;
        _M85 = 0;
        
        RemControllerDebugFunction(
                              h1,
                              lSizeIn,
                              DataIn,
                              lSizeOut,
                              DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemVerifyHwtDeviceCommonInterface(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M86;
    unsigned char __RPC_FAR *_M87;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M86;
        DataOut = &_M87;
        _M87 = 0;
        
        RemVerifyHwtDeviceCommonInterface(
                                     h1,
                                     lSizeIn,
                                     DataIn,
                                     lSizeOut,
                                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemVerifyAppInterfaceVersions(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M88;
    unsigned char __RPC_FAR *_M89;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M88;
        DataOut = &_M89;
        _M89 = 0;
        
        RemVerifyAppInterfaceVersions(
                                 h1,
                                 lSizeIn,
                                 DataIn,
                                 lSizeOut,
                                 DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemControllerDirectAccessFunction(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M90;
    unsigned char __RPC_FAR *_M91;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M90;
        DataOut = &_M91;
        _M91 = 0;
        
        RemControllerDirectAccessFunction(
                                     h1,
                                     lSizeIn,
                                     DataIn,
                                     lSizeOut,
                                     DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemDllAndInterfaceVersionInfo(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M92;
    unsigned char __RPC_FAR *_M93;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M92;
        DataOut = &_M93;
        _M93 = 0;
        
        RemDllAndInterfaceVersionInfo(
                                 h1,
                                 lSizeIn,
                                 DataIn,
                                 lSizeOut,
                                 DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}

void __RPC_STUB
HWT_CRM_DEV_RemRevisionCheckFile(
    PRPC_MESSAGE _pRpcMessage )
{
    unsigned char __RPC_FAR *DataIn;
    unsigned char __RPC_FAR *__RPC_FAR *DataOut;
    long _M94;
    unsigned char __RPC_FAR *_M95;
    MIDL_STUB_MESSAGE _StubMsg;
    handle_t h1;
    long lSizeIn;
    long __RPC_FAR *lSizeOut;
    RPC_STATUS _Status;
    
    ((void)(_Status));
    NdrServerInitializeNew(
                          _pRpcMessage,
                          &_StubMsg,
                          &HWT_CRM_DEV_StubDesc);
    
    h1 = _pRpcMessage->Handle;
    ( unsigned char __RPC_FAR * )DataIn = 0;
    ( long __RPC_FAR * )lSizeOut = 0;
    ( unsigned char __RPC_FAR *__RPC_FAR * )DataOut = 0;
    RpcTryFinally
        {
        RpcTryExcept
            {
            if ( (_pRpcMessage->DataRepresentation & 0X0000FFFFUL) != NDR_LOCAL_DATA_REPRESENTATION )
                NdrConvert( (PMIDL_STUB_MESSAGE) &_StubMsg, (PFORMAT_STRING) &__MIDL_ProcFormatString.Format[6] );
            
            lSizeIn = *(( long __RPC_FAR * )_StubMsg.Buffer)++;
            
            NdrConformantArrayUnmarshall( (PMIDL_STUB_MESSAGE) &_StubMsg,
                                          (unsigned char __RPC_FAR * __RPC_FAR *)&DataIn,
                                          (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[6],
                                          (unsigned char)0 );
            
            if(_StubMsg.Buffer > _StubMsg.BufferEnd)
                {
                RpcRaiseException(RPC_X_BAD_STUB_DATA);
                }
            }
        RpcExcept( RPC_BAD_STUB_DATA_EXCEPTION_FILTER )
            {
            RpcRaiseException(RPC_X_BAD_STUB_DATA);
            }
        RpcEndExcept
        lSizeOut = &_M94;
        DataOut = &_M95;
        _M95 = 0;
        
        RemRevisionCheckFile(
                        h1,
                        lSizeIn,
                        DataIn,
                        lSizeOut,
                        DataOut);
        
        _StubMsg.BufferLength = 4U + 8U;
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerBufferSize( (PMIDL_STUB_MESSAGE) &_StubMsg,
                              (unsigned char __RPC_FAR *)DataOut,
                              (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        _pRpcMessage->BufferLength = _StubMsg.BufferLength;
        
        _Status = I_RpcGetBuffer( _pRpcMessage ); 
        if ( _Status )
            RpcRaiseException( _Status );
        
        _StubMsg.Buffer = (unsigned char __RPC_FAR *) _pRpcMessage->Buffer;
        
        *(( long __RPC_FAR * )_StubMsg.Buffer)++ = *lSizeOut;
        
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerMarshall( (PMIDL_STUB_MESSAGE)& _StubMsg,
                            (unsigned char __RPC_FAR *)DataOut,
                            (PFORMAT_STRING) &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcFinally
        {
        _StubMsg.MaxCount = lSizeOut ? *lSizeOut : 0;
        
        NdrPointerFree( &_StubMsg,
                        (unsigned char __RPC_FAR *)DataOut,
                        &__MIDL_TypeFormatString.Format[20] );
        
        }
    RpcEndFinally
    _pRpcMessage->BufferLength = 
        (unsigned int)((long)_StubMsg.Buffer - (long)_pRpcMessage->Buffer);
    
}


static const MIDL_STUB_DESC HWT_CRM_DEV_StubDesc = 
    {
    (void __RPC_FAR *)& HWT_CRM_DEV___RpcServerInterface,
    MIDL_user_allocate,
    MIDL_user_free,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x10001, /* Ndr library version */
    0,
    0x50100a4, /* MIDL Version 5.1.164 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    1,  /* Flags */
    0,  /* Reserved3 */
    0,  /* Reserved4 */
    0   /* Reserved5 */
    };

static RPC_DISPATCH_FUNCTION HWT_CRM_DEV_table[] =
    {
    HWT_CRM_DEV_AddRef,
    HWT_CRM_DEV_Release,
    HWT_CRM_DEV_RemDeviceFunction,
    HWT_CRM_DEV_RemUplinkFunction,
    HWT_CRM_DEV_RemDeviceAndUplinkFunction,
    HWT_CRM_DEV_RemLoadControllerLibrary,
    HWT_CRM_DEV_RemLoadDeviceLibrary,
    HWT_CRM_DEV_RemID_Device,
    HWT_CRM_DEV_RemControllerDLL_FileNames,
    HWT_CRM_DEV_RemDeviceDLL_FileName,
    HWT_CRM_DEV_RemVerifyCommonDeviceDllVersion,
    HWT_CRM_DEV_RemVerifyDeviceSpecificDllVersion,
    HWT_CRM_DEV_RemUpdateLocalDLL,
    HWT_CRM_DEV_RemFormattedVersionInfo,
    HWT_CRM_DEV_RemLoadFirmwareMap,
    HWT_CRM_DEV_RemDeviceModelName,
    HWT_CRM_DEV_RemCheckForFirmwarePatch,
    HWT_CRM_DEV_RemMenuPath,
    HWT_CRM_DEV_RemProgramCacheControl,
    HWT_CRM_DEV_RemSupportedFunctions,
    HWT_CRM_DEV_RemControllerDebugFunction,
    HWT_CRM_DEV_RemVerifyHwtDeviceCommonInterface,
    HWT_CRM_DEV_RemVerifyAppInterfaceVersions,
    HWT_CRM_DEV_RemControllerDirectAccessFunction,
    HWT_CRM_DEV_RemDllAndInterfaceVersionInfo,
    HWT_CRM_DEV_RemRevisionCheckFile,
    0
    };
RPC_DISPATCH_TABLE HWT_CRM_DEV_v1_0_DispatchTable = 
    {
    26,
    HWT_CRM_DEV_table
    };

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {
			0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  2 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/*  4 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */
/*  6 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0xf,		/* FC_IGNORE */
/*  8 */	0x4e,		/* FC_IN_PARAM_BASETYPE */
			0x8,		/* FC_LONG */
/* 10 */	
			0x4d,		/* FC_IN_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 12 */	NdrFcShort( 0x2 ),	/* Type Offset=2 */
/* 14 */	
			0x51,		/* FC_OUT_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 16 */	NdrFcShort( 0x10 ),	/* Type Offset=16 */
/* 18 */	
			0x51,		/* FC_OUT_PARAM */
#ifndef _ALPHA_
			0x1,		/* x86, MIPS & PPC Stack size = 1 */
#else
			0x2,		/* Alpha Stack size = 2 */
#endif
/* 20 */	NdrFcShort( 0x14 ),	/* Type Offset=20 */
/* 22 */	0x5b,		/* FC_END */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x0,	/* FC_RP */
/*  4 */	NdrFcShort( 0x2 ),	/* Offset= 2 (6) */
/*  6 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/*  8 */	NdrFcShort( 0x1 ),	/* 1 */
/* 10 */	0x28,		/* Corr desc:  parameter, FC_LONG */
			0x0,		/*  */
#ifndef _ALPHA_
/* 12 */	NdrFcShort( 0x4 ),	/* x86, MIPS, PPC Stack size/offset = 4 */
#else
			NdrFcShort( 0x8 ),	/* Alpha Stack size/offset = 8 */
#endif
/* 14 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */
/* 16 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 18 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 20 */	
			0x11, 0x14,	/* FC_RP [alloced_on_stack] */
/* 22 */	NdrFcShort( 0x2 ),	/* Offset= 2 (24) */
/* 24 */	
			0x12, 0x0,	/* FC_UP */
/* 26 */	NdrFcShort( 0x2 ),	/* Offset= 2 (28) */
/* 28 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 30 */	NdrFcShort( 0x1 ),	/* 1 */
/* 32 */	0x28,		/* Corr desc:  parameter, FC_LONG */
			0x54,		/* FC_DEREFERENCE */
#ifndef _ALPHA_
/* 34 */	NdrFcShort( 0xc ),	/* x86, MIPS, PPC Stack size/offset = 12 */
#else
			NdrFcShort( 0x18 ),	/* Alpha Stack size/offset = 24 */
#endif
/* 36 */	0x2,		/* FC_CHAR */
			0x5b,		/* FC_END */

			0x0
        }
    };
