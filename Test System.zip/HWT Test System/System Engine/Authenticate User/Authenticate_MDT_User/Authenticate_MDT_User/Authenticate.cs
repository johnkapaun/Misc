﻿using System;
//using System.Text;
using System.DirectoryServices;

namespace Authenticate_MDT_User
{
    public class Authenticate
    {
        //
        public bool IsAuthenticated(string username, string pwd)
        {
            string domainAndUsername = "ENT\\" + username;
            DirectoryEntry entry = new DirectoryEntry(null, domainAndUsername, pwd);
            try
            {
                //Bind to the native AdsObject to force authentication.
                object obj = entry.NativeObject;
                //
                DirectorySearcher search = new DirectorySearcher(entry);
                //
                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                //
                if (result == null)
                    return false;
                //                
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
