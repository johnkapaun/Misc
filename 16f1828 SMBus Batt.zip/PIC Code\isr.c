/*******************************************************************************
* Copyright (C) 2014 -2015 John Kapaun  All rights reserved.                   *
*******************************************************************************/

/*******************************************************************************
*
*   file: isr.c
*   revision: 1.0
*   date: 1/19/15 9:58p
*
*-------------------------------------------------------------------------------
*
* Description:
*
* This is the interrupt service routine (isr). There are only two
* interrupts that will be serviced.  The first is a recieve from
* the SMBus.  The other occurs during a recieve from a PC.  It is
* important to keep these short but because RCIF can be called
* to do set up prior to testing starting, I went ahead and placed
* all the code here but made sure establishing responses on the
* SMBus would still execute as quickly as possible. 
*
*******************************************************************************/

#include <pic.h>
#include <htc.h>
#include "globals.h";
#include "delay.h";

	volatile char RX_Index = 0;		// Receiver 'rxfifo' index
	volatile char RX_Size = 0;		// Receiver number of chars in message (first char in every receive)
	volatile unsigned char rxfifo[31]; 	// Receive Buffer. Size = Primary_Data array size + 1
										// If the array being downloaded contains 26 values,
										// the first value [0] will contain 'P' or 'S' to
										// show if the primary or secondary data is being
										// updated in RAM. MWM 25Jun2015 change from 26 to 31
	
	volatile unsigned char Test_Mode = 0x00;	// 0x00 = Normal 0x01 = Use Primary and Secondary Data
 	unsigned char status = 0x00;				// Instrument Error and Status (see globals.h for details)

	unsigned char SMBus_State = 0x00;	// SMBus SSPSTAT status flag
	volatile char ResponseType = 'N';	// Primary or Secondary Data Response Type
	int ResponseStartIndex = 0x00;		// DataArray Start Index 
	int ResponseLength = 0x03;			// DataArray Start Index (isr.c)
	int SecondaryIndex = 0;
	unsigned char tmp_Current_Secondary = 0;
	unsigned char tmp_Set_Secondary = 0;
	unsigned char last_value = 0x00;

	unsigned char Non_Event_Cnt = 0x00;	// Non Event will occur before Error 
	unsigned char Err_Event_Cnt = 0x00;	// Error Event Count

	unsigned char TWI_Bus_Error_cnt = 0x00;			// TWI_Bus_Error current count
	unsigned char Lost_Bus_Arbitration_cnt = 0x00;	// Lost_Bus_Arbitration current count
	unsigned char SCL_Stretch_cnt = 0x00;	// SCL Stretch current count
	unsigned char Address_NACK_cnt = 0x00;	// Address NACK current count
	unsigned char Data_NACK_cnt = 0x00;		// Data NACK current count

	int CutOutCnt=0; //Count of Battery cut outs

	// The Event Types are as follows:
	// 	0bXXXX  XXX1: TWI_Bus_Error
	// 	0bXXXX  XX1X: Lost_Bus_Arbitration
	// 	0bXXXX  X1XX: SCL Stretch
	//	0bXXXX  1XXX: Address NACK
	//	0bXXX1  XXXX: Data NACK
	unsigned char Event_Type = 0x00;
	unsigned char current_Event_Type = 0x00;// Tracks Non(1s) and Error Event(0s)

	// Index controls for different items
	int i = 0;
	int x = 0;
	int y = 0;
	unsigned char Temp;				// Hold SMBus Data
	unsigned char LastTemp = 0xFF;	// Hold Previous Value
	unsigned char tmr_cnt=0;		// Hold tmr interupt number

	extern int ADC_Offset;	// Read from EEPROM when initialized or mode4 changes

void interrupt isr(void)
{
// The I2C/SMBus code below checks for 5 states:
//
// State 1: I2C write operation, last byte was an address byte.
//	 	SSPSTAT bits: S = 1, D_A = 0, R_W = 0, BF = 1
// State 2: I2C write operation, last byte was a data byte.
//		SSPSTAT bits: S = 1, D_A = 1, R_W = 0, BF = 1
// State 3: I2C read operation, last byte was an address byte.
//		SSPSTAT bits: S = 1, D_A = 0, R_W = 1, BF = 0
// State 4: I2C read operation, last byte was a data byte.
//		SSPSTAT bits: S = 1, D_A = 1, R_W = 1, BF = 0
// State 5: Slave NACK from master.
//		SSPSTAT bits: S = 1, D_A = 1, R_W = 0, BF = 0
//
// When a command is detected and Test_Mode is enabled,
// The command recieved, SMBus_State, and status will be uplinked
// to the PC.  A response will not occur until Have_Response = 0x01.
// If the Test mode isn't enabled, response will always be from the
// Primary Data Array.
//
//  The SMBus_State was tested and shows the it cycles as follows:
//	0x2C, 0x0D (RSTOC request/State is also 0D), 0x29, 0x09
//
	// This is the RX Interrupt (from PC to this unit)
	if(RCIF)
	{	
		// If an error occured, reset to clear it
		if(OERR) 
		{
			CREN = 0;
			CREN = 1;
		}
		// The first value received will contain the number
		// of chars in the message
		if( RX_Index == 0)
			RX_Size = (int)RCREG;
		
		SSP1IF = 0; //??? Clear flag
		PIE1 = 0b00100000;//??? Clear SMBus ISR

		// Capture the rest of the Chars in the message and
		// place them in the rxfifo buffer. This functionality
		// is required when Command_Lookup, AIC, Primary_Data, 
		// and Secondary_Data arrays are being updated by a
		// PC (see globals.h)
		if(RX_Index > 0 && RX_Index <= RX_Size)
		{
			if (RX_Index<31)	//??? check max rxfifo size
				rxfifo[RX_Index-1] = RCREG;
			else
				rxfifo[30] = RCREG;
		}
			
		RX_Index++;
		
		// If we got all the chars, reset the index for the next
		// RX Interrupt and execute the command we received. The
		// order this code executes matters and needs to be prioritized
		// to eleminate unneccissary RAM can still be done this way
		// because they are expected to occur before testing begins.	
		if(RX_Index > RX_Size)
		{
			if(RX_Size == 1)	// Send Primary or Secondary Data
			{ 
				if(rxfifo[0] == 'E')	// Read Status.  This will also clear it
				{
					txfifo[0] = 0x04;	//??? Cause SendData to execute
					txfifo[3] = status;		// System Error and Status Byte
									
					status &= 0b11101110;				// Clear RX Size 1 Command unKnown Error
					if((status & 0b00100000) != 0x20) 	// If TXREG wasn't busy
						status &= 0b10000000;			// Clear Everything including test mode
//						status &= 0b11000000;			// Clear Everything but test mode
				}
				else
					status |= 0b00010001;	// Set RX Size 1 Command unKnown Error
			}
			else if(RX_Size == 2) 			// Enable or disable Test_Mode
			{
				if(rxfifo[0] == 'T')
				{
					if(rxfifo[1] == 0)	// Normal
					{
						Test_Mode = 0x00;
						Event_Type = 0;		// Clear
						
					// Set back to Slave Mode

//???					SSP1CON1 = 0b00100110;
						SSP1CON1 = 0b00110110;	// CKP=1
						SSP1ADD = 0b00010110;
						SEN = 1;	//??? Set SEN(b0) to enable clock stretching in SLAVE Receive Mode.
									// Clock stretching is automatic for SLAVE transmit mode.
									// Placed here after Slave mode is set up.

						RA5 = 0;	// Switch MUX to Controller

						ResponseType = 'P'; 	// The response type will always be Primary Data Array
						status &= 0b00101001;	// Set Test_Mode Bits and Clear
												// RX Size 2 Command unKnown Error

						// Reset the interrupts and clear the flags
						INTCON = 0b11100000;// GIE PEIE TMR0IE INTE IOCIE TMR0IF INTF IOCIF
						PIE1 = 0b00101000;	// TMR1GIE ADIE RCIE TXIE SSP1IE CCP1IE TMR2IE TMR1IE
						PIR1 = 0b00000000;	// TMR1GIF ADIF RCIF TXIF SSP1IF CCP1IF TMR2IF TMR1IF (clear Flags)

					}
					else if(rxfifo[1] == 0x01)	// Test_Mode Enabled
					{
						Test_Mode = 0x01;
						status &= 0b0000001;	// Clear Test_Mode Bits and Clear
												// RX Size 2 Command unKnown Error
						status |= 0b01000000;	// Set Test_Mode Enabled
					}
					else if(rxfifo[1] == 0x02)	// ADC_Offset Trim Enabled
					{
						Test_Mode = 0x02;
						SSP1IF = 0;        		// Clear flag
						status &= 0b00101001;	// Clear Test_Mode Bits and Clear
												// RX Size 2 Command unKnown Error
						status |= 0b10000000;	// Set ADC offset Trim Enabled
					}
					else
					{
						status |= 0b00010110;	// Set Test_Mode Select Error and
												// RX Size 2 Command unKnown Error
					}
				}
				else						
					status |= 0b00010010;	// Set RX Size 2 Command unKnown Error	
			}
			else if(RX_Size == 4) 			// Bus Error Settings
			{
				if(rxfifo[0] == 'B')
				{	
					Non_Event_Cnt = rxfifo[2];	// Non Event will occur before Error 
					Err_Event_Cnt = rxfifo[3];	// Error Event Count
					
					// If either value is >0 then a test mode is required
					if( (Non_Event_Cnt != 0) || (Err_Event_Cnt != 0))	
					{
//???						ACKDT = 1; 			// NACK (ISR will change based on test)
						
						Test_Mode = 0x01;
						status &= 0b0000001;	// Clear Test_Mode Bits and Clear
												// RX Size 2 Command unKnown Error
						status |= 0b01000000;	// Set Test_Mode Enabled
					}
					else
					{
//???						ACKDT = 0;	// Enable ACK but don't clear Test_Mode
						Event_Type = 0;
					}

					// Always start with Non_Event_Cnt
					TWI_Bus_Error_cnt = Non_Event_Cnt;			// TWI_Bus_Error current count
					Lost_Bus_Arbitration_cnt = Non_Event_Cnt;	// Lost_Bus_Arbitration current count
					SCL_Stretch_cnt = Non_Event_Cnt;	// SCL Stretch current count
					Address_NACK_cnt = Non_Event_Cnt;	// Address NACK current count
					Data_NACK_cnt = Non_Event_Cnt;		// Data NACK current count

					// The Event Types are as follows:
					// 	0bXXXX  XXX1: TWI_Bus_Error
					// 	0bXXXX  XX1X: Lost_Bus_Arbitration
					// 	0bXXXX  X1XX: SCL Stretch
					//	0bXXXX  1XXX: Address NACK
					//	0bXXX1  XXXX: Data NACK
					Event_Type = rxfifo[1];
					current_Event_Type = Event_Type;	// Tracks Non(1s) and Error Event(0s)

				//	status |= 0b01000000;				// Set Test_Mode Enabled

				}
			}
			else if(RX_Size == 7 && rxfifo[0] == 'C') // Update Command_Lookup
			{
				for( RX_Index = 0; RX_Index < RX_Size - 1; RX_Index++)
				{
					Command_Lookup[RX_Index] = rxfifo[RX_Index+1];
				}
				status &= 0b11101111;	// Clear RX Command Recieved Error
			
			}
			else if(RX_Size == 7 && rxfifo[0] == 'V') // Update Secondary Use
			{	
				for( RX_Index = 0; RX_Index < RX_Size - 1; RX_Index++)
				{
					Current_Secondary[RX_Index] = rxfifo[RX_Index+1];
					Set_Secondary[RX_Index] = rxfifo[RX_Index+1];
				}
				status &= 0b11101111;	// Clear RX Command Recieved Error
			
			}
			else if(RX_Size == 13 && rxfifo[0] == 'A') // Update AIC
			{
				for( RX_Index = 0; RX_Index < RX_Size - 1; RX_Index++)
				{
					AIC[RX_Index] = rxfifo[RX_Index+1];
				}
				status &= 0b11101111;	// Clear RX Command Recieved Error
			
			}
			else if(RX_Size == 26) // Update Primary or Secondary Data
			{
				if(  rxfifo[0] == 'P')	// Update Primary Data
				{
					
					for( RX_Index = 0; RX_Index < RX_Size - 1; RX_Index++)
					{
						Primary_Data[RX_Index] = rxfifo[RX_Index+1]; // Skip 1st value
					}
					status &= 0b11100111;	// Clear Primary or Secondary RAM Select Error
				
				}
				else if(  rxfifo[0] == 'S')	// Update Secondary Data
				{
					for( RX_Index = 0; RX_Index < RX_Size - 1; RX_Index++)
					{
						Secondary_Data[RX_Index] = rxfifo[RX_Index+1]; // Skip 1st value
					}
					status &= 0b11100111;	// Clear Primary or Secondary RAM Select Error
				
				}
				else
					status |= 0b00011000;	// Set Primary or Secondary RAM Select Error
											// Set RX Command Recieved Error
			}
			else if(RX_Size == 31) // Controller simulation mode
			{

				Test_Mode = 0x04;
				if(  rxfifo[0] == 'W')	// Write data to Battery
				{

					RA5 = 1;			//Mux Switch PIC to Battery
					SSP1CON1 = 0b00111000; // Switch to Master
					SSP1ADD = 0x4F; // 100KHZ
					SSP1IF=0;
					RCEN=0;
					SEN=1;

					WaitForSSP1IF();
					SSP1IF=0;
					SSP1BUF = 0b00010110;

					WaitForSSP1IF();
					for( RX_Index = 0; RX_Index < rxfifo[1]; RX_Index++)
					{
						SSP1IF=0;
						SSP1BUF = rxfifo[RX_Index+2]; // Skip 1st 2 values

						WaitForSSP1IF();
					}
			  		SSP1IF=0;
					PEN=1;

					WaitForSSP1IF();
			  		SSP1IF=0;

					status &= 0b11100111;	// Clear Primary or Secondary RAM Select Error
				}
				else
					status |= 0b00011000;	// Set Primary or Secondary RAM Select Error
											// Set RX Command Recieved Error
			}
			else
				status |= 0b00010000;	// Set RX Command Recieved Error

			RX_Index = 0;		// Reset index to 0
			DelayMs(1);			//???
			ACKDT=0;
			CKP=1;
			PIE1 = 0b00101000; //??? Enable SMBus ISR
		}
	}
	else if(SSP1IF) // If SMBus caused the interruupt
	{
//	RC5=0;
//	for(x = 0; x < 12; x++) RC5=1;	// PIC Pin 5 Scope 104.9uS trigger
//	RC5=0;
			WaitForACKTIM();
			ACKDT=0;
//??? 		 	CKP = 0;     			// SEN1 set holds clock low except when SP xfer is NAK'd
			SMBus_State = (SSP1STAT & 0b00101101);	// Read the status register and mask with D_A , S , R_W , BF
			Temp = SSP1BUF; 		//read out address/data

			txfifo[0] = 0x00; 		// ???Send data reg
			txfifo[1] = Temp; 		// first byte = Data or Address
									// or if Test_Mode=4 then CutOutCnt MSB
			txfifo[2] =	SMBus_State;// The SMBus State
									// or if Test_Mode=4 then CutOutCnt LSB
			txfifo[3] = status;		// System Error and Status Byte
//???			txfifo[4] = 0xff;		// Instrument Respond Type Invalid
//			txfifo[5] = Current_Secondary[SecondaryIndex];
//			txfifo[6] = RSOC;		// Uplink Value
//			txfifo[7] = ADC_MSB;	// Uplink Value
//			txfifo[8] = ADC_LSB;	// Uplink Value
			txfifo[9] = 0xA5;		// provides a sink value
			txfifo[10] = 0xA5;		// provides a sink value


			if (SMBus_State == 0b00101001 || SMBus_State == 0b00101100 || SMBus_State == 0b00101000) 	// 29 2C - State 2: SSPSTAT bits: D_A=1, S=1, R_W=0, BF=1
		 		{            																			// Read the data  (Buffer Write Byte)
																										// Tested (Catches command and does lookup)
																										// MWM 1) Last Byte Recv'd was READ/WRITE DATA,
																										// D_A=1, S=1, (R_W=1, BF=0)/(R_W=0, BF=1/0)
					txfifo[4] = 0xff;	// Set default value
	
//	RC5=0;
//	for(x = 0; x < 4; x++) RC5=1;	// PIC Pin 5 Scope 9.9uS trigger
//	for(x = 0; x < 42; x++) RC5=1;	// PIC Pin 5 Scope 104.9uS trigger
//	RC5=0;
					if(Test_Mode == 0x01)
					{
						if((( Event_Type & 0x10) == 0x10)) // Check for Data_NACK (Data with write)&& ((Temp == 0x00) || (Temp == 0x0D))
						{
							if((current_Event_Type & 0x10) != 0x10)	// Error Event
							{
								ACKDT = 1; 			// NACK
								txfifo[4] = 0x10;
							}
							Data_NACK_cnt--; 	// Decrement Current count
							
							if(Data_NACK_cnt == 0)
							{
								if((current_Event_Type & 0x10) != 0x10) // Was Error Event
								{
									Data_NACK_cnt = Non_Event_Cnt; 	  // Next is Non-Event
									current_Event_Type |= 0b00010000; // Set for Non-Event
								}
								else
								{
									Data_NACK_cnt = Err_Event_Cnt; 	  // Next is Error-Event
									current_Event_Type &= 0b11101111; // Clear for Error-Event
								}
							}
						}
						else if((( Event_Type & 0x01) == 0x01) && (Temp == 0x1F)) // Check for Bus Error (Data with write)
						{														  // This is done during SAW setup
							if((current_Event_Type & 0x01) != 0x01)	// Error Event
							{
								ACKDT = 0;	// ACK
								CKP = 1;	// Free Clock
								SSP1CON1 = 0b00100010; // Switch to Master
								DelayMs(1);	// 1 mSec
								SEN = 1;	// Do a start
								DelayMs(10);// 10 mSec
								SSP1CON1 = 0b00100110; // Return to Slave
								txfifo[4] = 0x01;
							}
						
							TWI_Bus_Error_cnt--; 	// Decrement Current count
							
							if(TWI_Bus_Error_cnt == 0)
							{
								if((current_Event_Type & 0x01) != 0x01) // Was Error Event
								{	
									TWI_Bus_Error_cnt = Non_Event_Cnt;// Next is Non-Event
									current_Event_Type |= 0b00000001; // Set for Non-Event
								}
								else
								{
									TWI_Bus_Error_cnt = Err_Event_Cnt;// Next is Error-Event
									current_Event_Type &= 0b11111110; // Clear for Error-Event
								}
							}
						}
						else if((( Event_Type & 0x02) == 0x02) && (Temp == 0x00) && (LastTemp == 0x50))
						{														  						  
							// Check for Lost_Bus_Arbitration
							// This will run during the SAW Setup.  It will look at the Controller command
							// for a 0x50 followed by 0x00.  If found, SDA will be forced low.  This will 
							// result in the 0x1F command of the setup to become 0x00.
							if((current_Event_Type & 0x02) != 0x02)	// Error Event
							{
								ACKDT = 0;		// ACK the 0x00
								CKP = 1;	 	// Free Clock

								SSP1CON1 = 0x00;// Allow Bus to be normal IO
								TRISB4 = 0;		// Set Pin to Output
								RB4 = 0;		// Set Pin to 0
							
								DelayUs(113);	// Overwrite 0x1F
						
								TRISB4 = 1;				// Turn pin back to Input
								SSP1CON1 = 0b00100110;	// Turn Back to BUS
								
								txfifo[4] = 0x02;		
							}
						
							Lost_Bus_Arbitration_cnt--; 	// Decrement Current count
							
							if(Lost_Bus_Arbitration_cnt == 0)
							{
								if((current_Event_Type & 0x02) != 0x02) // Was Error Event
								{
									Lost_Bus_Arbitration_cnt = Non_Event_Cnt;	// Next is Non-Event
									current_Event_Type |= 0b00000010; 			// Set for Non-Event
								}
								else
								{
									Lost_Bus_Arbitration_cnt = Err_Event_Cnt;	// Next is Error-Event
									current_Event_Type &= 0b11111101; 			// Clear for Error-Event
								}
							}
						}
					}
					// Now look up the index and size/length of data for the response
					// Index 7 = Index 0 and is used to capture commands not found
					for(x = 0; x < 7; x++)
					{
						if( Temp == Command_Lookup[x])
						{
							if(Temp == 0x0D)	// This is RSOC
							{
								ResponseStartIndex = 0; //RSOC always first 3 bytes
								ResponseLength = 3;
								SecondaryIndex = 0;

								if((Current_Secondary[0] != 0) && (Test_Mode == 0x01))
								{
									ResponseType = 'S';
								}
								else
								{
									ResponseType = 'P';
								}
							}
							else
							{
								ResponseStartIndex = AIC[x*2];	// Index of the start or response
								ResponseLength = AIC[(x*2)+1];	// Length of response
								SecondaryIndex = x;

								if( (Current_Secondary[x] != 0) && (Test_Mode == 0x01))
									ResponseType = 'S';
								else
									ResponseType = 'P';
							}
						last_value = Temp;		// Store this for Slave Transmit uplink
						}
					}
					// Capture secondary count	
					txfifo[5] = Current_Secondary[SecondaryIndex];
				
					CKP=1;		// Release clock for ACKDT
					SendData();			// Uplink Data
					SSP1IF = 0;        	// Clear flag
				 	if (ACKDT != 1)
						CKP = 1;		// Enable CLK for next byte
				}
				else if (SMBus_State == 0b00001101) // 0D SSPSTAT bits: D_A=1, S=1, R_W=0, BF=1
		  		{             						// This was tested (Sends Data such RSOC)
													// MWM 2) Last Byte Recv'd was READ ADDRESS,
													// D_A=0, S=1, R_W=1, BF=1

//	RC5=0;	
//	for(x = 0; x < 21; x++) RC5=1;	// PIC Pin 5 Scope 52.4 uS trigger
//	for(x = 0; x < 42; x++) RC5=1; // PIC Pin 5 Scope 104.9uS trigger
//	RC5=0;
					CKP=1;		// Release clock for ACKDT
					y = ResponseStartIndex + ResponseLength; // Index of End of Data
				
					if(ResponseStartIndex == 0)
						txfifo[6] = Primary_Data[0];//	This is RSOC			

					if(ResponseType == 'P')	// Send Primary_Data
					{
						for(x = ResponseStartIndex; x < y; x++)
						{
							SSP1IF = 0;					//??? Clear Flag (used to send data)
							SSP1BUF = Primary_Data[x];	// Load Value
							if(Test_Mode == 0x01)  		// Check for SCL_Stretch
							{
								if((Event_Type & 0x04) == 0x04)
								{
									if((current_Event_Type & 0x04) != 0x04)	// Error Event
									{
										// CKP (the clock) is already being held low so
										// all we need to do is stay here until a time
										// out occurs.  CKP will be released at the end
										// of this ISR.
										DelayMs(100);		// 200 mSec min
										txfifo[4] = 0x04;	// SCL_Stretch
									}

									SCL_Stretch_cnt--; // Decrement Current count

									if(SCL_Stretch_cnt == 0)
									{
										if((current_Event_Type & 0x04) != 0x04) // Was Error Event
										{
											SCL_Stretch_cnt = Non_Event_Cnt; // Next is Non-Event
											current_Event_Type |= 0b00000100;// Set for Non-Event
										}
										else
										{
											SCL_Stretch_cnt = Err_Event_Cnt; // Next is Error-Event
											current_Event_Type &= 0b11111011;// Clear for Error-Event
										}
									}
								}
							}

							CKP = 1;
							WaitForSSP1IF();
							CKP = 0;
						}
//						CKP = 0;	// PEC byte, even with SEN1 set the PIC will not hold the Clock
									// low because this byte was NACK'd.
					}

					else if(ResponseType == 'S')// Send Secondary_Data
					{
						for(x = ResponseStartIndex; x < y; x++)
						{
							SSP1IF = 0;					//??? Clear Flag (used to send data)
							SSP1BUF = Secondary_Data[x];// Load Value
							if(Test_Mode == 0x01)  // Check for SCL_Stretch
							{
								if((Event_Type & 0x04) == 0x04)
								{
									if((current_Event_Type & 0x04) != 0x04)	// Error Event
									{
										// CKP (the clock) is already being held low so
										// all we need to do is stay here until a time
										// out occurs.  CKP will be released at the end
										// of this ISR.
										DelayMs(255);		// 200 mSec min
										txfifo[4] = 0x04;	// SCL_Stretch
									}
									SCL_Stretch_cnt--; // Decrement Current count
								
									if(SCL_Stretch_cnt == 0)
									{
										if((current_Event_Type & 0x04) != 0x04) // Was Error Event
										{
											SCL_Stretch_cnt = Non_Event_Cnt; // Next is Non-Event
											current_Event_Type |= 0b00000100;// Set for Non-Event
										}
										else
										{
											SCL_Stretch_cnt = Err_Event_Cnt; // Next is Error-Event
											current_Event_Type &= 0b11111011;// Clear for Error-Event
										}
									}
								}
							}
							CKP = 1;
							WaitForSSP1IF();
						}
//						CKP = 0;	// PEC byte, even with SEN1 set the PIC will not hold the Clock
									// low because this byte was NACK'd.
					}
					else
			 			ResponseType = 'N';	// Don't Respond
											// The next SMBus Status = 0x2C

					// See if we need to update data.
					if(Test_Mode == 0x01)
					{
						txfifo[1] = last_value;	//???
						tmp_Current_Secondary = Current_Secondary[SecondaryIndex];
						tmp_Set_Secondary = Set_Secondary[SecondaryIndex];

						if((tmp_Set_Secondary > 0x00) && (SecondaryIndex != 0x07))
						{
							if( tmp_Current_Secondary != 0x00)
							{
								Current_Secondary[SecondaryIndex] = (tmp_Current_Secondary - 1);
							}
							else
								Current_Secondary[SecondaryIndex] = tmp_Set_Secondary;
						}
					}


					if(BF)
						Temp = SSP1BUF; 	//read out to clear NAK
					
					if(txfifo[4] == 0xff)	// Don't overwrite Error Events
					{
						txfifo[4] = ResponseType;
					}


					SendData();			// Uplink Data

					ResponseType = 'N';		// Clear Response knowledge (Buffer Read Address)
					SecondaryIndex = 7; 	// Set it to and invalid Index
//					CKP=1;	//??? release clock for PEC transmission, BF automatically cleared
					SSP1IF = 0;        	// Clear flag
				 	if (ACKDT != 1)
						CKP = 1;		// Enable CLK for next byte
		  		}
			else if (SMBus_State == 0b00001001 || SMBus_State == 0b00001000) 	// 09 State 1:SSPSTAT bits: D_A=0, S=1, R_W=0, BF=1
		 		{            													// Address bit with write operation 
																				// MWM 3) Last Byte Recv'd was WRITE ADDRESS,
																				// D_A=0, S=1, R_W=0, BF=1/0
//	RC5=0;
//if (SMBus_State == 0b00001001)	for(x = 0; x < 12; x++) RC5=1;	// PIC Pin 5 Scope 104.9uS trigger
//if (SMBus_State == 0b00001000)	for(x = 0; x < 48; x++) RC5=1;	// PIC Pin 5 Scope 104.9uS trigger
//	RC5=0;
			WaitForACKTIM();
//	RC5=0;
//	for(x = 0; x < 42; x++) RC5=1;	// PIC Pin 5 Scope 104.9uS trigger
//	RC5=0;

					// See if we need to update data.
					if((Test_Mode == 0x01) && ((Event_Type & 0x08) == 0x08))
					{
						txfifo[5] = 0x00;	// Clear Current_Secondary[SecondaryIndex]
					
						if((current_Event_Type & 0x08) != 0x08)	// Error Event
						{
							ACKDT = 1; 		// NACK
							txfifo[4] = 0x08;
					    }
						else
						{
							txfifo[4] = 0x00;	// Handshake	
						}
						
						Address_NACK_cnt--; // Decrement Current count
							
						if(Address_NACK_cnt == 0)
						{
							if((current_Event_Type & 0x08) != 0x08) // Was Error Event
							{
								Address_NACK_cnt = Non_Event_Cnt; // Next is Non-Event
								current_Event_Type |= 0b00001000; // Set for Non-Event
							}
							else
							{
								Address_NACK_cnt = Err_Event_Cnt; // Next is Error-Event
								current_Event_Type &= 0b11110111; // Clear for Error-Event
							}
						}
					}
					else	// If not test mode
					{
						txfifo[4] = 0x00; 	// This was a handshake	
						txfifo[5] = 0x00;	// Clear Current_Secondary[SecondaryIndex]
					}

					CKP=1;		// Release clock for ACKDT
					WaitForACKTIMnot();
				 	if (ACKDT != 1)
						CKP=0;
					SendData();			// Uplink Data
//					CKP=1;		// Release clock for ACKDT
//					WaitForACKTIMnot();
					SSP1IF = 0;        	// Clear flag
				 	if (ACKDT != 1)
						CKP = 1;		// Enable CLK for next byte
		  		}
			else  	// Catch Unkown State
		  		{   // Tested by commenting out a state used.
//	RC5=0;	// PIC Pin 5 Scope 104.9uS trigger
//	for(x = 0; x < 42; x++) RC5=1;
//	RC5=0;
					// See if we need to update data.
					if(Test_Mode == 0x01)
					{
						txfifo[3] =	status | 0b11000000;// System Error and Status Byte
														// Uplink as an ERROR but don't
														// write to the status register
						txfifo[4] = 0xC0;				// Indicate Error
						txfifo[5] = 0x00;								
					}
		  		}
//???			x = SSP1BUF; 	//?? Read out to clear NAK
			SSPOV = 0;			//??? Clear overflow bit
//???			SSP1IF = 0;        	// Clear flag
//???		 	CKP = 1;           	// Enable CLK
			LastTemp = Temp;	// Update Last Read Value
	}

	else if(C1IF)
	{
		C1IF=0;
		y=1;
		for(x = 0; x < 7; x++)
		{
			if (!C1OUT) y=0;	//??? Average out 57kHz from ADC
		}
		if (y)
			CutOutCnt++;
	}
	else if(TMR0IF)
	{
		TMR0IF=0;

		tmr_cnt++;
		if (tmr_cnt>99)	// 100*6ms
		{
			SMBusTimeOut++;
			tmr_cnt=0;
			if (Test_Mode & 0x06)	// Test modes 4 or 2
				txfifo[0] = 0x02;
		}
	}
	else
		return;
}// End isr