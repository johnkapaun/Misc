
#include <StdAfx.h>
#include "Interface.h"
#include "main.h"
#include "external\Tversion.h"	// Note: if no longer needed remove version.lib from Library Modules list
#include "IndirectCall.h"
#include "ResourceLocks.h"

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

static TString GenericDeviceName;

//////////////////////////////////////////////////////////////////////////////////////

void RemDeviceFunction(	handle_t		h1,								// [in]
						long			lSizeIn,						// [in]
						unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
						long			__RPC_FAR *lSizeOut,			// [out]
						unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	ErrorCluster Err;
	unFlattenData Input(DataIn, lSizeIn);
	FlattenData Output(DataOut, lSizeOut);
	IndirectFunctionCallStack Indirect;

	DeviceResourceLock Lock( &Err );

	Indirect.FunctionCall( &Err, &Input, &Output );
}

void RemUplinkFunction(	handle_t		h1,								// [in]
						long			lSizeIn,						// [in]
						unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
						long			__RPC_FAR *lSizeOut,			// [out]
						unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	ErrorCluster Err;
	unFlattenData Input(DataIn, lSizeIn);
	FlattenData Output(DataOut, lSizeOut);
	IndirectFunctionCallStack Indirect;

	UplinkResourceLock Lock( &Err );

	Indirect.FunctionCall( &Err, &Input, &Output );
}

void RemDeviceAndUplinkFunction(	handle_t		h1,								// [in]
									long			lSizeIn,						// [in]
									unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
									long			__RPC_FAR *lSizeOut,			// [out]
									unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	ErrorCluster Err;
	unFlattenData Input(DataIn, lSizeIn);
	FlattenData Output(DataOut, lSizeOut);
	IndirectFunctionCallStack Indirect;

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	Indirect.FunctionCall( &Err, &Input, &Output );
}

//////////////////////////////////////////////////////////////////////////////////////

void RemControllerDebugFunction(	handle_t		h1,								// [in]
									long			lSizeIn,						// [in]
									unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
									long			__RPC_FAR *lSizeOut,			// [out]
									unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	ErrorCluster Err;
	unFlattenData Input(DataIn, lSizeIn);
	FlattenData Output(DataOut, lSizeOut);
	IndirectFunctionCallStack Indirect;

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	Indirect.DebugControllerFunctionCall( &Err, &Input, &Output );
}

void RemControllerDirectAccessFunction(	handle_t		h1,								// [in]
										long			lSizeIn,						// [in]
										unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
										long			__RPC_FAR *lSizeOut,			// [out]
										unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	ErrorCluster Err;
	unFlattenData Input(DataIn, lSizeIn);
	FlattenData Output(DataOut, lSizeOut);
	IndirectFunctionCallStack Indirect;

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	Indirect.DirectControllerObjectFunctionCall( &Err, &Input, &Output );
}

//////////////////////////////////////////////////////////////////////////////////////

void RemLoadControllerLibrary(	handle_t		h1,								// [in]
								long			lSizeIn,						// [in]
								unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
								long			__RPC_FAR *lSizeOut,			// [out]
								unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString LibName;
	TString ReturnStatus;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &LibName );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	if( !Err.Status() )
	{
		ReturnStatus = LoadControllerLibrary( &Err, LibName );

		// Eliminate the two different status formats.
		if( ReturnStatus.IsEmpty() == false && Err.Status() == false && Err.Code() < 5 )
		{
			ReturnStatus.Format("%d <%s> %s", Err.Code(), ControllerDLL_FileNames(false)[0].CStr(), ReturnStatus.CStr() );
			Err.SetWarning( 5, Err.Source() );	// Change Warning number to 5
		}

		GenericDeviceName = "";
	}

	UplinkLock.UnLock();
	DeviceLock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( ReturnStatus );
}

void RemLoadDeviceLibrary(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString LibName;
	TString DeviceName;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &LibName );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	if( !Err.Status() )
	{
		DeviceName = LoadDeviceLibrary( &Err, LibName );
		StateCache::CacheEnable(false);	// Disable Device State Cache
		StateCache::InvalidateAll();	// Invalidate all Cached values
		GenericDeviceName = DeviceName;
	}

	UplinkLock.UnLock();
	DeviceLock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( DeviceName );
}

//////////////////////////////////////////////////////////////////////////////////////

void RemID_Device(	handle_t		h1,								// [in]
					long			lSizeIn,						// [in]
					unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
					long			__RPC_FAR *lSizeOut,			// [out]
					unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString DllName;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock DeviceLock( &Err );
	UplinkResourceLock UplinkLock( &Err );

	if( !Err.Status() )
	{
		DllName = ID_Device( &Err );
	}

	UplinkLock.UnLock();
	DeviceLock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( DllName );
}

void RemControllerDLL_FileNames(	handle_t		h1,								// [in]
									long			lSizeIn,						// [in]
									unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
									long			__RPC_FAR *lSizeOut,			// [out]
									unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TStringArray FileNames;
	bool IncludePath = false;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &IncludePath );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	UplinkResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		FileNames = ControllerDLL_FileNames( IncludePath );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( FileNames );
}

void RemDeviceDLL_FileName(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString FileName;
	bool IncludePath = false;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &IncludePath );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	UplinkResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		FileName = DeviceDLL_FileName( IncludePath );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( FileName );
}

void RemVerifyHwtDeviceCommonInterface(	handle_t		h1,								// [in]
										long			lSizeIn,						// [in]
										unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
										long			__RPC_FAR *lSizeOut,			// [out]
										unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString VersionInfo;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	if( !Err.Status() )
	{
		VersionInfo = VerifyHwtDeviceCommonInterface( &Err );
	}

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( VersionInfo );
}

void RemVerifyAppInterfaceVersions(	handle_t		h1,								// [in]
									long			lSizeIn,						// [in]
									unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
									long			__RPC_FAR *lSizeOut,			// [out]
									unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString VersionInfo;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	if( !Err.Status() )
	{
		VersionInfo = VerifyAppInterfaceVersions( &Err );
	}

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( VersionInfo );
}

void RemVerifyCommonDeviceDllVersion(	handle_t		h1,								// [in]
										long			lSizeIn,						// [in]
										unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
										long			__RPC_FAR *lSizeOut,			// [out]
										unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString VersionInfo;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	// Function 'VerifyCommonDeviceDllVersion' is thread safe, a lock in not needed

	if( !Err.Status() )
	{
		VersionInfo = VerifyCommonDeviceDllVersion( &Err );
	}

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( VersionInfo );
}

void RemVerifyDeviceSpecificDllVersion(	handle_t		h1,								// [in]
										long			lSizeIn,						// [in]
										unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
										long			__RPC_FAR *lSizeOut,			// [out]
										unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString DllName;
	TString VersionInfo;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &DllName );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		VersionInfo = VerifyDeviceSpecificDllVersion( &Err, DllName );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( VersionInfo );
}

void RemUpdateLocalDLL(	handle_t		h1,								// [in]
						long			lSizeIn,						// [in]
						unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
						long			__RPC_FAR *lSizeOut,			// [out]
						unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString DllName;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &DllName );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		UpdateLocalDLL( &Err, DllName );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );

}

void RemFormattedVersionInfo(	handle_t		h1,								// [in]
								long			lSizeIn,						// [in]
								unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
								long			__RPC_FAR *lSizeOut,			// [out]
								unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString VersionInfo;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		FileVersionInfo CommonInterfaceInfo( CommonInterface_FileName(true) );

		VersionInfo = CommonInterfaceInfo.FormattedVersionInfo();

		if( InDebugMode )	// If running in 'Debug Mode', append information
		{
			VersionInfo.TrimRight();			// remove trailing newline
			VersionInfo += " (Debug Mode)\n";	// add (Debug Mode)\n
		}

		// Get List of all interfaces currently being used by all Clients
		TStringArray List = RefCount.InterfaceList( &Err );

		// Append Version Information for each interface
		for( int i = 0; i < List.GetSize(); i++ )
		{
			FileVersionInfo InterfaceInfo( List[i] );
			VersionInfo += InterfaceInfo.FormattedVersionInfo();
		}

		// Append Version Information for Device, Controller, and Common DLLs
		VersionInfo += FormattedVersionInfo( &Err );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( VersionInfo );
}

void RemLoadFirmwareMap(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	typedef void (*PFNDLL1)(ErrorCluster *, const TString &, const TString &, TString *); // DLL Function Prototype

	PFNDLL1 DLLFunct1 = NULL;	// Declare DLL Function Pointer
	ErrorCluster Err;
	TString Path;
	TString File;
	TString UsedFileName;
	TString MissingVariables;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &Path );
	Input.unFlatten( &File );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		AddressCache::InvalidateAll(&Err);	// invalidate all cached address

		// Lookup Address of DLL Function, and if found Execute
		if ((DLLFunct1 = (PFNDLL1) GetDeviceFunctionAddress(&Err,"LoadFirmwareMap")) != NULL)
			(DLLFunct1)(&Err, Path, File, &UsedFileName);

		AddressCache::UpdateAll(&Err);		// update all cached addresses
		MissingVariables = AddressCache::RetrieveFailureList(&Err);
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( UsedFileName );
	Output.Flatten( MissingVariables );
}

void RemDeviceModelName(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	typedef void (*PFNDLL1)(ErrorCluster *, TString *); // DLL Function Prototype

	PFNDLL1 DLLFunct1 = NULL;	// Declare DLL Function Pointer
	ErrorCluster Err;
	ErrorCluster Err2;
	TString DeviceModel = GenericDeviceName; // If Device DLL is loaded but the Function is NOT found,
											 // return Generic Device Name

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		if( DeviceDLL_FileName().IsEmpty() )
		{
			GenericDeviceName = DeviceModel = "";
			Err.SetError( 15, "Device DLL Not Loaded" );
		}
		// Lookup Address of DLL Function, and if found Execute, else don't set error (use dummy Err2)
		else if ((DLLFunct1 = (PFNDLL1) GetDeviceFunctionAddress(&Err2,"DeviceModelName")) != NULL)
			(DLLFunct1)(&Err, &DeviceModel);
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( DeviceModel );
}

void RemCheckForFirmwarePatch(	handle_t		h1,								// [in]
								long			lSizeIn,						// [in]
								unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
								long			__RPC_FAR *lSizeOut,			// [out]
								unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	typedef void (*PFNDLL1)(ErrorCluster *, TStringArray *, int32 *ReID_Code); // DLL Function Prototype

	PFNDLL1 DLLFunct1 = NULL;	// Declare DLL Function Pointer
	ErrorCluster Err;
	ErrorCluster Err2;
	TStringArray PatchVIs;
	int32 ReID_Code;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &ReID_Code );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		if( DeviceDLL_FileName().IsEmpty() )
			Err.SetError( 15, "Device DLL Not Loaded" );

		// Lookup Address of DLL Function, and if found Execute, else don't set error (use dummy Err2)
		else if ((DLLFunct1 = (PFNDLL1) GetDeviceFunctionAddress(&Err2,"CheckForFirmwarePatch")) != NULL)
			(DLLFunct1)(&Err, &PatchVIs, &ReID_Code);

		else	// If Device DLL is loaded but the Function is NOT found, set ReID_Count = 0
			ReID_Code = 0;
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( PatchVIs );
	Output.Flatten( ReID_Code );
}

void RemMenuPath(	handle_t		h1,								// [in]
					long			lSizeIn,						// [in]
					unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
					long			__RPC_FAR *lSizeOut,			// [out]
					unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString Path;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		Path = MenuPath( &Err );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( Path );
}

void RemProgramCacheControl(	handle_t		h1,								// [in]
								long			lSizeIn,						// [in]
								unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
								long			__RPC_FAR *lSizeOut,			// [out]
								unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	// New_Cache_State Values
	// 0 = Disable
	// 1 = Enable
	// 2 = Reset
	// 3 = No Change

	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString Cache;
	uInt16 New_Cache_State;
	uInt16 Prev_Cache_State = 3;
	bool CurrentState = false;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &Cache );
	Input.unFlatten( &New_Cache_State );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	DeviceResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		if( strcmp(Cache,"Device State") == 0 )	// Device State Cache
		{
			if(New_Cache_State < 2)
				CurrentState = StateCache::CacheEnable(New_Cache_State != 0);

			else if(New_Cache_State == 2)
			{
				StateCache::InvalidateAll();
				CurrentState = StateCache::CacheEnable();
			}
			else
				CurrentState = StateCache::CacheEnable();

			Prev_Cache_State = (CurrentState) ? 1 : 0;  //  Return previous state value
		}
		else	// Unknown
		{
			Err.SetError( -1, "Program Cache Control - Unsupported Option");
			Prev_Cache_State = 2;
		}
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( Prev_Cache_State );
}

///////////////////////////////////////////////////////////////////////////////

void RemSupportedFunctions(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TStringArray RequestedFunctions;
	TStringArray SupportedFunctions;
	int SupportedFunctionsCount = 0;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );
	Input.unFlatten( &RequestedFunctions );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	UplinkResourceLock Lock( &Err );	// Fast function that does not communicate with the device
										// so use the UplinkResourceLock
	if( !Err.Status() && DeviceDLL_FileName().IsEmpty() )
		Err.SetError( 15, "Device DLL Not Loaded" );

	if( !Err.Status() )
	{
		ErrorCluster Err2;

		SupportedFunctions.Initialize("", RequestedFunctions.GetSize() );

		for( int i = 0; i < RequestedFunctions.GetSize(); i++ )
		{
			if( GetDeviceFunctionAddress( &Err2, RequestedFunctions[i] ) != NULL )
				SupportedFunctions[SupportedFunctionsCount++] = RequestedFunctions[i];

			Err2.ResetStatus();
		}
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( SupportedFunctions.SubArray( 0, SupportedFunctionsCount ) );
}

///////////////////////////////////////////////////////////////////////////////

static TStringArray GetInterfaceAndDllInfo( ErrorCluster *error, bool *Released, bool *Match )
{
	if( error->Status() )
		return TStringArray();

	TStringArray LocalFiles;
	TStringArray MasterFiles;

	// Interfaces - Start
	LocalFiles.Insert( CommonInterface_FileName(true) );
	LocalFiles.Insert( RefCount.InterfaceList( error ) );

	for( int ii = MasterFiles.GetSize(); ii < LocalFiles.GetSize(); ii++ )
		MasterFiles.Insert( ReleasedInterfacePath() + RemovePathFromFileName( LocalFiles[ii] ) );

	// DLLs - Start
	LocalFiles.Insert( CommonDLL_FileName(true) );
	LocalFiles.Insert( ControllerDLL_FileNames(true) );

	if( !DeviceDLL_FileName().IsEmpty() )
		LocalFiles.Insert( DeviceDLL_FileName(true) );

	for( ii = MasterFiles.GetSize(); ii < LocalFiles.GetSize(); ii++ )
		MasterFiles.Insert( FindFile( ReleasedDllPath(), RemovePathFromFileName( LocalFiles[ii] ) ) );;

	// Done finding Interfaces and DLLs

	TStringArray Results( LocalFiles.GetSize() );

	*Released = *Match = true;

	for( int i = 0; i < LocalFiles.GetSize(); i++ )
	{
		uInt16Array LocalFileVersion;
		uInt32		LocalFlags;
		uInt16Array MasterFileVersion;
		uInt32		MasterFlags;
		bool FileReleased = false;
		bool FileMatch = false;

		Results[i] = RemovePathFromFileName( LocalFiles[i] );

		if( ReadFileVersionInformation( LocalFiles[i], &LocalFileVersion, NULL, &LocalFlags ) )
		{
			if( LocalFlags & ( VS_FF_PRERELEASE | VS_FF_PRIVATEBUILD | VS_FF_SPECIALBUILD ) )
			{
				if( LocalFlags & VS_FF_PRERELEASE )
					Results[i] += " (PRE-RELEASE)";

				if( LocalFlags & VS_FF_PRIVATEBUILD )
					Results[i] += " (Private Build)";

				if( LocalFlags & VS_FF_SPECIALBUILD )
					Results[i] += " (Special Build)";
			}
			else
				FileReleased = true;
		}
		else
			error->SetError( 15, "Unable to read Library Version Information from '%s'\n", Results[i].CStr() );

		if( ReadFileVersionInformation( MasterFiles[i], &MasterFileVersion, NULL, &MasterFlags ) )
			FileMatch = MasterFileVersion == LocalFileVersion && MasterFlags == LocalFlags;

		if( !FileMatch )
			Results[i] += " (Not Current Version)";

		*Released &= FileReleased;
		*Match &= FileMatch;
	}

	if( InDebugMode )	// If Common Interface is running in debug mode
	{
		Results[0] += " (DEBUG)";	// append (DEBUG) to end of first element
		*Released = false;			// mark the whole set of Interfaces/Dlls as unreleased
	}

	return Results;
}

void RemDllAndInterfaceVersionInfo(	handle_t		h1,								// [in]
									long			lSizeIn,						// [in]
									unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
									long			__RPC_FAR *lSizeOut,			// [out]
									unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TStringArray Info;
	bool Released = false;
	bool Match = false;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	UplinkResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		Info = GetInterfaceAndDllInfo( &Err, &Released, &Match );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( Info );
	Output.Flatten( Released );
	Output.Flatten( Match );
}

void RemRevisionCheckFile(	handle_t		h1,								// [in]
							long			lSizeIn,						// [in]
							unsigned char	__RPC_FAR *DataIn,				// [size_is][in]
							long			__RPC_FAR *lSizeOut,			// [out]
							unsigned char __RPC_FAR *__RPC_FAR *DataOut)	// [size_is][size_is][out]
{
	////// Declare Server Side Params ///////

	ErrorCluster Err;
	TString FilePath;

	///////// unFlatten Input Data //////////

	unFlattenData Input(DataIn, lSizeIn);

	Input.unFlatten( &Err );

	Input.BufferStatus( &Err );

	///////// Do Something usefull //////////

	UplinkResourceLock Lock( &Err );

	if( !Err.Status() )
	{
		FilePath = RevisionCheckFile( &Err );
	}

	Lock.UnLock();

	////////// Flatten Return Data //////////

	FlattenData Output(DataOut, lSizeOut);
	Output.Flatten( &Err );
	Output.Flatten( FilePath );
}
