#include <pic.h>


unsigned char delayus_variable;

#include	"delay.h"

//  This delay uses DelayUs to generate mSec.
//  The code is not optimized and an error
//  has been calibrated out.  As shown, 13
//  uSec in every 100 uSec has to be added.
void DelayMs(unsigned char cnt)
{
	unsigned char	i;
	do {
		i = 5;
		do {
			DelayUs(113); // Here is this calibration
			CLRWDT();
		} while(--i != 0);
	} while(--cnt != 0);
}
